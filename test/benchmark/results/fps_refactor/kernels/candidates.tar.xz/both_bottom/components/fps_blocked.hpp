#ifndef CP_COMPONENTS_FPS_BLOCKED_HPP
#define CP_COMPONENTS_FPS_BLOCKED_HPP
#include "fps_asm.hpp"
#include "fps_workspace.hpp"
#include "fps_output.hpp"
#include "../math/mint.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <type_traits>
#include <span>
#include <cstring>
#include <vector>

#if defined(__linux__) && defined(__x86_64__) && defined(__GNUC__) && !defined(__clang__)
#include <immintrin.h>
#pragma GCC push_options
_Pragma("GCC target(\"avx2\")")
#pragma GCC optimize("O3")

namespace fps_detail {
namespace blocked_ntt::kernels {

using Vec = __m256i;

inline constexpr std::uint32_t kP = 998244353, k2P = 2 * kP, kNI = 998244351;

inline void forward(Vec* a, std::size_t h, const std::uint32_t* x, const std::uint32_t* y) {
	alignas(32) Vec w[3];
	Vec* const end = a + h;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U) \
R(%[P],z) R(%[P2],r) D((%[x]),d) m(d,G)\
D(32(%[x]),w)\
D((%[y]),d)\
m(d,L)\
D(32(%[y]),E)\
D(4(%[y]),d)\
m(d,M)\
D(36(%[y]),F)\
".p2align 5\n\t" \
"1:\n\t" \
m(H,d)\
m(J,c)\
m(N,k)\
m(Q,g)\
q(H,w,u)\
q(J,w,s)\
q(4(%[a],%[h3]),w,e)\
q(36(%[a],%[h3]),w,i)\
m(I,l)\
v(t,u,u)\
m(K,n)\
v(t,s,s)\
B(A,e,u,e)\
B(A,i,s,i)\
m((%[a]),s)\
p(G,d,d)\
p(z,e,e)\
m(O,u)\
p(G,c,c)\
p(z,i,i)\
j(r,k,f)\
C(f,k,f)\
q(I,w,k)\
j(e,d,e)\
j(r,g,d)\
C(d,g,d)\
j(i,c,i)\
q(K,w,c)\
q(4(%[a],%[h],2),w,g)\
v(t,k,k)\
p(G,l,l)\
p(G,n,n)\
v(t,c,c)\
B(A,g,k,g)\
q(36(%[a],%[h],2),w,k)\
p(z,g,g)\
B(A,k,c,k)\
o(r,f,c)\
o(e,f,f)\
j(e,c,e)\
p(z,k,k)\
j(g,l,g)\
o(r,d,l)\
o(i,d,d)\
j(i,l,i)\
v(t,f,l)\
q(E,f,c)\
q(E,l,l)\
p(L,f,f)\
j(k,n,k)\
v(t,e,n)\
q(F,n,n)\
v(t,c,c)\
B(A,l,c,l)\
q(F,e,c)\
p(M,e,e)\
p(z,l,l)\
v(t,c,c)\
B(A,n,c,n)\
j(l,f,l)\
v(t,d,f)\
q(E,d,c)\
q(E,f,f)\
p(z,n,n)\
p(L,d,d)\
v(t,c,c)\
B(A,f,c,f)\
j(n,e,n)\
v(t,i,e)\
q(F,i,c)\
q(F,e,e)\
p(z,f,f)\
p(M,i,i)\
v(t,c,c)\
B(A,e,c,e)\
j(f,d,f)\
j(r,s,d)\
j(r,u,c)\
C(d,s,d)\
C(c,u,c)\
p(z,e,e)\
o(g,d,u)\
j(g,d,g)\
o(k,c,d)\
j(k,c,k)\
j(r,u,c)\
o(r,g,s)\
C(c,u,c)\
C(s,g,s)\
j(e,i,e)\
j(r,d,i)\
o(r,k,g)\
C(i,d,i)\
o(r,c,d)\
o(r,s,u)\
C(g,k,g)\
o(l,c,c)\
j(l,d,l)\
o(n,s,s)\
o(r,i,d)\
o(r,g,k)\
j(n,u,n)\
o(f,i,i)\
m(c,(%[a]))\
j(f,d,f)\
o(e,g,g)\
j(e,k,e)\
m(l,N)\
m(s,I)\
m(n,H)\
m(i,O)\
m(f,Q)\
m(g,K)\
m(e,J)\
S($64,%[a])\
T(%[end],%[a])\
U(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm1,%%ymm0,%%ymm6,%%ymm10,%%ymm3,%%ymm7,CP_FPS_ASM_VPSUBD,%%ymm2,%%ymm8,CP_FPS_ASM_VMOVDQA,%%ymm9,CP_FPS_ASM_VPADDD,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,%%ymm14,%%ymm5,$32,%%ymm4,CP_FPS_ASM_VPSRLQ,%%ymm11,%%ymm15,$170,CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPMINUD,CP_FPS_ASM_VBROADCASTSS,%%ymm12,%%ymm13,(%[w]),(%[a],%[h3]),(%[a],%[h],2),32(%[a],%[h3]),32(%[a],%[h],2),32(%[w]),64(%[w]),(%[a],%[h]),32(%[a]),32(%[a],%[h]),CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_ADD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a)
		: [end] "r"(end), [h] "r"(32 * h), [h3] "r"(96 * h), [y] "r"(y), [x] "r"(x), [w] "r"(w), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

inline void inverse(Vec* a, std::size_t h, const std::uint32_t* x, const std::uint32_t* y) {
	alignas(32) Vec w[3];
	Vec* const end = a + h;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T) \
Q(%[P],w) Q(%[P2],k) C((%[x]),c) r(c,F)\
C(32(%[x]),v)\
C((%[y]),c)\
r(c,K)\
C(32(%[y]),D)\
C(4(%[y]),c)\
r(c,L)\
C(36(%[y]),E)\
".p2align 5\n\t" \
"1:\n\t" \
r((%[a]),c)\
r(N,f)\
r(M,s)\
r(O,t)\
n(k,c,i)\
n(H,c,c)\
n(k,f,j)\
h(H,i,i)\
n(J,f,f)\
h(k,c,u)\
n(k,s,e)\
h(J,j,j)\
q(l,i,g)\
p(D,i,d)\
n(k,t,m)\
h(G,e,e)\
p(D,g,g)\
o(K,i,i)\
h(I,m,m)\
n(G,s,s)\
B(u,c,u)\
q(l,j,c)\
p(D,c,c)\
q(l,d,d)\
n(I,t,t)\
A(z,g,d,g)\
p(D,j,d)\
o(K,j,j)\
o(w,g,g)\
q(l,d,d)\
A(z,c,d,c)\
h(g,i,g)\
q(l,e,i)\
p(E,e,d)\
p(E,i,i)\
o(w,c,c)\
o(L,e,e)\
q(l,d,d)\
A(z,i,d,i)\
h(c,j,c)\
q(l,m,j)\
p(E,m,d)\
p(E,j,j)\
o(w,i,i)\
o(L,m,m)\
q(l,d,d)\
A(z,j,d,j)\
h(i,e,i)\
h(k,f,e)\
h(k,s,d)\
o(w,j,j)\
B(e,f,e)\
B(d,s,d)\
h(k,t,s)\
n(k,u,f)\
B(s,t,s)\
n(k,e,t)\
n(d,u,u)\
h(d,f,d)\
h(s,t,t)\
n(s,e,s)\
n(k,g,e)\
h(j,m,j)\
n(k,c,m)\
h(i,e,e)\
q(l,d,f)\
h(j,m,m)\
p(v,f,f)\
n(i,g,i)\
n(j,c,j)\
p(v,d,c)\
q(l,e,g)\
o(F,d,d)\
p(v,g,g)\
q(l,c,c)\
A(z,f,c,f)\
p(v,e,c)\
o(F,e,e)\
o(w,f,f)\
q(l,c,c)\
A(z,g,c,g)\
h(f,d,f)\
q(l,t,d)\
p(v,t,c)\
p(v,d,d)\
o(w,g,g)\
r(f,M)\
q(l,m,f)\
p(v,f,f)\
o(F,t,t)\
q(l,c,c)\
A(z,d,c,d)\
h(g,e,g)\
p(v,m,e)\
o(F,m,m)\
o(w,d,d)\
h(k,u,c)\
r(g,G)\
h(k,i,g)\
B(c,u,c)\
q(l,e,e)\
h(k,s,u)\
B(g,i,g)\
r(c,(%[a]))\
A(z,f,e,f)\
h(k,j,e)\
B(u,s,u)\
h(d,t,d)\
r(g,H)\
o(w,f,f)\
B(e,j,e)\
r(u,N)\
r(e,J)\
r(d,O)\
h(f,m,f)\
r(f,I)\
R($64,%[a])\
S(%[end],%[a])\
T(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm0,%%ymm9,%%ymm7,%%ymm1,%%ymm8,CP_FPS_ASM_VPSUBD,%%ymm4,%%ymm5,%%ymm14,$32,%%ymm10,CP_FPS_ASM_VPADDD,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,CP_FPS_ASM_VPSRLQ,CP_FPS_ASM_VMOVDQA,%%ymm2,%%ymm3,%%ymm6,%%ymm11,%%ymm15,$170,CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPMINUD,CP_FPS_ASM_VBROADCASTSS,%%ymm12,%%ymm13,(%[w]),(%[a],%[h3]),(%[a],%[h]),32(%[a],%[h3]),32(%[a],%[h]),32(%[w]),64(%[w]),(%[a],%[h],2),32(%[a]),32(%[a],%[h],2),CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_ADD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a)
		: [end] "r"(end), [h] "r"(32 * h), [h3] "r"(96 * h), [y] "r"(y), [x] "r"(x), [w] "r"(w), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

inline void forward_identity(Vec* a, std::size_t h, const std::uint32_t* y) {
	Vec* const end = a + h;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N) \
K(%[P],A) K(%[P2],d) I(4(%[y]),z) I(36(%[y]),t)\
".p2align 5\n\t" \
"1:\n\t" \
j(C,o)\
j(G,g)\
j(B,p)\
j(F,l)\
j((%[a]),i)\
j(D,m)\
j(E,q)\
j(H,r)\
c(d,o,h)\
c(d,g,f)\
n(h,o,h)\
c(d,p,o)\
n(f,g,f)\
k(d,h,g)\
c(d,l,s)\
n(o,p,o)\
k(d,f,p)\
n(s,l,s)\
c(o,g,g)\
c(d,i,l)\
k(o,h,o)\
c(s,p,p)\
x(u,g,h)\
w(t,g,e)\
n(l,i,l)\
x(u,p,i)\
w(t,h,h)\
v(z,g,g)\
k(s,f,s)\
w(t,p,f)\
w(t,i,i)\
x(u,e,e)\
v(z,p,p)\
J($170,h,e,h)\
c(d,m,e)\
x(u,f,f)\
n(e,m,e)\
v(A,h,h)\
c(d,q,m)\
n(m,q,m)\
J($170,i,f,i)\
c(d,r,f)\
k(e,l,q)\
n(f,r,f)\
c(e,l,e)\
v(A,i,i)\
c(d,q,l)\
k(f,m,r)\
c(f,m,f)\
k(d,e,m)\
n(l,q,l)\
c(d,r,q)\
n(m,e,m)\
c(d,o,e)\
c(h,g,h)\
k(d,f,g)\
n(q,r,q)\
c(d,s,r)\
n(e,o,e)\
n(g,f,g)\
k(d,l,f)\
k(d,m,o)\
n(r,s,r)\
c(i,p,i)\
k(d,q,p)\
k(d,g,s)\
k(e,l,l)\
c(e,f,e)\
k(h,m,m)\
c(h,o,h)\
k(r,q,q)\
j(l,(%[a]))\
c(r,p,r)\
k(i,g,g)\
c(i,s,i)\
j(e,C)\
j(m,D)\
j(h,B)\
j(q,E)\
j(r,G)\
j(g,H)\
j(i,F)\
L($64,%[a])\
M(%[end],%[a])\
N(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(CP_FPS_ASM_VPSUBD,%%ymm14,%%ymm11,%%ymm9,%%ymm1,%%ymm8,%%ymm4,CP_FPS_ASM_VMOVDQA,CP_FPS_ASM_VPADDD,%%ymm3,%%ymm5,CP_FPS_ASM_VPMINUD,%%ymm0,%%ymm2,%%ymm6,%%ymm7,%%ymm10,%%ymm13,$32,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,CP_FPS_ASM_VPSRLQ,%%ymm12,%%ymm15,(%[a],%[h3]),(%[a],%[h]),(%[a],%[h],2),32(%[a]),32(%[a],%[h3]),32(%[a],%[h]),32(%[a],%[h],2),CP_FPS_ASM_VBROADCASTSS,CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_ADD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a)
		: [end] "r"(end), [h] "r"(32 * h), [h3] "r"(96 * h), [y] "r"(y), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

inline void inverse_identity(Vec* a, std::size_t h, const std::uint32_t* y) {
	Vec* const end = a + h;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N) \
K(%[P],A) K(%[P2],f) I(4(%[y]),z) I(36(%[y]),t)\
".p2align 5\n\t" \
"1:\n\t" \
p(F,c)\
p(H,r)\
p((%[a]),n)\
p(G,j)\
h(f,c,o)\
h(B,c,c)\
h(f,r,i)\
e(B,o,o)\
h(D,r,r)\
e(f,c,s)\
e(D,i,i)\
x(u,o,d)\
w(t,o,g)\
v(z,o,o)\
x(u,i,k)\
w(t,i,m)\
w(t,d,d)\
h(C,n,q)\
w(t,k,k)\
v(z,i,i)\
e(C,n,n)\
l(s,c,s)\
x(u,g,g)\
h(E,j,c)\
e(E,j,j)\
x(u,m,m)\
J($170,d,g,d)\
e(f,q,g)\
J($170,k,m,k)\
v(A,d,d)\
l(g,q,g)\
h(f,n,q)\
v(A,k,k)\
e(f,c,m)\
l(q,n,q)\
h(s,g,n)\
l(m,c,m)\
e(s,g,s)\
e(f,r,g)\
h(f,j,c)\
e(d,o,d)\
l(g,r,g)\
l(c,j,c)\
e(f,n,j)\
e(k,i,k)\
h(d,q,i)\
e(d,q,d)\
h(g,m,q)\
h(k,c,r)\
e(g,m,g)\
e(k,c,k)\
e(f,i,c)\
h(f,s,m)\
h(f,d,o)\
l(j,n,j)\
l(c,i,c)\
e(f,q,i)\
e(f,r,n)\
l(m,s,m)\
l(o,d,o)\
p(j,(%[a]))\
h(f,g,j)\
h(f,k,d)\
l(i,q,i)\
l(n,r,n)\
p(c,C)\
l(j,g,j)\
l(d,k,d)\
p(m,F)\
p(o,B)\
p(i,G)\
p(n,E)\
p(j,H)\
p(d,D)\
L($64,%[a])\
M(%[end],%[a])\
N(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm0,%%ymm7,CP_FPS_ASM_VPSUBD,%%ymm14,%%ymm8,CP_FPS_ASM_VPADDD,%%ymm5,%%ymm3,%%ymm9,CP_FPS_ASM_VPMINUD,%%ymm10,%%ymm2,%%ymm4,CP_FPS_ASM_VMOVDQA,%%ymm11,%%ymm1,%%ymm6,%%ymm13,$32,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,CP_FPS_ASM_VPSRLQ,%%ymm12,%%ymm15,(%[a],%[h3]),(%[a],%[h]),32(%[a],%[h3]),32(%[a],%[h]),(%[a],%[h],2),32(%[a]),32(%[a],%[h],2),CP_FPS_ASM_VBROADCASTSS,CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_ADD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a)
		: [end] "r"(end), [h] "r"(32 * h), [h3] "r"(96 * h), [y] "r"(y), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

inline void scale_radix2(Vec* a, std::size_t h, const std::uint32_t* y) {
	Vec* const end = a + h;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,z,A,B,C,D,E,F,G,H,I,J,K) \
H(%[P],m) H(%[P2],C) G(4(%[y]),s) G(36(%[y]),l)\
".p2align 5\n\t" \
"1:\n\t" \
r((%[a]),c)\
r(F,d)\
z(C,c,e)\
z(D,c,c)\
z(C,d,f)\
k(D,e,e)\
z(E,d,d)\
q(n,c,h)\
k(E,f,f)\
p(l,c,v)\
q(n,e,i)\
p(l,e,w)\
q(n,d,j)\
p(l,d,x)\
q(n,f,g)\
p(l,f,u)\
p(l,h,h)\
p(l,i,i)\
p(l,j,j)\
p(l,g,g)\
q(n,v,v)\
q(n,w,w)\
q(n,x,x)\
q(n,u,u)\
o(s,c,c)\
o(s,e,e)\
A(t,h,v,h)\
A(t,i,w,i)\
o(s,d,d)\
o(s,f,f)\
A(t,j,x,j)\
A(t,g,u,g)\
o(m,h,h)\
o(m,i,i)\
o(m,j,j)\
o(m,g,g)\
k(h,c,h)\
k(i,e,i)\
k(j,d,j)\
k(g,f,g)\
k(m,h,f)\
k(m,i,d)\
k(m,j,e)\
k(m,g,c)\
B(f,h,f)\
B(d,i,d)\
B(e,j,e)\
B(c,g,c)\
r(f,(%[a]))\
r(d,D)\
r(e,F)\
r(c,E)\
I($64,%[a])\
J(%[end],%[a])\
K(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm0,%%ymm1,%%ymm2,%%ymm3,%%ymm10,%%ymm4,%%ymm6,%%ymm8,CP_FPS_ASM_VPSUBD,%%ymm13,%%ymm15,$32,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,CP_FPS_ASM_VPSRLQ,CP_FPS_ASM_VMOVDQA,%%ymm12,$170,%%ymm11,%%ymm5,%%ymm7,%%ymm9,CP_FPS_ASM_VPADDD,CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPMINUD,%%ymm14,(%[a],%[h]),32(%[a],%[h]),32(%[a]),CP_FPS_ASM_VBROADCASTSS,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_ADD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a)
		: [end] "r"(end), [h] "r"(32 * h), [h3] "r"(96 * h), [y] "r"(y), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

}
namespace blocked_ntt {

inline constexpr std::uint32_t kModulus = kernels::kP;
inline constexpr int kMaxLog = 25;

namespace detail {

using kernels::Vec;
using kernels::kP;

constexpr std::uint32_t multiply_mod(std::uint32_t x, std::uint32_t y) {
	return std::uint32_t(std::uint64_t(x) * y % kP);
}

constexpr std::uint32_t power(std::uint32_t x, std::uint32_t e) {
	std::uint32_t r = 1;
	for (; e; e >>= 1, x = multiply_mod(x, x))
		if (e & 1) r = multiply_mod(r, x);
	return r;
}

constexpr std::uint32_t quotient(std::uint32_t w) { return std::uint32_t((std::uint64_t(w) << 32) / kP); }

inline constexpr std::uint32_t kR = std::uint32_t((std::uint64_t(1) << 32) % kP);

inline constexpr int kRootCount = kMaxLog - 4;
inline constexpr auto kRoots = [] {
	std::array<std::array<std::uint32_t, kRootCount>, 2> t{};
	for (int j = 0; j < kRootCount; ++j) {
		t[0][j] = power(3, (kP - 1) >> (j + 2));
		t[1][j] = power(t[0][j], kP - 2);
	}
	return t;
}();

inline Vec broadcast(std::uint32_t x) { return _mm256_set1_epi32(int(x)); }
inline Vec add(Vec x, Vec y) { return _mm256_add_epi32(x, y); }
inline Vec diff(Vec x, Vec y) { return _mm256_sub_epi32(_mm256_add_epi32(x, broadcast(2 * kP)), y); }

inline Vec reduce(Vec x, std::uint32_t bound) { return _mm256_min_epu32(x, _mm256_sub_epi32(x, broadcast(bound))); }

struct Factor {
	Vec w, q;
	explicit Factor(std::uint32_t value) : w(broadcast(value)), q(broadcast(quotient(value))) {}
	Factor(std::uint32_t value, std::uint32_t value_quotient) : w(broadcast(value)), q(broadcast(value_quotient)) {}
};

inline Vec multiply(Vec x, const Factor& f) {
	const Vec even = _mm256_srli_epi64(_mm256_mul_epu32(x, f.q), 32);
	const Vec odd = _mm256_mul_epu32(_mm256_srli_epi64(x, 32), f.q);
	const Vec q = _mm256_blend_epi32(even, odd, 0xAA);
	return _mm256_sub_epi32(_mm256_mullo_epi32(x, f.w), _mm256_mullo_epi32(q, broadcast(kP)));
}

inline std::size_t slot(std::size_t k) { return (k >> 3 << 4) | (k & 7); }

inline std::size_t table_words(int lg) { return (std::size_t(1) << lg) / 8 + 16; }

inline void build_table(std::uint32_t* t, std::size_t count, const std::array<std::uint32_t, kRootCount>& roots) {
	t[slot(0)] = 1;
	t[slot(0) + 8] = quotient(1);
	for (int level = 0; level < kRootCount; ++level) {
		const std::size_t h = std::size_t(1) << level;
		if (h >= count) break;
		const std::uint32_t root = roots[level];
		if (h < 8) {
			for (std::size_t j = 0; j < h; ++j) {
				const std::uint32_t v = multiply_mod(t[slot(j)], root);
				t[slot(h + j)] = v;
				t[slot(h + j) + 8] = quotient(v);
			}
			continue;
		}

		const Factor by(root), to_r(kR);
		for (std::size_t j = 0; j < h; j += 8) {
			const Vec v = reduce(multiply(_mm256_load_si256(reinterpret_cast<const Vec*>(t + slot(j))), by), kP);
			const Vec vr = reduce(multiply(v, to_r), kP);
			_mm256_store_si256(reinterpret_cast<Vec*>(t + slot(h + j)), v);
			_mm256_store_si256(reinterpret_cast<Vec*>(t + slot(h + j) + 8), _mm256_mullo_epi32(vr, broadcast(kernels::kNI)));
		}
	}
}

inline void inverse_radix4(Vec* f, std::size_t h, const std::uint32_t* inverse_roots, const Factor& s) {
	const Factor z(inverse_roots[1], inverse_roots[9]);
	const auto scale = [&s](Vec x) __attribute__((target("avx2"))) { return reduce(multiply(x, s), kP); };
	for (std::size_t j = 0; j < h; ++j) {
		const Vec p0 = f[j], p1 = f[j + h], p2 = f[j + 2 * h], p3 = f[j + 3 * h];
		const Vec ab = reduce(add(p0, p1), 2 * kP), cd = reduce(add(p2, p3), 2 * kP);
		const Vec amb = reduce(diff(p0, p1), 2 * kP), cmd = multiply(diff(p2, p3), z);
		f[j] = scale(add(ab, cd)), f[j + h] = scale(add(amb, cmd));
		f[j + 2 * h] = scale(diff(ab, cd)), f[j + 3 * h] = scale(diff(amb, cmd));
	}
}

}
}
namespace blocked_poly::kernels {

using Vec = __m256i;

inline constexpr std::uint32_t kP = 998244353, k2P = 2 * kP;

[[gnu::noinline]] inline void forward_h4(Vec* a, std::size_t count, const std::uint32_t* table, std::size_t k) {
	Vec* const end = a + 16 * count;
	const std::uint32_t *tx, *ty;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U,V,W,X,Y,Z,_0,_1,_2,_3,_4) \
_0(%[P],w) _0(%[P2],q) ".p2align 5\n\t" "1:\n\t" \
_4(H,E)\
Z($-8,E)\
Y(H,E)\
G((%[table],%[tx],4),E)\
G((%[k],%[k]),F)\
Z($-8,F)\
G((%[ty],%[k],2),F)\
G((%[table],%[ty],4),F)\
D(32(%[tx]),p)\
D((%[tx]),A)\
s(R,d)\
s((%[a]),u)\
o(M,p,e)\
o(388(%[a]),p,g)\
n(M,A,c)\
i(q,d,f)\
o(I,p,C)\
z(f,d,f)\
o(260(%[a]),p,d)\
n(I,A,v)\
i(q,u,B)\
t(r,e,e)\
z(B,u,B)\
y(x,g,e,g)\
m(q,f,e)\
t(r,C,C)\
D(32(%[ty]),u)\
n(w,g,g)\
y(x,d,C,d)\
n(w,d,d)\
D((%[ty]),C)\
i(g,c,g)\
m(g,f,f)\
i(g,e,g)\
i(d,v,d)\
D(36(%[ty]),v)\
t(r,f,e)\
t(r,g,c)\
m(d,B,j)\
i(d,B,d)\
D(4(%[ty]),B)\
i(q,j,h)\
m(q,d,l)\
z(h,j,h)\
z(l,d,l)\
o(u,f,d)\
o(u,e,e)\
m(q,h,j)\
n(C,f,f)\
t(r,d,d)\
y(x,e,d,e)\
m(q,l,d)\
o(v,c,c)\
n(w,e,e)\
i(e,f,e)\
s(V,f)\
m(e,h,h)\
i(e,j,e)\
o(v,g,j)\
n(B,g,g)\
s(h,(%[a]))\
s(S,h)\
s(e,R)\
o(J,p,e)\
t(r,j,j)\
y(x,c,j,c)\
o(292(%[a]),p,j)\
t(r,e,e)\
n(w,c,c)\
y(x,j,e,j)\
o(N,p,e)\
n(w,j,j)\
i(c,g,c)\
o(420(%[a]),p,g)\
m(c,l,l)\
i(c,d,c)\
n(N,A,d)\
t(r,e,e)\
s(l,I)\
i(q,h,l)\
y(x,g,e,g)\
z(l,h,l)\
s(c,M)\
n(J,A,c)\
i(q,f,h)\
n(w,g,g)\
m(q,l,e)\
z(h,f,h)\
i(j,c,j)\
i(g,d,g)\
m(j,h,d)\
i(j,h,j)\
m(g,l,l)\
i(g,e,g)\
i(q,d,e)\
m(q,j,h)\
t(r,l,c)\
o(u,l,f)\
n(C,l,l)\
z(e,d,e)\
t(r,g,d)\
o(u,c,c)\
z(h,j,h)\
m(q,e,j)\
o(v,d,d)\
t(r,f,f)\
y(x,c,f,c)\
o(v,g,f)\
n(B,g,g)\
n(w,c,c)\
t(r,f,f)\
y(x,d,f,d)\
i(c,l,c)\
s(W,l)\
m(q,h,f)\
n(w,d,d)\
m(c,e,e)\
i(c,j,c)\
s(T,j)\
s(e,V)\
o(K,p,e)\
s(c,S)\
o(324(%[a]),p,c)\
i(d,g,d)\
o(O,p,g)\
t(r,e,e)\
m(d,h,h)\
i(d,f,d)\
o(452(%[a]),p,f)\
y(x,c,e,c)\
s(h,J)\
n(O,A,h)\
n(K,A,e)\
t(r,g,g)\
n(w,c,c)\
s(d,N)\
y(x,f,g,f)\
i(q,l,g)\
n(w,f,f)\
i(q,j,d)\
z(g,l,g)\
z(d,j,d)\
i(c,e,c)\
m(q,d,e)\
m(c,g,j)\
i(c,g,c)\
i(f,h,f)\
i(q,j,h)\
m(q,c,g)\
m(f,d,d)\
i(f,e,f)\
z(h,j,h)\
z(g,c,g)\
t(r,d,c)\
o(u,d,j)\
t(r,f,e)\
o(v,f,l)\
o(u,c,c)\
o(v,e,e)\
n(C,d,d)\
n(B,f,f)\
t(r,j,j)\
t(r,l,l)\
y(x,c,j,c)\
y(x,e,l,e)\
m(q,h,l)\
m(q,g,j)\
n(w,c,c)\
n(w,e,e)\
i(c,d,c)\
i(e,f,e)\
s(U,f)\
s(X,d)\
m(c,h,h)\
i(c,l,c)\
m(e,g,g)\
i(e,j,e)\
o(Q,p,j)\
o(L,p,l)\
s(h,W)\
o(484(%[a]),p,h)\
o(356(%[a]),p,p)\
s(c,T)\
n(Q,A,c)\
n(L,A,A)\
s(g,K)\
t(r,j,j)\
t(r,l,l)\
s(e,O)\
y(x,h,j,h)\
y(x,p,l,p)\
n(w,h,h)\
n(w,p,p)\
i(q,f,l)\
z(l,f,l)\
i(q,d,f)\
i(h,c,h)\
m(q,l,c)\
z(f,d,f)\
i(p,A,p)\
m(h,l,l)\
i(h,c,h)\
m(p,f,c)\
i(p,f,p)\
t(r,l,f)\
o(u,l,A)\
t(r,h,d)\
o(v,h,j)\
o(u,f,u)\
o(v,d,v)\
i(q,c,d)\
m(q,p,f)\
n(C,l,C)\
n(B,h,B)\
z(d,c,d)\
z(f,p,f)\
t(r,A,A)\
t(r,j,j)\
m(q,d,p)\
m(q,f,c)\
y(x,u,A,u)\
y(x,v,j,v)\
n(w,u,u)\
n(w,v,v)\
i(u,C,u)\
i(v,B,v)\
m(u,d,d)\
i(u,p,u)\
m(v,f,f)\
i(v,c,v)\
s(d,X)\
s(u,U)\
s(f,L)\
s(v,Q)\
Y($512,%[a])\
_2(H)\
_1(%[end],%[a])\
_3(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm6,%%ymm2,%%ymm4,%%ymm7,%%ymm5,%%ymm12,CP_FPS_ASM_VPSUBD,%%ymm11,%%ymm13,CP_FPS_ASM_VPADDD,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,%%ymm0,%%ymm14,$32,CP_FPS_ASM_VMOVDQA,CP_FPS_ASM_VPSRLQ,%%ymm3,%%ymm9,%%ymm15,$170,CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPMINUD,%%ymm1,%%ymm10,%%ymm8,CP_FPS_ASM_VBROADCASTSS,%[tx],%[ty],CP_FPS_ASM_LEA,%[k],256(%[a]),288(%[a]),320(%[a]),352(%[a]),384(%[a]),416(%[a]),448(%[a]),480(%[a]),128(%[a]),160(%[a]),192(%[a]),224(%[a]),32(%[a]),64(%[a]),96(%[a]),CP_FPS_ASM_ADD,CP_FPS_ASM_AND,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_CMP,CP_FPS_ASM_INC,CP_FPS_ASM_JNE,CP_FPS_ASM_MOV)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a), [k] "+r"(k), [tx] "=&r"(tx), [ty] "=&r"(ty)
		: [end] "r"(end), [table] "r"(table), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

[[gnu::noinline]] inline void inverse_h4(Vec* a, std::size_t count, const std::uint32_t* table, std::size_t k) {
	Vec* const end = a + 16 * count;
	const std::uint32_t *tx, *ty;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U,V,W,X,Y,Z,_0,_1,_2,_3,_4) \
_0(%[P],x) _0(%[P2],n) ".p2align 5\n\t" "1:\n\t" \
_4(H,E)\
Z($-8,E)\
Y(H,E)\
G((%[table],%[tx],4),E)\
G((%[k],%[k]),F)\
Z($-8,F)\
G((%[ty],%[k],2),F)\
G((%[table],%[ty],4),F)\
t((%[a]),l)\
t(R,m)\
D(32(%[ty]),v)\
D((%[ty]),C)\
p(n,l,w)\
p(I,l,l)\
i(I,w,w)\
p(n,m,g)\
i(n,l,c)\
p(M,m,m)\
D(36(%[ty]),u)\
s(o,w,d)\
r(v,w,e)\
i(M,g,g)\
q(C,w,w)\
D(4(%[ty]),B)\
r(v,d,d)\
s(o,g,f)\
A(c,l,c)\
i(n,m,l)\
A(l,m,l)\
s(o,e,e)\
p(l,c,m)\
z(y,d,e,d)\
i(n,m,e)\
q(x,d,d)\
p(n,c,c)\
A(e,m,e)\
D(32(%[tx]),m)\
i(l,c,l)\
t(e,(%[a]))\
s(o,l,e)\
r(u,g,c)\
r(u,f,f)\
i(d,w,d)\
q(B,g,g)\
D((%[tx]),w)\
s(o,c,c)\
z(y,f,c,f)\
p(n,d,c)\
q(x,f,f)\
r(m,l,h)\
r(m,e,e)\
i(f,g,f)\
i(f,c,c)\
s(o,h,h)\
q(w,l,l)\
p(f,d,f)\
s(o,c,d)\
r(m,c,g)\
z(y,e,h,e)\
q(w,c,c)\
t(T,h)\
r(m,d,d)\
q(x,e,e)\
i(n,f,j)\
A(j,f,j)\
t(S,f)\
s(o,g,g)\
t(j,I)\
z(y,d,g,d)\
i(e,l,e)\
q(x,d,d)\
t(e,R)\
i(d,c,d)\
p(n,h,c)\
p(J,h,h)\
t(d,M)\
i(J,c,c)\
p(n,f,d)\
i(n,h,e)\
p(N,f,f)\
s(o,c,l)\
r(v,c,g)\
i(N,d,d)\
q(C,c,c)\
r(v,l,l)\
s(o,d,j)\
A(e,h,e)\
i(n,f,h)\
r(u,j,j)\
A(h,f,h)\
r(u,d,f)\
s(o,g,g)\
q(B,d,d)\
z(y,l,g,l)\
p(n,e,g)\
p(h,e,e)\
s(o,f,f)\
q(x,l,l)\
i(h,g,h)\
i(n,e,g)\
z(y,j,f,j)\
A(g,e,g)\
s(o,h,e)\
r(m,h,f)\
q(x,j,j)\
r(m,e,e)\
t(g,T)\
i(l,c,l)\
q(w,h,h)\
p(n,l,c)\
s(o,f,f)\
i(j,d,j)\
z(y,e,f,e)\
i(j,c,c)\
q(x,e,e)\
p(j,l,j)\
t(W,l)\
s(o,c,f)\
r(m,c,d)\
q(w,c,c)\
i(n,j,g)\
r(m,f,f)\
A(g,j,g)\
t(U,j)\
i(e,h,e)\
t(g,J)\
s(o,d,d)\
t(e,S)\
z(y,f,d,f)\
q(x,f,f)\
p(n,l,d)\
p(K,l,l)\
i(f,c,f)\
i(K,d,d)\
p(n,j,c)\
i(n,l,e)\
p(O,j,j)\
t(f,N)\
s(o,d,f)\
r(v,d,g)\
i(O,c,c)\
q(C,d,d)\
r(v,f,f)\
s(o,c,h)\
A(e,l,e)\
i(n,j,l)\
r(u,h,h)\
A(l,j,l)\
r(u,c,j)\
s(o,g,g)\
q(B,c,c)\
z(y,f,g,f)\
p(n,e,g)\
p(l,e,e)\
s(o,j,j)\
q(x,f,f)\
i(l,g,l)\
i(n,e,g)\
z(y,h,j,h)\
A(g,e,g)\
s(o,l,e)\
r(m,l,j)\
q(x,h,h)\
r(m,e,e)\
t(g,W)\
i(f,d,f)\
q(w,l,l)\
p(n,f,d)\
s(o,j,j)\
i(h,c,h)\
z(y,e,j,e)\
i(h,d,d)\
q(x,e,e)\
p(h,f,h)\
t(X,f)\
s(o,d,j)\
r(m,d,c)\
q(w,d,d)\
i(n,h,g)\
r(m,j,j)\
A(g,h,g)\
t(V,h)\
i(e,l,e)\
t(g,K)\
s(o,c,c)\
t(e,U)\
z(y,j,c,j)\
q(x,j,j)\
p(n,f,c)\
p(L,f,f)\
i(j,d,j)\
i(L,c,c)\
p(n,h,d)\
i(n,f,e)\
p(Q,h,h)\
t(j,O)\
s(o,c,j)\
r(v,c,g)\
i(Q,d,d)\
q(C,c,C)\
r(v,j,v)\
s(o,d,j)\
r(u,d,c)\
A(e,f,e)\
r(u,j,u)\
q(B,d,B)\
i(n,h,d)\
s(o,g,g)\
A(d,h,d)\
z(y,v,g,v)\
s(o,c,c)\
p(n,e,g)\
p(d,e,e)\
q(x,v,v)\
z(y,u,c,u)\
i(d,g,d)\
i(n,e,g)\
q(x,u,u)\
s(o,d,c)\
r(m,d,h)\
A(g,e,g)\
r(m,c,c)\
q(w,d,d)\
t(g,X)\
i(v,C,v)\
i(u,B,u)\
p(n,v,B)\
s(o,h,h)\
i(u,B,B)\
z(y,c,h,c)\
p(u,v,u)\
s(o,B,v)\
r(m,B,h)\
q(x,c,c)\
i(n,u,C)\
r(m,v,m)\
q(w,B,w)\
A(C,u,C)\
t(C,L)\
s(o,h,h)\
i(c,d,c)\
z(y,m,h,m)\
t(c,V)\
q(x,m,m)\
i(m,w,m)\
t(m,Q)\
Y($512,%[a])\
_2(H)\
_1(%[end],%[a])\
_3(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm6,%%ymm8,%%ymm9,%%ymm11,%%ymm5,%%ymm12,CP_FPS_ASM_VPSUBD,%%ymm13,%%ymm0,%%ymm1,%%ymm14,$32,CP_FPS_ASM_VPADDD,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,CP_FPS_ASM_VPSRLQ,CP_FPS_ASM_VMOVDQA,%%ymm7,%%ymm2,%%ymm4,%%ymm15,$170,CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPMINUD,%%ymm10,%%ymm3,CP_FPS_ASM_VBROADCASTSS,%[tx],%[ty],CP_FPS_ASM_LEA,%[k],128(%[a]),160(%[a]),192(%[a]),224(%[a]),384(%[a]),416(%[a]),448(%[a]),480(%[a]),256(%[a]),288(%[a]),32(%[a]),320(%[a]),352(%[a]),64(%[a]),96(%[a]),CP_FPS_ASM_ADD,CP_FPS_ASM_AND,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_CMP,CP_FPS_ASM_INC,CP_FPS_ASM_JNE,CP_FPS_ASM_MOV)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a), [k] "+r"(k), [tx] "=&r"(tx), [ty] "=&r"(ty)
		: [end] "r"(end), [table] "r"(table), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}





[[gnu::noinline]] inline void forward_top8_lower(Vec* a, std::size_t q, const std::uint32_t* table) {
	alignas(32) Vec w[3];
	Vec* b = a + 4 * q;
	Vec* const end = a + q;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,i,j,k,l,m,n,o,p,q,r,s,u,v,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U) \
S(%[P],y) S(%[P2],x) D(4(%[t]),d) m(d,0(%[w]))\
D(36(%[t]),z)\
D(8(%[t]),d)\
m(d,H)\
D(40(%[t]),E)\
D(12(%[t]),d)\
m(d,I)\
D(44(%[t]),F)\
".p2align 5\n\t" \
"1:\n\t" \
m(J,d)\
m(L,o)\
m(K,n)\
m((%[a]),p)\
v(q,o,f)\
u(z,o,i)\
u(z,f,f)\
k(y,n,c)\
s(C,o,e)\
k(d,n,r)\
v(q,d,j)\
u(z,d,g)\
l(d,c,c)\
u(z,j,j)\
v(q,i,i)\
s(C,d,d)\
B(A,f,i,f)\
v(q,c,i)\
v(q,g,g)\
u(z,i,i)\
s(y,f,f)\
B(A,j,g,j)\
u(z,c,g)\
s(C,c,c)\
s(y,j,j)\
l(f,e,f)\
k(x,p,e)\
v(q,g,g)\
l(f,e,e)\
k(f,p,f)\
l(j,d,j)\
B(A,i,g,i)\
k(y,p,g)\
l(x,f,d)\
s(y,i,i)\
k(o,p,p)\
l(o,g,o)\
G(d,f,d)\
k(x,n,f)\
k(j,n,n)\
l(x,e,g)\
l(j,f,j)\
G(g,e,g)\
v(q,n,e)\
u(E,n,f)\
u(E,e,e)\
s(H,n,n)\
l(i,c,i)\
v(q,j,c)\
u(F,c,c)\
v(q,f,f)\
B(A,e,f,e)\
u(F,j,f)\
s(I,j,j)\
s(y,e,e)\
v(q,f,f)\
B(A,c,f,c)\
l(e,n,e)\
m(N,n)\
k(x,p,f)\
k(r,p,p)\
s(y,c,c)\
l(r,f,r)\
m(p,(%[a]))\
m(Q,p)\
k(x,o,f)\
k(i,o,o)\
l(i,f,i)\
m(r,K)\
m(O,r)\
k(x,d,f)\
k(e,d,d)\
l(e,f,e)\
m(o,L)\
m(M,o)\
k(x,g,f)\
l(c,j,c)\
m(i,J)\
k(c,g,g)\
l(c,f,c)\
m(d,(%[b]))\
m(e,(%[b],%[h]))\
m(g,(%[b],%[h],2))\
m(c,(%[b],%[h3]))\
v(q,p,c)\
u(z,p,g)\
u(z,c,c)\
k(y,r,e)\
s(C,p,d)\
k(n,r,f)\
v(q,n,i)\
u(z,n,j)\
l(n,e,e)\
u(z,i,i)\
v(q,g,g)\
s(C,n,n)\
B(A,c,g,c)\
v(q,e,g)\
v(q,j,j)\
u(z,g,g)\
s(y,c,c)\
B(A,i,j,i)\
u(z,e,j)\
s(C,e,e)\
s(y,i,i)\
l(c,d,c)\
k(x,o,d)\
v(q,j,j)\
l(c,d,d)\
k(c,o,c)\
l(i,n,i)\
B(A,g,j,g)\
k(y,o,j)\
l(x,c,n)\
s(y,g,g)\
k(p,o,o)\
l(p,j,p)\
G(n,c,n)\
k(x,r,c)\
k(i,r,r)\
l(x,d,j)\
l(i,c,i)\
G(j,d,j)\
v(q,r,d)\
u(E,r,c)\
u(E,d,d)\
s(H,r,r)\
l(g,e,g)\
v(q,i,e)\
u(F,e,e)\
v(q,c,c)\
B(A,d,c,d)\
u(F,i,c)\
s(I,i,i)\
s(y,d,d)\
v(q,c,c)\
B(A,e,c,e)\
l(d,r,d)\
k(x,o,r)\
k(x,p,c)\
s(y,e,e)\
k(f,o,o)\
l(f,r,f)\
k(g,p,p)\
k(x,n,r)\
l(g,c,g)\
k(d,n,n)\
m(o,M)\
k(x,j,o)\
l(d,r,d)\
m(f,O)\
l(e,i,e)\
m(p,Q)\
k(e,j,j)\
l(e,o,e)\
m(g,N)\
m(n,32(%[b]))\
m(d,32(%[b],%[h]))\
m(j,32(%[b],%[h],2))\
m(e,32(%[b],%[h3]))\
R($64,%[a])\
R($64,%[b])\
T(%[end],%[a])\
U(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm6,%%ymm0,%%ymm7,%%ymm4,%%ymm10,%%ymm5,%%ymm9,CP_FPS_ASM_VPADDD,CP_FPS_ASM_VPSUBD,CP_FPS_ASM_VMOVDQA,%%ymm2,%%ymm1,%%ymm3,$32,%%ymm8,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,CP_FPS_ASM_VPSRLQ,%%ymm14,%%ymm15,%%ymm11,$170,CP_FPS_ASM_VPBLENDD,(%[w]),CP_FPS_ASM_VBROADCASTSS,%%ymm12,%%ymm13,CP_FPS_ASM_VPMINUD,32(%[w]),64(%[w]),(%[a],%[h3]),(%[a],%[h]),(%[a],%[h],2),32(%[a]),32(%[a],%[h3]),32(%[a],%[h]),32(%[a],%[h],2),CP_FPS_ASM_ADD,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a), [b] "+r"(b)
		: [end] "r"(end), [h] "r"(32 * q), [h3] "r"(96 * q), [t] "r"(table), [w] "r"(w), [P] "m"(kP),
		  [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

[[gnu::noinline]] inline void forward_top8_upper(Vec* a, std::size_t q, const std::uint32_t* table) {
	alignas(32) Vec w[3];
	Vec* b = a + 4 * q;
	Vec* const end = a + q;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,i,j,k,l,m,n,o,p,q,r,s,u,v,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U) \
S(%[P],o) S(%[P2],y) D(4(%[t]),n) m(n,0(%[w]))\
D(36(%[t]),z)\
D(8(%[t]),n)\
m(n,H)\
D(40(%[t]),E)\
D(12(%[t]),n)\
m(n,I)\
D(44(%[t]),F)\
".p2align 5\n\t" \
"1:\n\t" \
m(J,n)\
m(L,v)\
m(K,e)\
m((%[b]),k)\
j(n,o,c)\
j(v,o,f)\
u(q,f,p)\
s(z,f,d)\
j(e,o,g)\
l(o,e,i)\
s(z,p,p)\
j(n,i,i)\
r(C,f,f)\
j(k,o,x)\
l(n,e,n)\
u(q,c,e)\
s(z,e,e)\
u(q,d,d)\
B(A,p,d,p)\
s(z,c,d)\
r(C,c,c)\
r(o,p,p)\
u(q,d,d)\
B(A,e,d,e)\
j(p,f,p)\
u(q,i,f)\
s(z,i,d)\
r(o,e,e)\
s(z,f,f)\
r(C,i,i)\
u(q,d,d)\
j(e,c,e)\
B(A,f,d,f)\
l(y,x,d)\
l(p,x,x)\
l(e,g,c)\
r(o,f,f)\
j(p,d,p)\
l(o,k,d)\
l(y,g,g)\
l(v,k,k)\
j(v,d,v)\
u(q,c,d)\
j(e,g,e)\
s(E,d,d)\
s(E,c,g)\
r(H,c,c)\
j(f,i,f)\
u(q,e,i)\
s(F,i,i)\
u(q,g,g)\
B(A,d,g,d)\
s(F,e,g)\
r(I,e,e)\
r(o,d,d)\
u(q,g,g)\
B(A,i,g,i)\
j(d,c,d)\
j(y,x,c)\
j(y,p,g)\
r(o,i,i)\
G(c,x,c)\
G(g,p,g)\
m(N,p)\
l(y,k,x)\
l(n,k,k)\
j(n,x,n)\
m(Q,x)\
m(k,(%[a]))\
m(O,k)\
j(i,e,i)\
m(n,(%[a],%[h]))\
m(M,n)\
l(y,v,e)\
l(f,v,v)\
j(f,e,f)\
m(v,(%[a],%[h],2))\
l(y,c,v)\
l(y,g,e)\
l(d,c,c)\
j(d,v,d)\
l(i,g,g)\
j(i,e,i)\
m(f,(%[a],%[h3]))\
m(c,(%[b]))\
m(d,K)\
j(p,o,d)\
m(g,L)\
j(x,o,g)\
m(i,J)\
u(q,g,i)\
s(z,g,c)\
j(k,o,f)\
l(o,k,e)\
s(z,i,i)\
j(p,e,e)\
r(C,g,g)\
j(n,o,v)\
l(p,k,p)\
u(q,d,k)\
s(z,k,k)\
u(q,c,c)\
B(A,i,c,i)\
s(z,d,c)\
r(C,d,d)\
r(o,i,i)\
u(q,c,c)\
B(A,k,c,k)\
j(i,g,i)\
u(q,e,g)\
s(z,e,c)\
r(o,k,k)\
s(z,g,g)\
r(C,e,e)\
u(q,c,c)\
j(k,d,k)\
B(A,g,c,g)\
l(y,v,c)\
l(i,v,v)\
l(k,f,d)\
r(o,g,g)\
j(i,c,i)\
l(o,n,c)\
l(y,f,f)\
l(x,n,n)\
j(x,c,x)\
u(q,d,c)\
j(k,f,k)\
s(E,c,c)\
s(E,d,f)\
r(H,d,d)\
j(g,e,g)\
u(q,k,e)\
s(F,e,e)\
u(q,f,f)\
B(A,c,f,c)\
s(F,k,f)\
r(I,k,k)\
r(o,c,c)\
u(q,f,f)\
B(A,e,f,e)\
j(c,d,c)\
j(y,v,d)\
j(y,i,f)\
r(o,e,e)\
G(d,v,d)\
G(f,i,f)\
l(y,n,i)\
l(y,x,v)\
l(p,n,n)\
j(p,i,p)\
l(g,x,x)\
l(y,d,i)\
j(g,v,g)\
l(c,d,d)\
m(n,32(%[a]))\
j(e,k,e)\
l(y,f,k)\
j(c,i,c)\
m(p,32(%[a],%[h]))\
l(e,f,f)\
j(e,k,e)\
m(x,32(%[a],%[h],2))\
m(g,32(%[a],%[h3]))\
m(d,M)\
m(c,O)\
m(f,Q)\
m(e,N)\
R($64,%[a])\
R($64,%[b])\
T(%[end],%[a])\
U(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm4,%%ymm7,%%ymm2,%%ymm5,%%ymm8,%%ymm9,CP_FPS_ASM_VPSUBD,%%ymm3,CP_FPS_ASM_VPADDD,CP_FPS_ASM_VMOVDQA,%%ymm0,%%ymm15,%%ymm6,$32,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,CP_FPS_ASM_VPSRLQ,%%ymm1,%%ymm10,%%ymm14,%%ymm11,$170,CP_FPS_ASM_VPBLENDD,(%[w]),CP_FPS_ASM_VBROADCASTSS,%%ymm12,%%ymm13,CP_FPS_ASM_VPMINUD,32(%[w]),64(%[w]),(%[b],%[h3]),(%[b],%[h]),(%[b],%[h],2),32(%[b]),32(%[b],%[h3]),32(%[b],%[h]),32(%[b],%[h],2),CP_FPS_ASM_ADD,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a), [b] "+r"(b)
		: [end] "r"(end), [h] "r"(32 * q), [h3] "r"(96 * q), [t] "r"(table), [w] "r"(w), [P] "m"(kP),
		  [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

}

namespace blocked_poly {

inline constexpr std::uint32_t kModulus = blocked_ntt::kModulus;

enum class Half { kBoth, kLower, kUpper };

class Arena {
public:
	explicit Arena(std::size_t words)
		: storage_(allocate_fps_words(words)), next_(storage_.get()), end_(next_ + words) {}
	Arena(const Arena &) = delete;
	Arena &operator=(const Arena &) = delete;
	static constexpr std::size_t footprint(std::size_t n) { return (n + 7) / 8 * 8 + 16; }
	std::span<std::uint32_t> take(std::size_t n) {
		if (std::size_t(end_ - next_) < footprint(n)) throw std::bad_alloc();
		auto *start = next_;
		next_ += footprint(n);
		return {start, n};
	}

	bool zero_initialized() const { return storage_.get_deleter().region != nullptr; }

private:
	FpsWords storage_;
	std::uint32_t *next_, *end_;
};

namespace detail {

using blocked_ntt::detail::add;
using blocked_ntt::detail::broadcast;
using blocked_ntt::detail::diff;
using blocked_ntt::detail::Factor;
using blocked_ntt::detail::kP;
using blocked_ntt::detail::kR;
using blocked_ntt::detail::reduce;
using blocked_ntt::detail::slot;
using blocked_ntt::detail::Vec;

inline constexpr auto kInverseScales = [] {
	std::array<std::array<std::uint32_t, blocked_ntt::kMaxLog + 1>, 2> s{};
	for (int lg = 3; lg <= blocked_ntt::kMaxLog; ++lg) {
		s[0][lg] = blocked_ntt::detail::power(std::uint32_t(1) << (lg - 3), kP - 2);
		s[1][lg] = blocked_ntt::detail::multiply_mod(s[0][lg], kR);
	}
	return s;
}();

inline Vec load(const std::uint32_t* p) { return _mm256_load_si256(reinterpret_cast<const Vec*>(p)); }
inline void store(std::uint32_t* p, Vec x) { _mm256_store_si256(reinterpret_cast<Vec*>(p), x); }

inline Vec low(Vec x) { return reduce(x, 2 * kP); }
inline Vec canonical(Vec x) { return reduce(reduce(x, 2 * kP), kP); }

inline Vec low_difference(Vec x, Vec y) {
	const Vec t = _mm256_sub_epi32(x, y);
	return _mm256_min_epu32(t, _mm256_add_epi32(t, broadcast(2 * kP)));
}

inline Vec difference(Vec x, Vec y) { return reduce(_mm256_sub_epi32(add(x, broadcast(kP)), y), kP); }

inline Vec times(Vec x, const Factor& w) { return blocked_ntt::detail::multiply(x, w); }

inline Factor entry(const std::uint32_t* table, std::size_t k) {
	const std::uint32_t* e = table + slot(k);
	return Factor(e[0], e[8]);
}

inline Factor leaf_weight(const std::uint32_t* roots, std::size_t p) {
	const std::uint32_t* e = roots + slot(p >> 1);
	return p & 1 ? Factor(kP - e[0], ~e[8]) : Factor(e[0], e[8]);
}

struct Group {
	Factor x, y, z;
	[[gnu::always_inline]] Group(const std::uint32_t* table, std::size_t g)
		: x(entry(table, g)), y(entry(table, 2 * g)), z(entry(table, 2 * g + 1)) {}
};

[[gnu::always_inline]] inline void forward_h1(Vec (&f)[4], const Group& w) {
	const Vec a = low(f[0]), b = low(f[1]), c = times(f[2], w.x), d = times(f[3], w.x);
	const Vec ac = low(add(a, c)), amc = low_difference(a, c);
	const Vec bd = times(add(b, d), w.y), bmd = times(diff(b, d), w.z);
	f[0] = add(ac, bd), f[1] = diff(ac, bd), f[2] = add(amc, bmd), f[3] = diff(amc, bmd);
}

[[gnu::always_inline]] inline void inverse_h1(Vec (&f)[4], const Group& w) {
	const Vec ab = low(add(f[0], f[1])), cd = low(add(f[2], f[3]));
	const Vec amb = times(diff(f[0], f[1]), w.y), cmd = times(diff(f[2], f[3]), w.z);
	f[0] = low(add(ab, cd)), f[1] = low(add(amb, cmd));
	f[2] = times(diff(ab, cd), w.x), f[3] = times(diff(amb, cmd), w.x);
}

struct alignas(64) Window {
	std::uint32_t word[17];
};

inline void fill_window(Window& window, Vec a, const Factor& w) {
	window.word[16] = 0;
	store(window.word + 8, a);
	store(window.word, reduce(times(a, w), kP));
}

[[gnu::always_inline]] inline void fill_windows(Window (&window)[4], const Vec (&a)[4], const std::uint32_t* roots,
												std::size_t g) {
	const Factor y = entry(roots, 2 * g), z = entry(roots, 2 * g + 1);
#pragma GCC unroll 4
	for (int t = 0; t < 4; ++t) {
		window[t].word[16] = 0;
		store(window[t].word + 8, a[t]);
		const Vec wa = times(a[t], t < 2 ? y : z);
		store(window[t].word, reduce(t % 2 ? _mm256_sub_epi32(broadcast(2 * kP), wa) : wa, kP));
	}
}

[[gnu::always_inline]] inline Vec leaf_product(const Window& window, const std::uint32_t* b) {
	const Vec ni = broadcast(blocked_ntt::kernels::kNI), p = broadcast(kP), p2 = broadcast(2 * kP);
	Vec even, odd, bi, t0, t1, t2, t3;
	#define CP_FPS_ASM_BLOCK(a,c,d,e,f,g,h,i,j,k,l,m,n,o,q,r,s,t,u,v) \
i((%[b]),a) d(36(%[w]),a,e) d(r,a,c) i(4(%[b]),a)\
d(r,a,g)\
d(q,a,h)\
i(8(%[b]),a)\
d(q,a,j)\
d(o,a,k)\
f(g,e,e)\
f(h,c,c)\
i(12(%[b]),a)\
d(o,a,g)\
d(n,a,h)\
f(j,e,e)\
f(k,c,c)\
i(16(%[b]),a)\
d(n,a,j)\
d(m,a,k)\
f(g,e,e)\
f(h,c,c)\
i(20(%[b]),a)\
d(m,a,g)\
d(l,a,h)\
f(j,e,e)\
f(k,c,c)\
i(24(%[b]),a)\
d(l,a,j)\
d(s,a,k)\
f(g,e,e)\
f(h,c,c)\
i(28(%[b]),a)\
d(s,a,g)\
d(4(%[w]),a,h)\
f(j,e,e)\
f(k,c,c)\
f(g,e,e)\
f(h,c,c)\
d(%[ni],c,g)\
d(%[ni],e,h)\
d(%[p],g,g)\
d(%[p],h,h)\
f(g,c,c)\
f(h,e,e)\
u($32,c,c)\
t($0xaa,e,c,c)\
v(%[p2],c,g)\
"vpminud %[t0], %[even], %[even]"
	asm(
		CP_FPS_ASM_BLOCK(%[bi],%[even],CP_FPS_ASM_VPMULUDQ,%[odd],CP_FPS_ASM_VPADDQ,%[t0],%[t1],CP_FPS_ASM_VPBROADCASTD,%[t2],%[t3],12(%[w]),16(%[w]),20(%[w]),24(%[w]),28(%[w]),32(%[w]),8(%[w]),CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPSRLQ,CP_FPS_ASM_VPSUBD)
#undef CP_FPS_ASM_BLOCK
		: [even] "=&x"(even), [odd] "=&x"(odd), [bi] "=&x"(bi), [t0] "=&x"(t0), [t1] "=&x"(t1), [t2] "=&x"(t2),
		[t3] "=&x"(t3)
		: [w] "r"(window.word), [b] "r"(b), [ni] "x"(ni), [p] "x"(p), [p2] "x"(p2),
		"m"(*reinterpret_cast<const std::uint32_t(*)[17]>(window.word)),
		"m"(*reinterpret_cast<const std::uint32_t(*)[8]>(b)));
	return even;
}

struct ForwardBottom {
	static constexpr bool kForward = true, kInverse = false;
	const std::uint32_t* roots;

	void operator()(std::uint32_t* a, std::size_t count, std::size_t first) const {
		for (std::size_t j = 0; j < count; ++j, a += 32) {
			const Group w(roots, first + j);
			Vec f[4] = {load(a), load(a + 8), load(a + 16), load(a + 24)};
			forward_h1(f, w);
#pragma GCC unroll 4
			for (int t = 0; t < 4; ++t) store(a + 8 * t, canonical(f[t]));
		}
	}
};

struct InverseBottom {
	static constexpr bool kForward = false, kInverse = true;
	const std::uint32_t* inverse_roots;
	const std::uint32_t* in;

	void operator()(std::uint32_t* a, std::size_t count, std::size_t first) const {
		const std::uint32_t* from = in + 32 * first;
		for (std::size_t j = 0; j < count; ++j, a += 32, from += 32) {
			const Group w(inverse_roots, first + j);
			Vec f[4] = {load(from), load(from + 8), load(from + 16), load(from + 24)};
			inverse_h1(f, w);
			for (int t = 0; t < 4; ++t) store(a + 8 * t, f[t]);
		}
	}
};

struct ProductBottom {
	static constexpr bool kForward = true, kInverse = true;
	const std::uint32_t* roots;
	const std::uint32_t* inverse_roots;
	const std::uint32_t* b;

	[[gnu::always_inline]] void prepare(const std::uint32_t* a, std::size_t g, Window (&window)[4]) const {
		Vec f[4] = {load(a), load(a + 8), load(a + 16), load(a + 24)};
		forward_h1(f, Group(roots, g));
#pragma GCC unroll 4
		for (int t = 0; t < 4; ++t) f[t] = canonical(f[t]);
		fill_windows(window, f, roots, g);
	}

	[[gnu::always_inline]] void finish(std::uint32_t* a, std::size_t g, const Window (&window)[4]) const {
		Vec f[4];
#pragma GCC unroll 4
		for (int t = 0; t < 4; ++t) f[t] = leaf_product(window[t], b + 8 * (4 * g + t));
		inverse_h1(f, Group(inverse_roots, g));
		for (int t = 0; t < 4; ++t) store(a + 8 * t, f[t]);
	}

	void operator()(std::uint32_t* a, std::size_t count, std::size_t first) const {
		Window window[2][4];
		prepare(a, first, window[0]);
		for (std::size_t j = 0; j < count; ++j, a += 32) {
			if (j + 1 < count) prepare(a + 32, first + j + 1, window[(j + 1) & 1]);
			finish(a, first + j, window[j & 1]);
		}
	}
};

struct InverseProductBottom {
	static constexpr bool kForward = false, kInverse = true;
	ProductBottom product;
	const std::uint32_t* a;

	[[gnu::always_inline]] void prepare(std::size_t g, Window (&window)[4]) const {
		const std::uint32_t* leaves = a + 32 * g;
		const Vec f[4] = {load(leaves), load(leaves + 8), load(leaves + 16), load(leaves + 24)};
		fill_windows(window, f, product.roots, g);
	}

	void operator()(std::uint32_t* out, std::size_t count, std::size_t first) const {
		Window window[2][4];
		prepare(first, window[0]);
		for (std::size_t j = 0; j < count; ++j, out += 32) {
			if (j + 1 < count) prepare(first + j + 1, window[(j + 1) & 1]);
			product.finish(out, first + j, window[j & 1]);
		}
	}
};

template <std::size_t K>
struct InverseProductSumBottom {
	static constexpr bool kForward = false, kInverse = true;
	std::array<InverseProductBottom, K> terms;

	void prepare(std::size_t g, Window (&window)[K][4]) const {
		for (std::size_t k = 0; k < K; ++k) terms[k].prepare(g, window[k]);
	}

	void operator()(std::uint32_t* out, std::size_t count, std::size_t first) const {
		Window window[2][K][4];
		prepare(first, window[0]);
		for (std::size_t j = 0; j < count; ++j, out += 32) {
			if (j + 1 < count) prepare(first + j + 1, window[(j + 1) & 1]);
			const std::size_t g = first + j;
			Vec f[4];
#pragma GCC unroll 4
			for (std::size_t t = 0; t < 4; ++t) {
				f[t] = leaf_product(window[j & 1][0][t], terms[0].product.b + 8 * (4 * g + t));
				for (std::size_t k = 1; k < K; ++k)
					f[t] = low(add(f[t], leaf_product(window[j & 1][k][t], terms[k].product.b + 8 * (4 * g + t))));
			}
			inverse_h1(f, Group(terms[0].product.inverse_roots, g));
#pragma GCC unroll 4
			for (std::size_t t = 0; t < 4; ++t) store(out + 8 * t, f[t]);
		}
	}
};

struct ForwardProductBottom {
	static constexpr bool kForward = true, kInverse = false;
	ProductBottom product;

	void operator()(std::uint32_t* a, std::size_t count, std::size_t first) const {
		const Factor undo_montgomery(kR);
		Window window[2][4];
		product.prepare(a, first, window[0]);
		for (std::size_t j = 0; j < count; ++j, a += 32) {
			if (j + 1 < count) product.prepare(a + 32, first + j + 1, window[(j + 1) & 1]);
			const std::uint32_t* b = product.b + 32 * (first + j);
#pragma GCC unroll 4
			for (int t = 0; t < 4; ++t)
				store(a + 8 * t, reduce(times(leaf_product(window[j & 1][t], b + 8 * t), undo_montgomery), kP));
		}
	}
};

template <class Bottom>
class Recursion {
public:
	Recursion(const std::uint32_t* roots, const std::uint32_t* inverse_roots, const Bottom& bottom)
		: r_(roots), ir_(inverse_roots), bottom_(bottom) {}

	void visit(std::uint32_t* a, std::size_t nv, std::size_t k) const {
		if (nv <= kTile) return tile(a, nv, k);
		const std::size_t h = nv / 4;
		if constexpr (Bottom::kForward) forward(a, h, k);
		for (std::size_t t = 0; t < 4; ++t) visit(a + 8 * t * h, h, 4 * k + t);
		if constexpr (Bottom::kInverse) inverse(a, h, k);
	}

	static constexpr bool radix8(std::size_t nv) { return nv / 2 > kTile; }

	void below(std::uint32_t* a, std::size_t nv, std::size_t k) const {
		const std::size_t h = nv / 4;
		for (std::size_t t = 0; t < 4; ++t) visit(a + 8 * t * h, h, 4 * k + t);
		if constexpr (Bottom::kInverse) inverse(a, h, k);
	}

private:
	static constexpr std::size_t kTile = 256;

	void tile(std::uint32_t* a, std::size_t nv, std::size_t k) const {
		if constexpr (Bottom::kForward) {
			for (std::size_t h = nv / 4; h >= 16; h /= 4)
				for (std::size_t j = 0, g = k * (nv / (4 * h)); j < nv; j += 4 * h, ++g) forward(a + 8 * j, h, g);
			if (nv >= 16) kernels::forward_h4(vectors(a), nv / 16, r_, k * (nv / 16));
		}
		bottom_(a, nv / 4, k * (nv / 4));
		if constexpr (Bottom::kInverse) {
			if (nv >= 16) kernels::inverse_h4(vectors(a), nv / 16, ir_, k * (nv / 16));
			for (std::size_t h = 16; h < nv; h *= 4)
				for (std::size_t j = 0, g = k * (nv / (4 * h)); j < nv; j += 4 * h, ++g) inverse(a + 8 * j, h, g);
		}
	}

	static Vec* vectors(std::uint32_t* a) { return reinterpret_cast<Vec*>(a); }

	void forward(std::uint32_t* a, std::size_t h, std::size_t k) const {
		if (k == 0) return blocked_ntt::kernels::forward_identity(vectors(a), h, r_);
		blocked_ntt::kernels::forward(vectors(a), h, r_ + slot(k), r_ + slot(2 * k));
	}

	void inverse(std::uint32_t* a, std::size_t h, std::size_t k) const {
		if (k == 0) return blocked_ntt::kernels::inverse_identity(vectors(a), h, ir_);
		blocked_ntt::kernels::inverse(vectors(a), h, ir_ + slot(k), ir_ + slot(2 * k));
	}

	const std::uint32_t *r_, *ir_;
	Bottom bottom_;
};

class Source {
public:
	Source(const std::uint32_t* in, std::size_t size, std::size_t shift)
		: in_(in), shift_(shift), end_(shift + size), first_((shift + 7) / 8), first_touched_(shift / 8) {
		count_ = end_ / 8 > first_ ? end_ / 8 - first_ : 0;
		touched_ = (end_ + 7) / 8 - first_touched_;
	}

	Vec operator()(std::size_t v) const {
		if (v - first_ < count_) return _mm256_loadu_si256(reinterpret_cast<const Vec*>(in_ + (8 * v - shift_)));
		if (v - first_touched_ >= touched_) return _mm256_setzero_si256();
		return edge(in_, shift_, end_, v);
	}

	bool in_place(const std::uint32_t* out) const { return in_ == out + shift_; }

	void zero_outside(std::uint32_t* out, std::size_t lo, std::size_t hi) const {
		const std::size_t begin = std::clamp(shift_, lo, hi), end = std::clamp(end_, begin, hi);
		std::fill(out + lo, out + begin, 0);
		std::fill(out + end, out + hi, 0);
	}


	bool within(std::size_t lo, std::size_t hi) const {
		return touched_ == 0 || (first_touched_ >= lo && first_touched_ + touched_ <= hi);
	}

private:

	[[gnu::noinline]] static Vec edge(const std::uint32_t* in, std::size_t shift, std::size_t end, std::size_t v) {
		alignas(32) std::uint32_t x[8] = {};
		for (std::size_t i = 8 * v; i < 8 * v + 8; ++i)
			if (i >= shift && i < end) x[i - 8 * v] = in[i - shift];
		return load(x);
	}

	const std::uint32_t* in_;
	std::size_t shift_, end_;
	std::size_t first_, count_;
	std::size_t first_touched_, touched_;
};

template <class Input>
[[gnu::always_inline]] inline void forward_top4_body(Input in, Vec* out, std::size_t h, const std::uint32_t* roots) {
	const Factor z(roots[1], roots[9]);
	const Vec p = broadcast(kP);
	if (in.within(0, 2 * h)) {
		for (std::size_t j = 0; j < h; ++j) {
			const Vec a = in(j), b = in(j + h), zb = times(b, z);
			out[j] = add(a, b), out[j + h] = diff(a, b), out[j + 2 * h] = add(a, zb), out[j + 3 * h] = diff(a, zb);
		}
		return;
	}
	if (in.within(2 * h, 4 * h)) {
		for (std::size_t j = 0; j < h; ++j) {
			const Vec c = in(j + 2 * h), d = in(j + 3 * h);
			const Vec mc = _mm256_sub_epi32(p, c), zmd = times(_mm256_sub_epi32(p, d), z);
			out[j] = add(c, d), out[j + h] = diff(c, d), out[j + 2 * h] = add(mc, zmd), out[j + 3 * h] = diff(mc, zmd);
		}
		return;
	}
	for (std::size_t j = 0; j < h; ++j) {
		const Vec a = in(j), b = in(j + h), c = in(j + 2 * h), d = in(j + 3 * h);
		const Vec ac = add(a, c), amc = _mm256_sub_epi32(add(a, p), c);
		const Vec bd = add(b, d), zbmd = times(_mm256_sub_epi32(add(b, p), d), z);
		out[j] = add(ac, bd), out[j + h] = diff(ac, bd);
		out[j + 2 * h] = add(amc, zbmd), out[j + 3 * h] = diff(amc, zbmd);
	}
}

template <class Input>
[[gnu::always_inline]] inline void forward_top2_body(Input in, Vec* out, std::size_t h) {
	const Vec p = broadcast(kP);
	if (in.within(0, h)) {
		for (std::size_t j = 0; j < h; ++j) out[j] = out[j + h] = in(j);
		return;
	}
	if (in.within(h, 2 * h)) {
		for (std::size_t j = 0; j < h; ++j) {
			const Vec v = in(j + h);
			out[j] = v, out[j + h] = _mm256_sub_epi32(p, v);
		}
		return;
	}
	for (std::size_t j = 0; j < h; ++j) {
		const Vec u = in(j), v = in(j + h);
		out[j] = add(u, v), out[j + h] = _mm256_sub_epi32(add(u, p), v);
	}
}

[[gnu::noinline]] inline void forward_top4(Source in, Vec* out, std::size_t h, const std::uint32_t* roots) {
	forward_top4_body(in, out, h, roots);
}
[[gnu::noinline]] inline void forward_top2(Source in, Vec* out, std::size_t h) {
	forward_top2_body(in, out, h);
}

inline bool forward_top8(const Source& in, std::uint32_t* a, std::size_t nv, const std::uint32_t* roots) {
	const bool lower = in.within(0, nv / 2);
	if (!in.in_place(a) || !(lower || in.within(nv / 2, nv))) return false;
	const std::size_t half = 4 * nv;
	in.zero_outside(a, lower ? 0 : half, lower ? half : 2 * half);
	auto* v = reinterpret_cast<Vec*>(a);
	if (lower) kernels::forward_top8_lower(v, nv / 8, roots);
	else kernels::forward_top8_upper(v, nv / 8, roots);
	return true;
}

template <class Bottom>
void radix2_halves(const Recursion<Bottom>& recursion, const Source& in, std::uint32_t* a, std::size_t nv,
				   const std::uint32_t* roots) {
	const std::size_t h = nv / 2;
	if constexpr (Bottom::kForward) {
		if (recursion.radix8(nv) && forward_top8(in, a, nv, roots)) {
			recursion.below(a, h, 0);
			recursion.below(a + 8 * h, h, 1);
			return;
		}
		forward_top2(in, reinterpret_cast<Vec*>(a), h);
	}
	recursion.visit(a, h, 0);
	recursion.visit(a + 8 * h, h, 1);
}

inline void inverse_top4(Vec* f, std::size_t h, Half output, const std::uint32_t* inverse_roots, const Factor& s) {
	if (output == Half::kBoth) return blocked_ntt::detail::inverse_radix4(f, h, inverse_roots, s);
	const Factor z(inverse_roots[1], inverse_roots[9]);
	const auto scale = [&s](Vec x) __attribute__((target("avx2"))) { return reduce(times(x, s), kP); };
	for (std::size_t j = 0; j < h; ++j) {
		const Vec p0 = f[j], p1 = f[j + h], p2 = f[j + 2 * h], p3 = f[j + 3 * h];
		const Vec ab = low(add(p0, p1)), cd = low(add(p2, p3));
		const Vec amb = low(diff(p0, p1)), cmd = times(diff(p2, p3), z);
		if (output == Half::kLower) {
			f[j] = scale(add(ab, cd)), f[j + h] = scale(add(amb, cmd));
		} else {
			f[j + 2 * h] = scale(diff(ab, cd)), f[j + 3 * h] = scale(diff(amb, cmd));
		}
	}
}

inline void inverse_top2(Vec* f, std::size_t h, Half output, std::uint32_t scale) {
	if (output == Half::kBoth) {
		alignas(32) std::uint32_t s[16] = {};
		s[1] = scale;
		s[9] = blocked_ntt::detail::quotient(scale);
		return blocked_ntt::kernels::scale_radix2(f, h, s);
	}
	const Factor s(scale);
	for (std::size_t j = 0; j < h; ++j) {
		if (output == Half::kLower) f[j] = reduce(times(add(f[j], f[j + h]), s), kP);
		else f[j + h] = reduce(times(diff(f[j], f[j + h]), s), kP);
	}
}

}

class Transform {
public:
	static constexpr int kMinLog = 6, kMaxLog = blocked_ntt::kMaxLog;

	static constexpr std::size_t words(int lg_max) { return Arena::footprint(2 * blocked_ntt::detail::table_words(lg_max)); }

	Transform(Arena& arena, int lg_max) : lg_max_(lg_max) {
		if (lg_max < kMinLog || lg_max > kMaxLog) std::abort();
		const std::size_t table = blocked_ntt::detail::table_words(lg_max), entries = (std::size_t(1) << lg_max) / 16;
		roots_ = arena.take(2 * table).data();
		std::fill_n(roots_, 2 * table, 0u);
		inverse_roots_ = roots_ + table;
		blocked_ntt::detail::build_table(roots_, entries, blocked_ntt::detail::kRoots[0]);
		blocked_ntt::detail::build_table(inverse_roots_, entries, blocked_ntt::detail::kRoots[1]);
	}

	int lg_max() const { return lg_max_; }

	const std::uint32_t* roots() const { return roots_; }
	const std::uint32_t* inverse_roots() const { return inverse_roots_; }

	void forward(std::span<const std::uint32_t> in, std::size_t shift, std::span<std::uint32_t> out) const {
		run(out, source(in, shift, out.size()), detail::ForwardBottom{roots_}, 0, Half::kBoth);
	}

	void forward(std::span<std::uint32_t> a) const { forward(a, 0, a); }

	void forward_upper(std::span<const std::uint32_t> in, std::size_t shift, std::span<std::uint32_t> out) const {
		using namespace detail;
		check_length(2 * out.size());
		const Source src = source(in, shift, out.size());
		const detail::Recursion recursion(roots_, inverse_roots_, ForwardBottom{roots_});
		const std::size_t nv = out.size() / 8;
		auto* v = reinterpret_cast<Vec*>(out.data());
		if (std::countr_zero(nv) % 2 == 0) {
			for (std::size_t j = 0; j < nv; ++j) v[j] = src(j);
			return recursion.visit(out.data(), nv, 1);
		}

		const std::size_t h = nv / 2;
		const Factor z(roots_[1], roots_[9]);
		for (std::size_t j = 0; j < h; ++j) {
			const Vec a = src(j), zb = times(src(j + h), z);
			v[j] = add(a, zb), v[j + h] = diff(a, zb);
		}
		recursion.visit(out.data(), h, 2);
		recursion.visit(out.data() + 8 * h, h, 3);
	}

	void inverse(std::span<const std::uint32_t> in, std::span<std::uint32_t> out, Half output = Half::kBoth) const {
		using namespace blocked_ntt::detail;
		const std::uint32_t scale = inverse_scale(out.size(), false);
		run(out, detail::Source(nullptr, 0, 0), detail::InverseBottom{inverse_roots_, in.data()}, scale, output);
	}

	void inverse(std::span<std::uint32_t> a, Half output = Half::kBoth) const { inverse(a, a, output); }

	void cyclic_product(std::span<const std::uint32_t> in, std::size_t shift, std::span<std::uint32_t> out,
						std::span<const std::uint32_t> b, Half output = Half::kBoth, std::uint32_t c = 1) const {
		using namespace blocked_ntt::detail;
		const std::uint32_t scale = multiply_mod(inverse_scale(out.size(), true), c);
		run(out, source(in, shift, out.size()), detail::ProductBottom{roots_, inverse_roots_, b.data()}, scale, output);
	}

	void cyclic_product(std::span<std::uint32_t> a, std::span<const std::uint32_t> b) const { cyclic_product(a, 0, a, b); }

	void inverse_product(std::span<const std::uint32_t> a, std::span<const std::uint32_t> b, std::span<std::uint32_t> out,
						Half output = Half::kBoth) const {
		using namespace blocked_ntt::detail;
		const std::uint32_t scale = inverse_scale(out.size(), true);
		const detail::ProductBottom product{roots_, inverse_roots_, b.data()};
		run(out, detail::Source(nullptr, 0, 0), detail::InverseProductBottom{product, a.data()}, scale, output);
	}

	struct Pair {
		std::span<const std::uint32_t> a, b;
	};

	void inverse_product_sum(std::span<const Pair> pairs, std::span<std::uint32_t> out, Half output = Half::kBoth) const {
		switch (pairs.size()) {
			case 1: return inverse_product(pairs[0].a, pairs[0].b, out, output);
			case 2: return inverse_products<2>(pairs, out, output);
			case 3: return inverse_products<3>(pairs, out, output);
			default: std::abort();
		}
	}

	template <class Bottom>
	void inverse_with(const Bottom& bottom, std::span<std::uint32_t> out, Half output = Half::kBoth) const {
		using namespace blocked_ntt::detail;
		const std::uint32_t scale = inverse_scale(out.size(), true);
		run(out, detail::Source(nullptr, 0, 0), bottom, scale, output);
	}

	void forward_product(std::span<const std::uint32_t> in, std::size_t shift, std::span<std::uint32_t> out,
						std::span<const std::uint32_t> b) const {
		const detail::ProductBottom product{roots_, inverse_roots_, b.data()};
		run(out, source(in, shift, out.size()), detail::ForwardProductBottom{product}, 0, Half::kBoth);
	}

	void multiply(std::span<std::uint32_t> a, std::span<const std::uint32_t> b) const {
		products(a.data(), a.data(), b.data(), a.size(), [&](detail::Vec, detail::Vec p) __attribute__((target("avx2"))) { return p; });
	}

	void multiply_add(std::span<std::uint32_t> c, std::span<const std::uint32_t> a,
					std::span<const std::uint32_t> b) const {
		products(c.data(), a.data(), b.data(), a.size(), [&](detail::Vec c, detail::Vec p) __attribute__((target("avx2"))) { return detail::add(c, p); });
	}

private:
	std::uint32_t inverse_scale(std::size_t n, bool montgomery) const {
		check_length(n);
		return detail::kInverseScales[montgomery][std::countr_zero(n)];
	}

	void check_length(std::size_t n) const {
		const int lg = std::countr_zero(n);
		if (!std::has_single_bit(n) || lg < kMinLog || lg > lg_max_) std::abort();
	}

	template <std::size_t K>
	void inverse_products(std::span<const Pair> pairs, std::span<std::uint32_t> out, Half output) const {
		using namespace blocked_ntt::detail;
		const std::uint32_t scale = inverse_scale(out.size(), true);
		detail::InverseProductSumBottom<K> bottom{};
		for (std::size_t k = 0; k < K; ++k) bottom.terms[k] = {{roots_, inverse_roots_, pairs[k].b.data()}, pairs[k].a.data()};
		run(out, detail::Source(nullptr, 0, 0), bottom, scale, output);
	}

	static detail::Source source(std::span<const std::uint32_t> in, std::size_t shift, std::size_t n) {
		if (shift > n || in.size() > n - shift) std::abort();
		return detail::Source(in.data(), in.size(), shift);
	}

	template <class Bottom>
	void run(std::span<std::uint32_t> a, const detail::Source& in, const Bottom& bottom, std::uint32_t scale,
			Half output) const {
		using namespace detail;
		check_length(a.size());
		const detail::Recursion recursion(roots_, inverse_roots_, bottom);
		const std::size_t nv = a.size() / 8;
		auto* v = reinterpret_cast<Vec*>(a.data());
		if (std::countr_zero(nv) % 2 == 0) {
			const std::size_t h = nv / 4;
			if constexpr (Bottom::kForward) forward_top4(in, v, h, roots_);
			for (std::size_t t = 0; t < 4; ++t) recursion.visit(a.data() + 8 * t * h, h, t);
			if constexpr (Bottom::kInverse) inverse_top4(v, h, output, inverse_roots_, Factor(scale));
		} else {
			const std::size_t h = nv / 2;
			radix2_halves(recursion, in, a.data(), nv, roots_);
			if constexpr (Bottom::kInverse) inverse_top2(v, h, output, scale);
		}
	}

	template <class Combine>
	void products(std::uint32_t* out, const std::uint32_t* a, const std::uint32_t* b, std::size_t n, Combine combine) const {
		using namespace detail;
		check_length(n);
		const Factor undo_montgomery(kR);
		Window window[2];
		fill_window(window[0], load(a), leaf_weight(roots_, 0));
		for (std::size_t p = 0; p < n / 8; ++p) {
			if (p + 1 < n / 8) fill_window(window[(p + 1) & 1], load(a + 8 * p + 8), leaf_weight(roots_, p + 1));
			const Vec product = reduce(times(leaf_product(window[p & 1], b + 8 * p), undo_montgomery), kP);
			store(out + 8 * p, canonical(combine(load(out + 8 * p), product)));
		}
	}

	int lg_max_;
	std::uint32_t *roots_, *inverse_roots_;
};

}

namespace blocked_poly {

namespace detail {

inline Vec load_unaligned(const std::uint32_t* p) { return _mm256_loadu_si256(reinterpret_cast<const Vec*>(p)); }
inline void store_unaligned(std::uint32_t* p, Vec x) { _mm256_storeu_si256(reinterpret_cast<Vec*>(p), x); }

inline Vec montgomery(Vec a, Vec b) {
	const Vec ni = broadcast(blocked_ntt::kernels::kNI), p = broadcast(kP);
	Vec even = _mm256_mul_epu32(a, b);
	Vec odd = _mm256_mul_epu32(_mm256_srli_epi64(a, 32), _mm256_srli_epi64(b, 32));
	even = _mm256_add_epi64(even, _mm256_mul_epu32(_mm256_mul_epu32(even, ni), p));
	odd = _mm256_add_epi64(odd, _mm256_mul_epu32(_mm256_mul_epu32(odd, ni), p));
	return _mm256_blend_epi32(_mm256_srli_epi64(even, 32), odd, 0xAA);
}

class Indices {
public:
	explicit Indices(std::size_t k) {
		alignas(32) std::uint32_t x[8];
		for (std::uint32_t i = 0; i < 8; ++i) x[i] = std::uint32_t((std::uint64_t(k + i) << 32) % kP);
		value_ = load(x);
	}

	Vec value() const { return value_; }
	void next() { value_ = reduce(add(value_, broadcast(kStep)), kP); }

private:
	static constexpr std::uint32_t kStep = std::uint32_t((std::uint64_t(8) << 32) % kP);
	Vec value_;
};

inline std::uint32_t scalar_inverse(std::uint32_t x) { return blocked_ntt::detail::power(x, kP - 2); }

template <class A>
void divide_by_index(std::size_t first, std::span<std::uint32_t> out, const A& a, std::uint32_t factor = 1) {
	constexpr std::size_t kLanes = 32;
	const std::size_t n = out.size();
	if (n == 0) return;
	const std::size_t blocks = (n + kLanes - 1) / kLanes, last = kLanes * (blocks - 1);
	const Vec one = broadcast(1), step = broadcast(kLanes);

	Vec x[4];
	for (int v = 0; v < 4; ++v)
		x[v] = _mm256_add_epi32(broadcast(std::uint32_t(first + 8 * v)), _mm256_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7));
	const auto valid = [n](std::size_t at) __attribute__((target("avx2"))) {
		const Vec lanes = _mm256_add_epi32(broadcast(std::uint32_t(at)), _mm256_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7));
		return _mm256_cmpgt_epi32(broadcast(std::uint32_t(n)), lanes);
	};
	const auto masked = [&](Vec value, std::size_t at) __attribute__((target("avx2"))) { return at + 8 <= n ? value : _mm256_blendv_epi8(one, value, valid(at)); };

	Vec prefix[4];
	for (int v = 0; v < 4; ++v) prefix[v] = masked(x[v], 8 * v);
	for (std::size_t b = kLanes; b < n; b += kLanes) {
		for (int v = 0; v < 4; ++v) {
			store_unaligned(out.data() + b - kLanes + 8 * v, prefix[v]);
			x[v] = _mm256_add_epi32(x[v], step);
			prefix[v] = montgomery(prefix[v], masked(x[v], b + 8 * v));
		}
	}

	alignas(32) std::uint32_t total[kLanes], inverse[kLanes];
	for (int v = 0; v < 4; ++v) store(total + 8 * v, canonical(prefix[v]));
	std::uint32_t running = 1;
	for (std::size_t l = 0; l < kLanes; ++l) {
		inverse[l] = running;
		running = blocked_ntt::detail::multiply_mod(running, total[l]);
	}
	running = blocked_ntt::detail::multiply_mod(scalar_inverse(running), blocked_ntt::detail::multiply_mod(kR, factor));
	for (std::size_t l = kLanes; l-- > 0;) {
		inverse[l] = blocked_ntt::detail::multiply_mod(inverse[l], running);
		running = blocked_ntt::detail::multiply_mod(running, total[l]);
	}

	Vec inv[4];
	for (int v = 0; v < 4; ++v) inv[v] = load(inverse + 8 * v);
	const auto put = [&](std::size_t at, Vec reciprocal) __attribute__((target("avx2"))) {
		const Vec q = canonical(montgomery(reciprocal, a(at)));
		if (at + 8 <= n) return store_unaligned(out.data() + at, q);
		_mm256_maskstore_epi32(reinterpret_cast<int*>(out.data() + at), valid(at), q);
	};
	for (std::size_t b = last; b > 0; b -= kLanes) {
		for (int v = 0; v < 4; ++v) {
			const std::size_t at = b + 8 * v;
			if (at < n) put(at, montgomery(load_unaligned(out.data() + at - kLanes), inv[v]));
			inv[v] = montgomery(inv[v], masked(x[v], at));
			x[v] = _mm256_sub_epi32(x[v], step);
		}
	}
	for (int v = 0; v < 4; ++v)
		if (8 * std::size_t(v) < n) put(8 * v, inv[v]);
}

}

inline void derivative(std::span<const std::uint32_t> f, std::span<std::uint32_t> d) {
	using namespace detail;
	const std::size_t n = d.size(), full = std::min(n, f.size() > 0 ? f.size() - 1 : 0) / 8 * 8;
	Indices index(1);
	for (std::size_t i = 0; i < full; i += 8, index.next())
		store_unaligned(d.data() + i, canonical(montgomery(load_unaligned(f.data() + i + 1), index.value())));
	for (std::size_t i = full; i < n; ++i)
		d[i] = i + 1 < f.size() ? blocked_ntt::detail::multiply_mod(std::uint32_t(i + 1), f[i + 1]) : 0;
}

inline void divide_by_index(std::span<const std::uint32_t> a, std::size_t first, std::span<std::uint32_t> q) {
	if (a.size() != q.size() || first == 0 || first + a.size() > kModulus) std::abort();
	const std::size_t n = a.size();
	detail::divide_by_index(first, q, [a, n](std::size_t at) __attribute__((target("avx2"))) {
		if (at + 8 <= n) return detail::load_unaligned(a.data() + at);
		alignas(32) std::uint32_t rest[8] = {};
		std::copy(a.begin() + at, a.end(), rest);
		return detail::load(rest);
	});
}

}

#include <algorithm>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <span>

namespace blocked_poly {

namespace detail {

inline constexpr std::size_t kInverseBase = 32;

inline void inverse_direct(std::span<const std::uint32_t> f, std::span<std::uint32_t> g) {
	using blocked_ntt::detail::multiply_mod;
	const std::uint32_t inv0 = blocked_ntt::detail::power(f[0], kP - 2);
	g[0] = inv0;
	for (std::size_t i = 1; i < g.size(); ++i) {
		std::uint64_t sum = 0;
		for (std::size_t j = 1; j <= std::min(i, f.size() - 1); ++j) {
			sum += std::uint64_t(f[j]) * g[i - j] % kP;
		}
		g[i] = multiply_mod(std::uint32_t(sum % kP ? kP - sum % kP : 0), inv0);
	}
}

}

inline int inverse_log(std::size_t n) {
	return std::max(Transform::kMinLog, int(std::bit_width(std::max<std::size_t>(n, 2) - 1)));
}

inline std::size_t inverse_scratch(std::size_t n) { return 2 * Arena::footprint(std::size_t(1) << inverse_log(n)); }

inline void inverse_step(const Transform& t, std::span<const std::uint32_t> f, std::span<const std::uint32_t> g,
						std::span<std::uint32_t> to, std::span<std::uint32_t> gt, std::span<std::uint32_t> work) {
	const std::size_t k = g.size();
	t.forward(g, 0, gt);
	t.cyclic_product(f.first(std::min(2 * k, f.size())), 0, work, gt, Half::kUpper);
	t.cyclic_product(work.subspan(k), k, work, gt, Half::kUpper, detail::kP - 1);
	if (to.data() != work.data() + k) std::copy_n(work.begin() + std::ptrdiff_t(k), to.size(), to.begin());
}

inline void inverse(const Transform& t, std::span<const std::uint32_t> f, std::span<std::uint32_t> g,
					std::span<std::uint32_t> scratch) {
	const std::size_t n = g.size();
	std::size_t k = std::min(n, detail::kInverseBase);
	detail::inverse_direct(f, g.first(k));
	for (; k < n; k *= 2) {
		const std::size_t len = 2 * k;
		inverse_step(t, f, g.first(k), g.subspan(k, std::min(k, n - k)), scratch.first(len),
					scratch.subspan(Arena::footprint(len), len));
	}
}

}

namespace blocked_poly {

namespace detail {

inline constexpr std::size_t kLogBase = 64;

inline constexpr std::size_t kLogBlocks = 4;

inline void log_direct(std::span<const std::uint32_t> f, std::span<std::uint32_t> g) {
	using blocked_ntt::detail::multiply_mod;
	std::uint32_t a[kLogBase] = {}, inv[kLogBase] = {0, 1}, kg[kLogBase] = {};
	std::copy_n(f.begin(), std::min(f.size(), g.size()), a);
	for (std::size_t i = 2; i < g.size(); ++i) inv[i] = multiply_mod(kP - kP / std::uint32_t(i), inv[kP % i]);
	g[0] = 0;
	for (std::size_t i = 1; i < g.size(); ++i) {
		std::uint64_t sum = multiply_mod(std::uint32_t(i), a[i]);
		for (std::size_t k = 1; k < i; ++k) sum += kP - std::uint64_t(kg[k]) * a[i - k] % kP;
		kg[i] = std::uint32_t(sum % kP);
		g[i] = multiply_mod(kg[i], inv[i]);
	}
}

inline std::size_t log_block(std::size_t n) {
	return std::max<std::size_t>(32, std::bit_ceil((n - 1 + kLogBlocks - 1) / kLogBlocks));
}

inline std::size_t log_blocks(std::size_t n) { return (n - 1 + log_block(n) - 1) / log_block(n); }

inline void subtract_from_derivative(std::span<const std::uint32_t> f, std::size_t first, std::size_t count,
									std::uint32_t* out, std::size_t size) {
	const std::size_t inside = f.size() > first + 1 ? std::min(count, f.size() - first - 1) : 0, full = inside / 8 * 8;
	Indices index(first + 1);
	for (std::size_t c = 0; c < full; c += 8, index.next()) {
		const Vec d = canonical(montgomery(load_unaligned(f.data() + first + 1 + c), index.value()));
		store_unaligned(out + c, reduce(_mm256_sub_epi32(add(d, broadcast(kP)), load_unaligned(out + size + c)), kP));
	}
	for (std::size_t c = full; c < count; ++c) {
		const std::uint32_t d = c < inside ? blocked_ntt::detail::multiply_mod(std::uint32_t(first + 1 + c), f[first + 1 + c]) : 0;
		out[c] = (d + kP - out[size + c]) % kP;
	}
}

struct ToeplitzBottom {
	static constexpr bool kForward = false, kInverse = true;
	const std::uint32_t *roots, *inverse_roots, *w1, *w2, *q0, *q1;
	std::uint32_t* w3;

	[[gnu::always_inline]] void prepare(std::size_t g, Window (&window)[3][4]) const {
		Vec sum[4], d1[4], d3[4];
#pragma GCC unroll 4
		for (std::size_t t = 0; t < 4; ++t) {
			const std::size_t leaf = 8 * (4 * g + t);
			const Vec v2 = load(w2 + leaf);
			sum[t] = reduce(add(load(q0 + leaf), load(q1 + leaf)), kP);
			d1[t] = difference(load(w1 + leaf), v2);
			d3[t] = difference(load(w3 + leaf), v2);
		}
		fill_windows(window[0], sum, roots, g);
		fill_windows(window[1], d1, roots, g);
		fill_windows(window[2], d3, roots, g);
	}

	void operator()(std::uint32_t* out, std::size_t count, std::size_t first) const {
		Window window[2][3][4];
		prepare(first, window[0]);
		for (std::size_t j = 0; j < count; ++j, out += 32) {
			if (j + 1 < count) prepare(first + j + 1, window[(j + 1) & 1]);
			const std::size_t g = first + j;
			const auto& w = window[j & 1];
			Vec f[4];
#pragma GCC unroll 4
			for (std::size_t t = 0; t < 4; ++t) {
				const std::size_t leaf = 8 * (4 * g + t);
				const Vec m1 = leaf_product(w[0][t], w2 + leaf);
				f[t] = low(add(m1, leaf_product(w[1][t], q1 + leaf)));
				store(w3 + leaf, low(add(m1, leaf_product(w[2][t], q0 + leaf))));
			}
			inverse_h1(f, Group(inverse_roots, g));
#pragma GCC unroll 4
			for (std::size_t t = 0; t < 4; ++t) store(out + 8 * t, f[t]);
		}
	}
};

struct SideProductBottom {
	static constexpr bool kForward = false, kInverse = true;
	InverseProductBottom term;
	const std::uint32_t* side;

	void operator()(std::uint32_t* out, std::size_t count, std::size_t first) const {
		Window window[2][4];
		term.prepare(first, window[0]);
		for (std::size_t j = 0; j < count; ++j, out += 32) {
			if (j + 1 < count) term.prepare(first + j + 1, window[(j + 1) & 1]);
			const std::size_t g = first + j;
			Vec f[4];
#pragma GCC unroll 4
			for (std::size_t t = 0; t < 4; ++t) {
				const std::size_t leaf = 8 * (4 * g + t);
				f[t] = low(add(leaf_product(window[j & 1][t], term.product.b + leaf), load(side + leaf)));
			}
			inverse_h1(f, Group(term.product.inverse_roots, g));
#pragma GCC unroll 4
			for (std::size_t t = 0; t < 4; ++t) store(out + 8 * t, f[t]);
		}
	}
};

inline std::size_t log_buffers(std::size_t n) { return std::max<std::size_t>(log_blocks(n) + 2, 3); }

inline unsigned mint_scalar(Mint x) { return std::min(x.v, x.v - Mint::mod()); }
inline Vec mint_load(std::span<const Mint> f, std::size_t at) {
	if (at + 8 <= f.size()) {
		Vec value;
		std::memcpy(&value, f.data() + at, sizeof(value));
		return reduce(value, kP);
	}
	alignas(32) unsigned values[8] = {};
	for (std::size_t i = 0; i < 8 && at + i < f.size(); ++i) values[i] = mint_scalar(f[at + i]);
	return load(values);
}
class MintSource {
public:
	explicit MintSource(std::span<const Mint> f) : f_(f), full_(f.size() / 8), touched_((f.size() + 7) / 8) {}
	Vec operator()(std::size_t v) const {
		if (v < full_) {
			Vec value;
			std::memcpy(&value, f_.data() + 8 * v, sizeof(value));
			return reduce(value, kP);
		}
		if (v >= touched_) return _mm256_setzero_si256();
		return edge(f_, 8 * v);
	}
	bool within(std::size_t lo, std::size_t hi) const { return touched_ == 0 || (lo == 0 && touched_ <= hi); }
private:
	[[gnu::noinline]] static Vec edge(std::span<const Mint> f, std::size_t at) { return mint_load(f, at); }
	std::span<const Mint> f_;
	std::size_t full_, touched_;
};
[[gnu::noinline]] inline void mint_forward_top4(MintSource in, Vec* out, std::size_t h, const std::uint32_t* roots) {
	forward_top4_body(in, out, h, roots);
}
[[gnu::noinline]] inline void mint_forward_top2(MintSource in, Vec* out, std::size_t h) {
	forward_top2_body(in, out, h);
}

inline void mint_forward(const Transform& t, std::span<const Mint> f, std::span<std::uint32_t> out) {
	const MintSource in(f);
	const detail::Recursion recursion(t.roots(), t.inverse_roots(), ForwardBottom{t.roots()});
	const std::size_t nv = out.size() / 8;
	auto* v = reinterpret_cast<Vec*>(out.data());
	if (std::countr_zero(nv) % 2 == 0) {
		const std::size_t h = nv / 4;
		mint_forward_top4(in, v, h, t.roots());
		for (std::size_t q = 0; q < 4; ++q) recursion.visit(out.data() + 8 * q * h, h, q);
	} else {
		const std::size_t h = nv / 2;
		mint_forward_top2(in, v, h);
		recursion.visit(out.data(), h, 0);
		recursion.visit(out.data() + 8 * h, h, 1);
	}
}
inline void mint_derivative(std::span<const Mint> f, std::span<std::uint32_t> d) {
	using namespace detail;
	const std::size_t n = d.size(), full = std::min(n, f.size() > 0 ? f.size() - 1 : 0) / 8 * 8;
	Indices index(1);
	for (std::size_t i = 0; i < full; i += 8, index.next())
		store_unaligned(d.data() + i, canonical(montgomery(mint_load(f, i + 1), index.value())));
	for (std::size_t i = full; i < n; ++i)
		d[i] = i + 1 < f.size() ? blocked_ntt::detail::multiply_mod(std::uint32_t(i + 1), mint_scalar(f[i + 1])) : 0;
}

inline void mint_subtract_from_derivative(std::span<const Mint> f, std::size_t first, std::size_t count,
									std::uint32_t* out, std::size_t size) {
	const std::size_t inside = f.size() > first + 1 ? std::min(count, f.size() - first - 1) : 0, full = inside / 8 * 8;
	Indices index(first + 1);
	for (std::size_t c = 0; c < full; c += 8, index.next()) {
		const Vec d = canonical(montgomery(mint_load(f, first + 1 + c), index.value()));
		store_unaligned(out + c, reduce(_mm256_sub_epi32(add(d, broadcast(kP)), load_unaligned(out + size + c)), kP));
	}
	for (std::size_t c = full; c < count; ++c) {
		const std::uint32_t d = c < inside ? blocked_ntt::detail::multiply_mod(std::uint32_t(first + 1 + c), mint_scalar(f[first + 1 + c])) : 0;
		out[c] = (d + kP - out[size + c]) % kP;
	}
}

struct NoLogTransform {
	void operator()(std::size_t, std::span<const std::uint32_t>) const {}
};

template <class Input, class Sink, class Transformed>
[[gnu::always_inline]] inline void log_derivative_impl(const Transform& t, Input f, std::size_t n,
												std::span<std::uint32_t> scratch, std::span<const std::uint32_t> prefix, const Sink& sink, const Transformed& transformed = {}) {
	const std::size_t k = log_block(n), len = 2 * k, blocks = log_blocks(n);
	const auto buffer = [&scratch, len](std::size_t i) __attribute__((target("avx2"))) { return scratch.subspan(i * Arena::footprint(len), len); };
	const std::span<std::uint32_t> ht = buffer(0), q0 = buffer(blocks);
	const auto window = [&buffer](std::size_t t) __attribute__((target("avx2"))) { return buffer(t); };

	inverse(t, prefix, ht.first(k), scratch.subspan(Arena::footprint(len), inverse_scratch(k)));
	t.forward(ht.first(k), 0, ht);
	for (std::size_t s = 1; s < blocks; ++s) {
		const std::size_t from = std::min(f.size(), (s - 1) * k);
		if constexpr (std::is_same_v<Input, std::span<const Mint>>) mint_forward(t, f.subspan(from, std::min(f.size() - from, len)), window(s));
		else t.forward(f.subspan(from, std::min(f.size() - from, len)), 0, window(s));
	}
	for (std::size_t j = 0; j < blocks; ++j) {
		const std::size_t first = j * k, count = std::min(k, n - 1 - first);
		const std::span<std::uint32_t> work = j == 0 ? q0 : buffer(blocks + 1);
		if (j == 0) {
			if constexpr (std::is_same_v<Input, std::span<const Mint>>) mint_derivative(f.first(std::min(f.size(), count + 1)), work.first(count));
			else derivative(f.first(std::min(f.size(), count + 1)), work.first(count));
		} else {
			if (j == 1) {
				t.inverse_product(window(1), q0, work, Half::kUpper);
			} else if (blocks == 3) {
				const Transform::Pair pairs[2] = {{window(2), q0}, {window(1), work}};
				t.inverse_product_sum(pairs, work, Half::kUpper);
			} else if (j == 2) {
				t.inverse_with(ToeplitzBottom{t.roots(), t.inverse_roots(), window(1).data(), window(2).data(), q0.data(),
											work.data(), window(3).data()},
							work, Half::kUpper);
			} else {
				const InverseProductBottom product{{t.roots(), t.inverse_roots(), work.data()}, window(1).data()};
				t.inverse_with(SideProductBottom{product, window(3).data()}, work, Half::kUpper);
			}
			if constexpr (std::is_same_v<Input, std::span<const Mint>>) mint_subtract_from_derivative(f, first, count, work.data(), k);
			else subtract_from_derivative(f, first, count, work.data(), k);
		}
		t.cyclic_product(work.first(count), 0, work, ht, Half::kLower);
		sink(first, std::span<const std::uint32_t>(work.first(count)));
		if (j + 1 < blocks) {
			t.forward(work.first(k), 0, work);
			transformed(j, std::span<const std::uint32_t>(work));
		}
	}
}

template <class Sink, class Transformed = NoLogTransform>
[[gnu::always_inline]] inline void log_derivative(const Transform& t, std::span<const std::uint32_t> f, std::size_t n,
		std::span<std::uint32_t> scratch, const Sink& sink, const Transformed& transformed = {}) {
	log_derivative_impl(t, f, n, scratch, f, sink, transformed);
}

template <class Sink, class Transformed = NoLogTransform>
[[gnu::always_inline]] inline void mint_log_derivative(const Transform& t, std::span<const Mint> f, std::size_t n,
		std::span<std::uint32_t> scratch, std::span<const std::uint32_t> prefix, const Sink& sink, const Transformed& transformed = {}) {
	log_derivative_impl(t, f, n, scratch, prefix, sink, transformed);
}

inline int log_derivative_log(std::size_t n) { return std::countr_zero(2 * log_block(n)); }

inline std::size_t log_derivative_scratch(std::size_t n) { return log_buffers(n) * Arena::footprint(2 * log_block(n)); }

}

inline int log_log(std::size_t n) {
	return n <= detail::kLogBase ? Transform::kMinLog : std::countr_zero(2 * detail::log_block(n));
}

inline std::size_t log_scratch(std::size_t n) {
	return n <= detail::kLogBase ? 0 : detail::log_buffers(n) * Arena::footprint(2 * detail::log_block(n));
}

inline void log(const Transform& t, std::span<const std::uint32_t> f, std::span<std::uint32_t> g,
				std::span<std::uint32_t> scratch) {
	using namespace detail;
	const std::size_t n = g.size();
	if (n <= kLogBase) return log_direct(f, g);
	log_derivative(t, f, n, scratch, [g](std::size_t first, std::span<const std::uint32_t> q) __attribute__((target("avx2"))) {
		detail::divide_by_index(first + 1, g.subspan(first + 1, q.size()), [q](std::size_t i) __attribute__((target("avx2"))) { return load(q.data() + i); });
	});
	g[0] = 0;
}

}

namespace blocked_poly {
inline void native_log(const Mint *in, std::size_t input, std::vector<Mint> &out, std::size_t n, bool integrate) {
	prepare_fps_output(out, n);
	out.emplace_back(0);
	const std::size_t c = std::min(input, n);
	const int lg = detail::log_derivative_log(n);
	const bool direct = n >= 262144;
	const auto prefix_size = direct ? std::min(c, detail::log_block(n)) : c;
	Arena arena(Transform::words(lg) + Arena::footprint(prefix_size) + Arena::footprint(log_scratch(n)));
	const Transform t(arena, lg);
	auto f = arena.take(prefix_size), scratch = arena.take(log_scratch(n));
	for (std::size_t i = 0; i < prefix_size; ++i) {
		const unsigned v = in[i].v;
		f[i] = std::min(v, v - Mint::mod());
	}
	const auto sink = [&out, integrate, n](std::size_t first, std::span<const std::uint32_t> q) __attribute__((target("avx2"))) {
		if (integrate) {
			auto *work = const_cast<std::uint32_t *>(q.data()) + detail::log_block(n);
			detail::divide_by_index(first + 1, {work, q.size()}, [q](std::size_t i) __attribute__((target("avx2"))) { return detail::load(q.data() + i); }, blocked_ntt::detail::kR);
		}
		const auto *values = integrate ? q.data() + detail::log_block(n) : q.data();
		if (integrate) append_fps_words<true>(out, values, q.size());
		else append_fps_words<false>(out, values, q.size());
	};
	if (direct) detail::mint_log_derivative(t, {in, c}, n, scratch, f, sink);
	else detail::log_derivative(t, f, n, scratch, sink);
}
}
}
#pragma GCC pop_options
#endif
#endif
