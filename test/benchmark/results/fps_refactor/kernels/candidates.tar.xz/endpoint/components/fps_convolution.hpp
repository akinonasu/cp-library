#ifndef CP_COMPONENTS_FPS_CONVOLUTION_HPP
#define CP_COMPONENTS_FPS_CONVOLUTION_HPP
#include "fps_asm.hpp"
#include "fps_blocked.hpp"
#include "fps_output.hpp"
#include "fps_convolution_unbalanced.hpp"
#include "fps_convolution_constant.hpp"
#include <algorithm>
#include <bit>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <vector>

#if defined(__linux__) && defined(__x86_64__) && defined(__GNUC__) && !defined(__clang__)
#pragma GCC push_options
#pragma GCC optimize("O3")
_Pragma("GCC target(\"avx2\")")

namespace fps_detail::multiply_detail {
namespace ntt::kernels {
using namespace blocked_ntt::kernels;
inline void forward_pair(Vec* a, Vec* b, std::size_t h, const std::uint32_t* x, const std::uint32_t* y) {
	alignas(32) Vec w[3];
	Vec* const end = a + h;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T) \
R(%[P],z) R(%[P2],r) D((%[x]),c) m(c,G)\
D(32(%[x]),w)\
D((%[y]),c)\
m(c,L)\
D(32(%[y]),E)\
D(4(%[y]),c)\
m(c,M)\
D(36(%[y]),F)\
".p2align 5\n\t" \
"1:\n\t" \
m(H,c)\
m(J,d)\
m(N,f)\
m(O,g)\
q(H,w,i)\
q(J,w,t)\
m(I,l)\
q(4(%[a],%[h3]),w,e)\
q(4(%[b],%[h3]),w,j)\
m(K,n)\
m((%[a]),v)\
u(s,i,i)\
u(s,t,t)\
B(A,e,i,e)\
B(A,j,t,j)\
m((%[b]),t)\
q(I,w,i)\
p(z,e,e)\
p(z,j,j)\
p(G,c,c)\
p(G,d,d)\
u(s,i,i)\
p(G,l,l)\
k(e,c,e)\
k(j,d,j)\
p(G,n,n)\
k(r,f,d)\
C(d,f,d)\
k(r,g,f)\
q(K,w,c)\
C(f,g,f)\
q(4(%[a],%[h],2),w,g)\
u(s,c,c)\
B(A,g,i,g)\
q(4(%[b],%[h],2),w,i)\
p(z,g,g)\
B(A,i,c,i)\
o(r,d,c)\
o(e,d,d)\
k(e,c,e)\
p(z,i,i)\
k(g,l,g)\
o(r,f,l)\
o(j,f,f)\
k(j,l,j)\
u(s,d,l)\
q(E,d,c)\
q(E,l,l)\
p(L,d,d)\
k(i,n,i)\
u(s,e,n)\
q(F,n,n)\
u(s,c,c)\
B(A,l,c,l)\
q(F,e,c)\
p(M,e,e)\
p(z,l,l)\
u(s,c,c)\
B(A,n,c,n)\
k(l,d,l)\
u(s,f,d)\
q(E,f,c)\
q(E,d,d)\
p(z,n,n)\
p(L,f,f)\
u(s,c,c)\
B(A,d,c,d)\
k(n,e,n)\
u(s,j,e)\
q(F,j,c)\
q(F,e,e)\
p(z,d,d)\
p(M,j,j)\
u(s,c,c)\
B(A,e,c,e)\
k(d,f,d)\
k(r,v,f)\
k(r,t,c)\
C(f,v,f)\
C(c,t,c)\
p(z,e,e)\
o(g,f,t)\
k(g,f,g)\
o(i,c,f)\
k(i,c,i)\
k(r,t,c)\
o(r,g,v)\
C(c,t,c)\
C(v,g,v)\
k(e,j,e)\
k(r,f,j)\
o(r,i,g)\
C(j,f,j)\
o(r,c,f)\
o(r,v,t)\
C(g,i,g)\
o(l,c,c)\
k(l,f,l)\
o(n,v,v)\
o(r,j,f)\
o(r,g,i)\
k(n,t,n)\
o(d,j,j)\
m(c,(%[a]))\
k(d,f,d)\
o(e,g,g)\
k(e,i,e)\
m(l,N)\
m(v,I)\
m(n,H)\
m(j,(%[b]))\
m(d,O)\
m(g,K)\
m(e,J)\
Q(s,%[b])\
Q(s,%[a])\
S(%[end],%[a])\
T(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm0,%%ymm1,%%ymm7,%%ymm2,%%ymm3,%%ymm4,%%ymm8,CP_FPS_ASM_VPSUBD,%%ymm6,CP_FPS_ASM_VMOVDQA,%%ymm9,CP_FPS_ASM_VPADDD,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,%%ymm14,$32,%%ymm5,CP_FPS_ASM_VPSRLQ,%%ymm10,%%ymm11,%%ymm15,$170,CP_FPS_ASM_VPBLENDD,CP_FPS_ASM_VPMINUD,CP_FPS_ASM_VBROADCASTSS,%%ymm12,%%ymm13,(%[w]),(%[a],%[h3]),(%[a],%[h],2),(%[b],%[h3]),(%[b],%[h],2),32(%[w]),64(%[w]),(%[a],%[h]),(%[b],%[h]),CP_FPS_ASM_ADD,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a), [b] "+r"(b)
		: [end] "r"(end), [h] "r"(32 * h), [h3] "r"(96 * h), [y] "r"(y), [x] "r"(x), [w] "r"(w), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}





inline void bottom_both(const void* a, const void* b, void* buf, const void* x, const void* y, const void* w, void* out, const void* cur, const void* ix, const void* iy) {
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,x,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U,V,W,X,Y,Z,_0,_1,_2,_3,_4,_5,_6,_7,_8,_9,_10,_11,_12,_13,_14,_15,_16,_17,_18,_19,_20,_21,_22,_23,_24,_25,_26,_27,_28,_29,_30,_31) \
M(%[P],t) M(%[P2],v) M(%[NI],G) C(32(%[a]),k)\
z(36(%[cur]),d)\
f(S,j)\
f(H,n)\
f(H,e)\
f(I,o)\
C(32(%[cur]),c)\
f(S,m)\
C((%[a]),s)\
q(v,k,h)\
u(h,k,h)\
f(T,k)\
g(j,d,j)\
g(_28,n,n)\
f(H,d)\
g(68(%[a]),e,e)\
z(28(%[cur]),i)\
f(T,l)\
g(m,c,m)\
B(x,n,n)\
A(_28,o,o)\
q(v,s,r)\
F(E,e,n,e)\
u(r,s,r)\
f(U,s)\
f(H,n)\
A(t,e,e)\
g(k,c,k)\
q(e,o,e)\
z(24(%[cur]),o)\
f(U,c)\
g(_30,d,d)\
g(l,i,l)\
p(k,j,k)\
f(I,j)\
g(s,i,s)\
g(100(%[a]),n,n)\
B(x,d,d)\
f(V,i)\
p(l,m,l)\
z(20(%[cur]),m)\
p(s,k,s)\
F(E,n,d,n)\
f(V,d)\
D(e,r,k)\
A(t,n,n)\
q(e,r,e)\
q(v,k,r)\
g(c,o,c)\
u(r,k,r)\
f(W,k)\
A(_30,j,j)\
g(i,o,i)\
p(c,l,c)\
z(16(%[cur]),l)\
D(v,e,o)\
u(o,e,o)\
f(W,e)\
q(n,j,n)\
f(X,j)\
g(d,m,d)\
p(i,s,i)\
D(v,h,s)\
D(n,h,h)\
q(n,s,n)\
f(X,s)\
g(k,m,k)\
z(12(%[cur]),m)\
p(d,c,d)\
f(K,c)\
p(k,i,k)\
f(Z,i)\
g(e,l,e)\
g(j,l,j)\
f(K,l)\
p(e,d,e)\
z(8(%[cur]),d)\
g(s,m,s)\
p(j,k,j)\
f(Z,k)\
g(c,h,c)\
g(i,m,i)\
p(s,e,s)\
f(_0,e)\
f((%[y]),m)\
B(x,c,c)\
p(i,j,i)\
z(4(%[cur]),j)\
g(k,d,k)\
p(k,s,k)\
g(e,d,e)\
A(m,h,m)\
f(_0,d)\
B(x,n,s)\
B(x,h,h)\
g(l,h,l)\
f(L,h)\
p(e,i,e)\
f(L,i)\
F(E,l,c,l)\
g(G,e,c)\
A(t,l,l)\
g(d,j,d)\
g(t,c,c)\
f(_27,j)\
q(l,m,l)\
g(h,n,h)\
p(d,k,d)\
p(c,e,c)\
g(i,s,i)\
z(100(%[cur]),s)\
g(G,d,e)\
f(_1,k)\
B(x,h,h)\
F(E,i,h,i)\
D(l,r,h)\
f(_1,m)\
g(t,e,e)\
A(t,i,i)\
D(v,r,r)\
A(j,n,j)\
q(l,r,l)\
C(96(%[cur]),r)\
f(_2,n)\
p(e,d,e)\
z(92(%[cur]),d)\
B(x,e,e)\
F(E,c,e,c)\
q(i,j,i)\
f(_2,j)\
D(v,o,e)\
g(k,s,k)\
D(i,o,o)\
q(i,e,i)\
f(_3,e)\
q(v,c,s)\
u(s,c,s)\
z(88(%[cur]),c)\
g(m,r,m)\
g(n,r,n)\
f(_3,r)\
g(j,d,j)\
g(e,d,e)\
p(n,k,n)\
q(v,h,k)\
f(_4,d)\
u(k,h,k)\
p(j,m,j)\
f(O,m)\
q(t,k,h)\
p(e,n,e)\
u(h,k,h)\
f(_4,k)\
z(84(%[cur]),n)\
C(h,32(%[buf]))\
g(r,c,r)\
p(r,j,r)\
f(_5,j)\
g(d,c,d)\
f(O,c)\
g(m,h,m)\
g(k,n,k)\
p(d,e,d)\
f(_5,e)\
B(x,m,m)\
p(k,r,k)\
z(80(%[cur]),r)\
g(j,n,j)\
f(_6,n)\
p(j,d,j)\
f((%[w]),d)\
g(e,r,e)\
g(n,r,n)\
z(76(%[cur]),r)\
p(e,k,e)\
f(_6,k)\
p(n,j,n)\
A(d,h,d)\
q(v,l,j)\
B(x,h,h)\
u(j,l,j)\
g(c,h,c)\
f(_7,h)\
z(72(%[cur]),l)\
F(E,c,m,c)\
q(t,j,m)\
u(m,j,m)\
A(t,c,c)\
f(_7,j)\
g(k,r,k)\
C(m,96(%[buf]))\
q(c,d,c)\
f(_8,d)\
g(h,r,h)\
p(k,e,k)\
f(Q,e)\
B(x,m,r)\
p(h,n,h)\
f(_8,n)\
g(j,l,j)\
g(d,l,d)\
p(j,k,j)\
z(68(%[cur]),k)\
q(t,c,l)\
g(e,m,e)\
u(l,c,l)\
f(Q,c)\
C(l,(%[buf]))\
f(4(%[w]),l)\
p(d,h,d)\
g(G,d,h)\
B(x,e,e)\
g(t,h,h)\
g(n,k,n)\
g(c,r,c)\
p(h,d,h)\
A(l,m,l)\
p(n,j,n)\
g(G,n,j)\
F(E,c,e,c)\
z(164(%[cur]),e)\
A(t,c,c)\
f(_10,m)\
g(t,j,j)\
q(v,o,d)\
f(_10,r)\
C(160(%[cur]),k)\
u(d,o,d)\
q(c,l,c)\
f(_11,l)\
p(j,n,j)\
q(t,d,n)\
q(t,c,o)\
B(x,j,j)\
u(n,d,n)\
u(o,c,o)\
f(_11,c)\
z(156(%[cur]),d)\
F(E,h,j,h)\
C(o,64(%[buf]))\
f(R,o)\
B(x,n,j)\
g(m,e,m)\
C(n,160(%[buf]))\
f(_12,e)\
g(r,k,r)\
g(l,k,l)\
z(152(%[cur]),k)\
g(c,d,c)\
p(l,m,l)\
g(o,n,o)\
f(_12,m)\
g(e,d,e)\
f(_13,d)\
p(c,r,c)\
q(v,h,r)\
u(r,h,r)\
B(x,o,o)\
f(R,h)\
p(e,l,e)\
f(_13,l)\
g(m,k,m)\
g(d,k,d)\
z(148(%[cur]),k)\
p(m,c,m)\
g(h,j,h)\
f(_14,j)\
f(8(%[w]),c)\
p(d,e,d)\
z(144(%[cur]),e)\
F(E,h,o,h)\
q(v,i,o)\
A(t,h,h)\
u(o,i,o)\
f(_14,i)\
g(l,k,l)\
g(j,k,j)\
A(c,n,c)\
f(_15,n)\
q(t,o,k)\
p(l,m,l)\
u(k,o,k)\
f(_15,o)\
z(140(%[cur]),m)\
p(j,d,j)\
q(h,c,h)\
C(k,224(%[buf]))\
B(x,k,c)\
f(_16,d)\
g(i,e,i)\
g(n,e,n)\
p(i,l,i)\
f(Y,l)\
f(Y,e)\
g(o,m,o)\
p(n,j,n)\
f(_16,j)\
g(d,m,d)\
z(136(%[cur]),m)\
p(o,i,o)\
f(_17,i)\
p(d,n,d)\
f(12(%[w]),n)\
g(e,c,e)\
g(l,k,l)\
q(t,h,c)\
u(c,h,c)\
f(_17,h)\
C(c,128(%[buf]))\
z(132(%[cur]),c)\
B(x,l,l)\
g(j,m,j)\
F(E,e,l,e)\
g(i,m,i)\
A(t,e,e)\
p(j,o,j)\
A(n,k,n)\
p(i,d,i)\
C((%[b]),d)\
g(G,i,k)\
g(h,c,h)\
q(e,n,e)\
q(t,e,n)\
g(t,k,k)\
u(n,e,n)\
p(h,j,h)\
C(32(%[b]),j)\
C(n,192(%[buf]))\
z(228(%[cur]),n)\
g(G,h,e)\
f(_18,c)\
p(k,i,k)\
f(H,i)\
q(v,d,o)\
C(224(%[cur]),m)\
g(t,e,e)\
u(o,d,o)\
f(_18,d)\
f(H,l)\
p(e,h,e)\
f(_19,h)\
B(x,e,e)\
F(E,k,e,k)\
q(v,j,e)\
g(c,n,c)\
u(e,j,e)\
f(_19,j)\
z(220(%[cur]),n)\
g(_29,i,i)\
g(d,m,d)\
g(68(%[b]),l,l)\
B(x,i,i)\
g(h,m,h)\
f(_21,m)\
F(E,l,i,l)\
z(216(%[cur]),i)\
A(t,l,l)\
g(j,n,j)\
p(h,c,h)\
f(_21,c)\
p(j,d,j)\
f(H,d)\
g(m,n,m)\
f(_22,n)\
g(c,i,c)\
p(m,h,m)\
f(H,h)\
p(c,j,c)\
g(_31,d,d)\
z(212(%[cur]),j)\
g(n,i,n)\
f(_22,i)\
B(x,d,d)\
p(n,m,n)\
g(100(%[b]),h,h)\
f(_23,m)\
F(E,h,d,h)\
f(I,d)\
A(t,h,h)\
g(i,j,i)\
p(i,c,i)\
g(m,j,m)\
f(_23,j)\
z(208(%[cur]),c)\
p(m,n,m)\
A(_31,d,d)\
q(v,k,n)\
u(n,k,n)\
f(_24,k)\
q(h,d,h)\
f(I,d)\
g(j,c,j)\
p(j,i,j)\
z(204(%[cur]),i)\
g(k,c,k)\
f(_24,c)\
A(_29,d,d)\
p(k,m,k)\
f(_25,m)\
q(l,d,l)\
D(v,e,d)\
D(h,e,e)\
q(h,d,h)\
z(200(%[cur]),d)\
g(c,i,c)\
g(m,i,m)\
p(c,j,c)\
f(_25,j)\
B(x,e,i)\
p(m,k,m)\
f(_26,k)\
g(j,d,j)\
g(k,d,k)\
p(j,c,j)\
f(K,c)\
f(K,d)\
p(k,m,k)\
z(196(%[cur]),m)\
g(d,i,d)\
g(c,e,c)\
f(_26,i)\
B(x,c,c)\
F(E,d,c,d)\
f((%[y]),c)\
g(i,m,i)\
q(l,o,m)\
D(l,o,l)\
g(G,k,o)\
A(t,d,d)\
p(i,j,i)\
D(v,m,j)\
g(t,o,o)\
A(c,e,c)\
u(j,m,j)\
B(x,h,m)\
g(G,i,e)\
p(o,k,o)\
q(d,c,d)\
f(L,c)\
q(v,l,k)\
g(t,e,e)\
u(k,l,k)\
f(L,l)\
p(e,i,e)\
D(r,s,i)\
B(x,e,e)\
F(E,o,e,o)\
q(v,i,e)\
D(v,s,s)\
u(e,i,e)\
q(v,o,i)\
u(i,o,i)\
q(r,s,r)\
g(c,h,c)\
f(_27,s)\
f(_9,o)\
g(l,m,l)\
f(_9,m)\
B(x,c,c)\
F(E,l,c,l)\
B(x,r,c)\
A(t,l,l)\
A(s,h,s)\
f((%[iy]),h)\
g(o,r,o)\
g(m,c,m)\
D(i,n,c)\
q(l,s,l)\
q(v,c,s)\
D(v,n,n)\
B(x,o,o)\
u(s,c,s)\
D(v,j,c)\
q(i,n,i)\
F(E,m,o,m)\
q(l,c,c)\
D(l,j,l)\
f(_20,j)\
f(_20,o)\
B(x,i,n)\
A(t,m,m)\
A(h,r,h)\
D(v,k,r)\
D(d,k,k)\
q(d,r,d)\
f(4(%[iy]),r)\
q(m,h,m)\
q(v,d,h)\
u(h,d,h)\
q(v,k,d)\
g(j,i,j)\
u(d,k,d)\
D(s,e,k)\
g(o,n,o)\
q(t,d,n)\
u(n,d,n)\
q(t,h,d)\
B(x,j,j)\
C(n,256(%[buf]))\
u(d,h,d)\
q(v,k,h)\
F(E,o,j,o)\
A(r,i,r)\
q(v,l,i)\
C(d,288(%[buf]))\
u(h,k,h)\
A(t,o,o)\
D(v,e,e)\
u(i,l,i)\
C(h,(%[out]))\
f(J,h)\
q(s,e,s)\
q(t,i,e)\
f(J,l)\
B(x,s,k)\
q(v,c,d)\
u(e,i,e)\
q(o,r,o)\
u(d,c,d)\
C(e,320(%[buf]))\
f(N,e)\
D(o,m,c)\
q(t,d,r)\
q(v,c,i)\
u(r,d,r)\
D(v,m,m)\
u(i,c,i)\
C(r,352(%[buf]))\
f(J,r)\
q(o,m,o)\
C(i,32(%[out]))\
f(J,i)\
B(x,o,m)\
g(h,s,h)\
f(N,c)\
g(l,k,l)\
B(x,h,h)\
A(e,s,e)\
F(E,l,h,l)\
A(t,l,l)\
g(r,o,r)\
g(i,m,i)\
q(l,e,l)\
B(x,r,r)\
A(c,o,c)\
C(l,64(%[out]))\
F(E,i,r,i)\
A(t,i,i)\
q(i,c,i)\
C(i,96(%[out]))
	asm volatile(
		CP_FPS_ASM_BLOCK(%%ymm6,%%ymm1,%%ymm4,CP_FPS_ASM_VBROADCASTSS,CP_FPS_ASM_VPMULUDQ,%%ymm9,%%ymm10,%%ymm2,%%ymm0,%%ymm11,%%ymm7,%%ymm3,%%ymm5,CP_FPS_ASM_VPADDQ,CP_FPS_ASM_VPSUBD,%%ymm12,%%ymm8,%%ymm15,CP_FPS_ASM_VPMINUD,%%ymm14,$32,CP_FPS_ASM_VMOVDQU,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPSRLQ,CP_FPS_ASM_VMOVDQA,CP_FPS_ASM_VPADDD,$170,CP_FPS_ASM_VPBLENDD,%%ymm13,32(%[x]),(%[x]),32(%[ix]),32(%[y]),36(%[y]),CP_FPS_ASM_VPBROADCASTD,(%[ix]),16(%[w]),20(%[w]),24(%[w]),256(%[cur]),260(%[cur]),264(%[cur]),268(%[cur]),272(%[cur]),276(%[cur]),28(%[w]),280(%[cur]),284(%[cur]),288(%[cur]),292(%[cur]),296(%[cur]),300(%[cur]),304(%[cur]),308(%[cur]),312(%[cur]),316(%[cur]),32(%[iy]),320(%[cur]),324(%[cur]),328(%[cur]),332(%[cur]),336(%[cur]),340(%[cur]),344(%[cur]),348(%[cur]),352(%[cur]),356(%[cur]),36(%[iy]),360(%[cur]),364(%[cur]),368(%[cur]),372(%[cur]),376(%[cur]),380(%[cur]),4(%[y]),64(%[a]),64(%[b]),96(%[a]),96(%[b]))
#undef CP_FPS_ASM_BLOCK
		:
		: [a] "r"(a), [b] "r"(b), [buf] "r"(buf), [x] "r"(x), [y] "r"(y), [w] "r"(w), [out] "r"(out), [cur] "r"(cur), [ix] "r"(ix), [iy] "r"(iy),
		  [P] "m"(kP), [P2] "m"(k2P), [NI] "m"(kNI)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory");
}
inline void bottom_first(const void* a, const void* b, void* buf, const void* x, const void* y, const void* w) {
	alignas(64) static const std::uint32_t zero[96]{};
	alignas(64) std::uint32_t discarded[32];
	bottom_both(a, b, buf, x, y, w, discarded, zero, x, y);
}
inline void bottom_last(void* out, const void* cur, const void* ix, const void* iy) {
	alignas(64) static const std::uint32_t zero[32]{};
	alignas(64) std::uint32_t discarded[96];
	bottom_both(zero, zero, discarded, ix, iy, zero, out, cur, ix, iy);
}


}
namespace ntt {
inline constexpr int kMaxLog = 23;
namespace detail {
using namespace blocked_ntt::detail;
class Recursion {
public:
	Recursion(const std::uint32_t* roots, const std::uint32_t* inverse_roots) : r_(roots), ir_(inverse_roots) {}

	void visit(Vec* a, Vec* b, std::size_t nv, std::size_t k) const {
		switch (nv) {
		case 4: return tile<4>(a, b, k);
		case 16: return tile<16>(a, b, k);
		case 64: return tile<64>(a, b, k);
		case 256: return tile<256>(a, b, k);
		}
		const std::size_t h = nv / 4;
		forward(a, b, h, k);
		for (std::size_t t = 0; t < 4; ++t) visit(a + t * h, b + t * h, h, 4 * k + t);
		inverse(a, h, k);
	}

private:
	
	template <std::size_t NV>
	[[gnu::noinline]] void tile(Vec* a, Vec* b, std::size_t k) const {
		for (std::size_t h = NV / 4; h >= 4; h /= 4)
			for (std::size_t j = 0, g = k * (NV / (4 * h)); j < NV; j += 4 * h, ++g) forward(a + j, b + j, h, g);
		bottom(a, b, NV, k * (NV / 4));
		for (std::size_t h = 4; h < NV; h *= 4)
			for (std::size_t j = 0, g = k * (NV / (4 * h)); j < NV; j += 4 * h, ++g) inverse(a + j, h, g);
	}

	void forward(Vec* a, Vec* b, std::size_t h, std::size_t k) const {
		if (k == 0) {
			kernels::forward_identity(a, h, r_);
			kernels::forward_identity(b, h, r_);
			return;
		}
		const std::uint32_t *x = r_ + slot(k), *y = r_ + slot(2 * k);
		if (h == 4) return kernels::forward_pair(a, b, h, x, y);
		kernels::forward(a, h, x, y);
		kernels::forward(b, h, x, y);
	}

	void inverse(Vec* a, std::size_t h, std::size_t k) const {
		if (k == 0) return kernels::inverse_identity(a, h, ir_);
		kernels::inverse(a, h, ir_ + slot(k), ir_ + slot(2 * k));
	}

	struct alignas(64) Leaves {
		std::uint32_t window[4][16];
		std::uint32_t coefficients[4][8];
	};

	void leaf_weights(std::size_t k, std::uint32_t* w) const {
		const std::uint32_t* y = r_ + slot(2 * k);
		w[0] = y[0], w[1] = kP - y[0], w[2] = y[1], w[3] = kP - y[1];
		w[4] = y[8], w[5] = ~y[8], w[6] = y[9], w[7] = ~y[9];
	}

	
	void bottom(Vec* a, Vec* b, std::size_t nv, std::size_t first) const {
		Leaves leaves[2]{};
		alignas(32) std::uint32_t w[2][8];
		leaf_weights(first, w[0]);
		kernels::bottom_first(a, b, &leaves[0], r_ + slot(first), r_ + slot(2 * first), w[0]);
		for (std::size_t j = 0, k = first; j < nv; j += 4, ++k) {
			const std::size_t cur = j / 4 % 2, next = cur ^ 1;
			const std::uint32_t *ix = ir_ + slot(k), *iy = ir_ + slot(2 * k);
			if (j + 4 == nv) {
				kernels::bottom_last(a + j, &leaves[cur], ix, iy);
				break;
			}
			leaf_weights(k + 1, w[next]);
			kernels::bottom_both(a + j + 4, b + j + 4, &leaves[next], r_ + slot(k + 1), r_ + slot(2 * k + 2), w[next],
								 a + j, &leaves[cur], ix, iy);
		}
	}

	const std::uint32_t *r_, *ir_;
};



inline void forward_radix2(Vec* f, std::size_t h, bool sparse) {
	if (sparse) {
		std::memcpy(f + h, f, h * sizeof(Vec));
		return;
	}
	for (std::size_t i = 0; i < h; ++i) {
		const Vec x = f[i], y = f[i + h];
		f[i] = reduce(add(x, y), 2 * kP);
		f[i + h] = reduce(diff(x, y), 2 * kP);
	}
}

inline void forward_radix4(Vec* f, std::size_t h, bool sparse, const std::uint32_t* roots) {
	if (!sparse) return kernels::forward_identity(f, h, roots);
	const Factor z(roots[1], roots[9]);
	for (std::size_t j = 0; j < h; ++j) {
		const Vec a = f[j], b = f[j + h], zb = multiply(b, z);
		f[j] = add(a, b), f[j + h] = diff(a, b), f[j + 2 * h] = add(a, zb), f[j + 3 * h] = diff(a, zb);
	}
}

inline void inverse_radix4(Vec* f, std::size_t h, const std::uint32_t* inverse_roots, const Factor& s) {
	const Factor z(inverse_roots[1], inverse_roots[9]);
	const auto scale = [&s](Vec x) __attribute__((target("avx2"))) { return reduce(multiply(x, s), kP); };
	for (std::size_t j = 0; j < h; ++j) {
		const Vec p0 = f[j], p1 = f[j + h], p2 = f[j + 2 * h], p3 = f[j + 3 * h];
		const Vec ab = reduce(add(p0, p1), 2 * kP), cd = reduce(add(p2, p3), 2 * kP);
		const Vec amb = reduce(diff(p0, p1), 2 * kP), cmd = multiply(diff(p2, p3), z);
		f[j] = scale(add(ab, cd)), f[j + h] = scale(add(amb, cmd));
		f[j + 2 * h] = scale(diff(ab, cd)), f[j + 3 * h] = scale(diff(amb, cmd));
	}
}

}
class Convolution {
public:
	Convolution(std::size_t n, std::size_t m) : Convolution(n, m, nullptr) {}
	Convolution(std::size_t n, std::size_t m, std::uint32_t* borrowed_a)
		: n_(n), m_(m), lg_(std::max(6, int(std::bit_width(n + m - 2)))) {
		if (n == 0 || m == 0 || lg_ > kMaxLog) std::abort();
		const std::size_t len = length(), words = (borrowed_a ? 1 : 2) * (len + kPadding) + 2 * detail::table_words(lg_) + (borrowed_a ? 1024 : 0);
		storage_ = allocate_fps_words(words);
		a_ = borrowed_a ? borrowed_a : storage_.get();
		const std::size_t color = ((reinterpret_cast<std::uintptr_t>(a_) >> 6) - (reinterpret_cast<std::uintptr_t>(storage_.get()) >> 6) + 1) & 63;
		b_ = storage_.get() + (borrowed_a ? 16 * color : len + kPadding);
		roots_ = b_ + len + kPadding;
		inverse_roots_ = roots_ + detail::table_words(lg_);
		std::fill(roots_, inverse_roots_ + detail::table_words(lg_), 0);
	}

	Convolution(const Convolution&) = delete;
	Convolution& operator=(const Convolution&) = delete;

	std::uint32_t* a() { return a_; }
	std::uint32_t* b() { return b_; }

	const std::uint32_t* multiply() {
		using namespace detail;
		const std::size_t len = length(), nv = len / 8;
		build_table(roots_, len / 16, kRoots[0]);
		build_table(inverse_roots_, len / 16, kRoots[1]);
		const Recursion recursion(roots_, inverse_roots_);
		const std::uint32_t scale = power(std::uint32_t(nv), kP - 2);
		auto* a = reinterpret_cast<Vec*>(a_);
		auto* b = reinterpret_cast<Vec*>(b_);
		const bool sparse_a = n_ <= len / 2, sparse_b = m_ <= len / 2;
		if (std::countr_zero(nv) % 2) {
			const std::size_t h = nv / 2;
			forward_radix2(a, h, sparse_a);
			forward_radix2(b, h, sparse_b);
			recursion.visit(a, b, h, 0);
			recursion.visit(a + h, b + h, h, 1);
			alignas(32) std::uint32_t s[16] = {};
			s[1] = scale;
			s[9] = quotient(scale);
			kernels::scale_radix2(a, h, s);
		} else {
			const std::size_t h = nv / 4;
			forward_radix4(a, h, sparse_a, roots_);
			forward_radix4(b, h, sparse_b, roots_);
			for (std::size_t t = 0; t < 4; ++t) recursion.visit(a + t * h, b + t * h, h, t);
			detail::inverse_radix4(a, h, inverse_roots_, Factor(scale));
		}
		return a_;
	}

private:
	static constexpr std::size_t kPadding = 16;

	std::size_t length() const { return std::size_t(1) << lg_; }

	std::size_t n_, m_;
	int lg_;
	FpsWords storage_;
	std::uint32_t *a_, *b_, *roots_, *inverse_roots_;
};

}
namespace bottom_kernels {

using ntt::kernels::k2P;
using ntt::kernels::kNI;
using ntt::kernels::kP;





[[gnu::always_inline]] inline void both(const void* a, const void* b, void* buf, const void* x, const void* y, void* out, const void* cur, const void* ix, const void* iy) {
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U,V,W,X,Y,Z,_0,_1,_2,_3,_4,_5,_6,_7,_8,_9,_10,_11,_12,_13,_14,_15,_16,_17,_18,_19,_20,_21,_22,_23,_24,_25,_26,_27,_28,_29,_30,_31,_32,_33,_34,_35,_36,_37,_38,_39,_40,_41,_42,_43,_44,_45,_46,_47,_48,_49,_50,_51,_52,_53,_54,_55,_56,_57,_58,_59,_60,_61,_62,_63) \
T(%[P],t) T(%[P2],v) T(%[NI],D) l(E,p)\
l(E,h)\
B(32(%[a]),m)\
l(K,g)\
l(E,d)\
l(256(%[cur]),n)\
l(E,j)\
l(K,k)\
B((%[a]),e)\
l(260(%[cur]),i)\
c(_61,p,p)\
c(100(%[a]),h,h)\
s(v,m,q)\
x(_61,g,g)\
c(_52,d,d)\
u(q,m,q)\
c(_18,n,m)\
c(36(%[cur]),n,n)\
y(w,p,p)\
l(264(%[cur]),f)\
C(A,h,p,h)\
c(68(%[a]),j,j)\
s(v,e,p)\
c(_17,i,o)\
c(_18,i,i)\
y(w,d,d)\
u(p,e,p)\
x(t,h,h)\
z(v,q,e)\
x(_52,k,k)\
C(A,j,d,j)\
l(268(%[cur]),d)\
r(o,m,o)\
r(i,n,i)\
x(t,j,j)\
l(F,n)\
s(h,g,h)\
l(272(%[cur]),g)\
z(h,q,q)\
s(h,e,h)\
l(F,e)\
y(w,q,m)\
s(j,k,j)\
c(_16,f,k)\
c(_17,f,f)\
r(k,o,k)\
r(f,i,f)\
c(_6,d,i)\
c(_16,d,d)\
l(276(%[cur]),o)\
c(n,q,n)\
r(i,k,i)\
r(d,f,d)\
c(_2,g,f)\
c(_6,g,g)\
l(L,k)\
c(e,m,e)\
z(j,p,m)\
s(j,p,j)\
l(280(%[cur]),p)\
y(w,n,n)\
r(f,i,f)\
r(g,d,g)\
l(H,d)\
l(H,i)\
C(A,e,n,e)\
l(284(%[cur]),n)\
x(t,e,e)\
x(k,q,k)\
c(V,o,q)\
c(_2,o,o)\
c(d,h,d)\
r(q,f,q)\
s(e,k,e)\
c(_56,p,k)\
c(V,p,p)\
c(4(%[cur]),n,f)\
c(_56,n,n)\
r(o,g,o)\
y(w,h,g)\
c(i,g,i)\
y(w,d,d)\
l(R,g)\
r(k,q,k)\
r(p,o,p)\
s(v,m,o)\
z(v,j,q)\
r(f,k,f)\
r(n,p,n)\
u(o,m,o)\
u(q,j,q)\
c(D,f,j)\
c(D,n,m)\
C(A,i,d,i)\
z(v,o,d)\
l(288(%[cur]),p)\
x(t,i,i)\
z(v,q,k)\
s(e,d,d)\
z(e,o,e)\
l(292(%[cur]),o)\
c(t,j,j)\
c(t,m,m)\
x(g,h,g)\
s(v,e,h)\
r(j,f,j)\
r(m,n,m)\
u(h,e,h)\
l(F,e)\
l(296(%[cur]),n)\
y(w,j,j)\
l(F,f)\
C(A,m,j,m)\
s(i,g,i)\
s(t,h,g)\
c(_63,p,j)\
c(100(%[cur]),p,p)\
s(i,k,k)\
z(i,q,i)\
l(300(%[cur]),q)\
u(g,h,g)\
c(_60,o,h)\
c(_63,o,o)\
B(g,32(%[buf]))\
r(h,j,h)\
r(o,p,o)\
c(e,g,e)\
s(v,m,p)\
l(L,j)\
u(p,m,p)\
l(304(%[cur]),m)\
y(w,e,e)\
x(j,g,j)\
y(w,g,g)\
c(f,g,f)\
c(_59,n,g)\
c(_60,n,n)\
r(g,h,g)\
C(A,f,e,f)\
l(308(%[cur]),e)\
c(_58,q,h)\
c(_59,q,q)\
r(n,o,n)\
x(t,f,f)\
s(v,d,o)\
u(o,d,o)\
l(312(%[cur]),d)\
r(h,g,h)\
c(_57,m,g)\
c(_58,m,m)\
r(q,n,q)\
s(f,j,f)\
l(F,j)\
l(F,n)\
r(g,h,g)\
r(m,q,m)\
s(t,o,q)\
s(t,f,h)\
u(q,o,q)\
u(h,f,h)\
l(316(%[cur]),f)\
c(_55,e,o)\
c(_57,e,e)\
B(h,(%[buf]))\
l(L,h)\
B(q,96(%[buf]))\
r(o,g,o)\
r(e,m,e)\
c(_54,d,m)\
c(_55,d,d)\
y(w,q,g)\
c(j,q,j)\
c(n,g,n)\
r(m,o,m)\
r(d,e,d)\
c(68(%[cur]),f,e)\
c(_54,f,f)\
y(w,j,j)\
s(v,i,o)\
C(A,n,j,n)\
u(o,i,o)\
x(h,q,h)\
x(t,n,n)\
l(320(%[cur]),q)\
r(e,m,e)\
r(f,d,f)\
s(t,o,d)\
c(D,e,m)\
c(D,f,i)\
u(d,o,d)\
l(324(%[cur]),o)\
l(H,j)\
y(w,d,g)\
s(n,h,n)\
B(d,160(%[buf]))\
l(H,h)\
c(t,m,m)\
c(t,i,i)\
r(m,e,m)\
r(i,f,i)\
l(328(%[cur]),f)\
s(t,n,e)\
y(w,m,m)\
u(e,n,e)\
c(_3,q,n)\
c(164(%[cur]),q,q)\
C(A,i,m,i)\
s(e,t,e)\
l(R,m)\
c(j,d,j)\
B(e,64(%[buf]))\
l(332(%[cur]),e)\
c(h,g,h)\
c(_1,o,g)\
c(_3,o,o)\
y(w,j,j)\
r(g,n,g)\
C(A,h,j,h)\
l(336(%[cur]),j)\
s(v,i,n)\
r(o,q,o)\
u(n,i,n)\
x(t,h,h)\
c(_0,f,i)\
c(_1,f,f)\
s(v,k,q)\
u(q,k,q)\
x(m,d,m)\
l(340(%[cur]),d)\
c(Z,e,k)\
c(_0,e,e)\
r(i,g,i)\
s(t,q,g)\
r(f,o,f)\
u(g,q,g)\
l(H,q)\
l(344(%[cur]),o)\
s(h,m,h)\
B(g,224(%[buf]))\
r(k,i,k)\
r(e,f,e)\
l(H,f)\
y(w,g,i)\
s(t,h,m)\
u(m,h,m)\
l(348(%[cur]),h)\
B(m,128(%[buf]))\
c(Y,j,m)\
c(Z,j,j)\
r(m,k,m)\
r(j,e,j)\
c(X,d,e)\
c(Y,d,d)\
l(R,k)\
c(q,g,q)\
r(e,m,e)\
r(d,j,d)\
c(f,i,f)\
c(W,o,i)\
c(X,o,o)\
c(132(%[cur]),h,j)\
y(w,q,q)\
c(W,h,h)\
B((%[b]),m)\
r(i,e,i)\
C(A,f,q,f)\
r(o,d,o)\
r(j,i,j)\
x(t,f,f)\
r(h,o,h)\
c(D,j,o)\
B(32(%[b]),i)\
l(352(%[cur]),d)\
c(D,h,q)\
x(k,g,k)\
l(E,g)\
c(t,o,o)\
c(t,q,q)\
l(E,e)\
s(f,k,f)\
l(356(%[cur]),k)\
r(o,j,o)\
s(v,m,j)\
r(q,h,q)\
y(w,o,o)\
u(j,m,j)\
s(t,f,m)\
l(360(%[cur]),h)\
C(A,q,o,q)\
l(K,o)\
u(m,f,m)\
c(_15,d,f)\
c(228(%[cur]),d,d)\
s(m,t,m)\
c(_53,g,g)\
B(m,192(%[buf]))\
s(v,q,m)\
u(m,q,m)\
l(364(%[cur]),q)\
c(68(%[b]),e,e)\
y(w,g,g)\
C(A,e,g,e)\
c(_12,k,g)\
c(_15,k,k)\
x(_53,o,o)\
x(t,e,e)\
r(g,f,g)\
r(k,d,k)\
l(368(%[cur]),d)\
c(_11,h,f)\
c(_12,h,h)\
s(e,o,e)\
c(_10,q,o)\
c(_11,q,q)\
r(f,g,f)\
l(E,g)\
r(h,k,h)\
r(o,f,o)\
l(372(%[cur]),f)\
l(E,k)\
r(q,h,q)\
l(K,h)\
c(_62,g,g)\
c(100(%[b]),k,k)\
x(_62,h,h)\
y(w,g,g)\
C(A,k,g,k)\
l(376(%[cur]),g)\
x(t,k,k)\
s(k,h,k)\
c(_9,d,h)\
c(_10,d,d)\
r(h,o,h)\
r(d,q,d)\
c(_8,f,q)\
c(_9,f,f)\
l(380(%[cur]),o)\
r(q,h,q)\
r(f,d,f)\
c(_7,g,d)\
c(_8,g,g)\
l(F,h)\
r(d,q,d)\
r(g,f,g)\
l(F,f)\
s(v,i,q)\
u(q,i,q)\
z(e,j,i)\
s(e,j,e)\
z(v,q,j)\
z(k,q,q)\
s(k,j,k)\
c(196(%[cur]),o,j)\
c(_7,o,o)\
r(j,d,j)\
r(o,g,o)\
c(h,q,h)\
l(L,g)\
y(w,q,d)\
c(f,d,f)\
c(D,j,d)\
y(w,h,h)\
c(t,d,d)\
C(A,f,h,f)\
c(D,o,h)\
x(t,f,f)\
c(t,h,h)\
r(d,j,d)\
x(g,q,g)\
l(H,q)\
l(H,j)\
y(w,d,d)\
r(h,o,h)\
s(f,g,f)\
z(v,p,g)\
y(w,k,o)\
C(A,h,d,h)\
s(n,g,g)\
z(n,p,n)\
l(R,p)\
s(v,i,d)\
u(d,i,d)\
l(_19,i)\
c(q,k,q)\
c(j,o,j)\
l(_19,o)\
y(w,q,q)\
C(A,j,q,j)\
x(p,k,p)\
s(v,h,k)\
y(w,g,q)\
u(k,h,k)\
c(i,g,i)\
x(t,j,j)\
l((%[iy]),h)\
c(o,q,o)\
y(w,i,i)\
s(j,p,j)\
s(v,n,p)\
z(v,m,q)\
z(k,m,m)\
u(p,n,p)\
z(v,e,n)\
s(k,q,k)\
u(n,e,n)\
l(_20,e)\
s(v,m,q)\
C(A,o,i,o)\
u(q,m,q)\
l(_20,m)\
y(w,k,i)\
x(t,o,o)\
x(h,g,h)\
z(v,d,g)\
z(f,d,d)\
s(f,g,f)\
l(4(%[iy]),g)\
s(o,h,o)\
z(v,n,h)\
z(j,n,n)\
s(j,h,j)\
s(v,d,h)\
c(e,k,e)\
u(h,d,h)\
s(v,f,d)\
c(m,i,m)\
u(d,f,d)\
s(v,n,f)\
z(q,p,i)\
u(f,n,f)\
s(v,j,n)\
y(w,e,e)\
u(n,j,n)\
s(t,h,j)\
C(A,m,e,m)\
x(g,k,g)\
u(j,h,j)\
s(t,d,h)\
x(t,m,m)\
z(v,p,p)\
s(t,f,k)\
s(v,i,e)\
B(j,256(%[buf]))\
B(128(%[a]),j)\
s(q,p,q)\
s(t,n,p)\
u(h,d,h)\
u(k,f,k)\
B(160(%[a]),f)\
y(w,q,d)\
u(e,i,e)\
u(p,n,p)\
B(h,288(%[buf]))\
l(G,h)\
l(N,n)\
s(m,g,m)\
B(e,(%[out]))\
l(G,e)\
l(N,g)\
z(m,o,i)\
B(k,320(%[buf]))\
l(U,k)\
B(p,352(%[buf]))\
z(v,o,o)\
s(v,i,p)\
s(m,o,m)\
u(p,i,p)\
l(Q,i)\
l(N,o)\
B(p,32(%[out]))\
s(v,j,p)\
u(p,j,p)\
s(v,f,j)\
c(_4,h,h)\
u(j,f,j)\
c(n,q,n)\
l(N,f)\
c(196(%[a]),e,e)\
c(g,d,g)\
l(G,d)\
x(k,q,k)\
l(G,q)\
y(w,h,h)\
y(w,n,n)\
C(A,e,h,e)\
x(_4,i,i)\
C(A,g,n,g)\
l(U,n)\
y(w,m,h)\
x(t,e,e)\
c(o,m,o)\
x(t,g,g)\
s(e,i,e)\
c(f,h,f)\
y(w,o,o)\
l(640(%[cur]),h)\
l(Q,i)\
c(_13,d,d)\
s(g,k,g)\
l(644(%[cur]),k)\
c(228(%[a]),q,q)\
B(g,64(%[out]))\
z(e,p,g)\
s(e,p,e)\
C(A,f,o,f)\
l(648(%[cur]),o)\
s(v,g,p)\
y(w,d,d)\
u(p,g,p)\
x(n,m,n)\
x(t,f,f)\
C(A,q,d,q)\
z(v,j,d)\
z(v,e,m)\
l(652(%[cur]),g)\
x(t,q,q)\
u(m,e,m)\
l(I,e)\
s(f,n,f)\
c(_29,h,n)\
c(420(%[cur]),h,h)\
B(f,96(%[out]))\
l(656(%[cur]),f)\
x(_13,i,i)\
s(q,i,q)\
c(_28,k,i)\
c(_29,k,k)\
z(q,j,j)\
s(q,d,q)\
c(_27,o,d)\
c(_28,o,o)\
r(i,n,i)\
r(k,h,k)\
c(e,j,e)\
l(660(%[cur]),h)\
c(_26,g,n)\
c(_27,g,g)\
r(d,i,d)\
r(o,k,o)\
l(I,k)\
y(w,j,i)\
r(n,d,n)\
y(w,e,e)\
l(664(%[cur]),d)\
r(g,o,g)\
c(_25,f,o)\
c(_26,f,f)\
r(o,n,o)\
r(f,g,f)\
l(J,g)\
l(J,n)\
c(k,i,k)\
l(668(%[cur]),i)\
C(A,k,e,k)\
c(_22,h,e)\
c(_25,h,h)\
x(t,k,k)\
r(e,o,e)\
r(h,f,h)\
c(g,q,g)\
c(_21,d,f)\
l(S,o)\
c(_22,d,d)\
r(f,e,f)\
y(w,g,g)\
c(388(%[cur]),i,e)\
c(_21,i,i)\
r(d,h,d)\
l(M,h)\
r(e,f,e)\
r(i,d,i)\
y(w,q,d)\
z(v,p,f)\
c(n,d,n)\
c(D,e,d)\
x(o,j,o)\
c(D,i,j)\
c(t,d,d)\
C(A,n,g,n)\
l(672(%[cur]),g)\
c(t,j,j)\
x(t,n,n)\
s(k,o,k)\
z(v,m,o)\
x(h,q,h)\
s(k,f,f)\
z(k,p,k)\
l(676(%[cur]),p)\
r(d,e,d)\
s(v,k,e)\
r(j,i,j)\
y(w,d,d)\
l(I,i)\
u(e,k,e)\
l(680(%[cur]),k)\
C(A,j,d,j)\
s(n,h,n)\
l(I,h)\
s(t,e,d)\
s(v,j,q)\
s(n,o,o)\
z(n,m,n)\
u(d,e,d)\
l(684(%[cur]),e)\
u(q,j,q)\
l(S,j)\
y(w,d,m)\
B(d,416(%[buf]))\
c(i,d,i)\
c(h,m,h)\
c(_37,g,m)\
c(484(%[cur]),g,g)\
y(w,i,i)\
x(j,d,j)\
l(688(%[cur]),d)\
C(A,h,i,h)\
c(_36,p,i)\
c(_37,p,p)\
x(t,h,h)\
r(i,m,i)\
r(p,g,p)\
c(_35,k,g)\
c(_36,k,k)\
l(692(%[cur]),m)\
s(h,j,h)\
c(_34,e,j)\
c(_35,e,e)\
r(g,i,g)\
r(k,p,k)\
s(v,f,p)\
s(t,h,i)\
u(p,f,p)\
u(i,h,i)\
l(696(%[cur]),h)\
c(_33,d,f)\
c(_34,d,d)\
r(j,g,j)\
r(e,k,e)\
B(i,384(%[buf]))\
l(I,i)\
s(t,p,k)\
l(700(%[cur]),g)\
u(k,p,k)\
r(f,j,f)\
l(I,j)\
l(S,p)\
B(k,480(%[buf]))\
r(d,e,d)\
y(w,k,e)\
c(i,k,i)\
c(j,e,j)\
x(p,k,p)\
c(_32,m,k)\
c(_33,m,m)\
y(w,i,i)\
c(_31,h,e)\
c(_32,h,h)\
C(A,j,i,j)\
c(452(%[cur]),g,i)\
c(_31,g,g)\
r(k,f,k)\
r(m,d,m)\
x(t,j,j)\
s(v,n,d)\
r(e,k,e)\
r(h,m,h)\
u(d,n,d)\
l(704(%[cur]),n)\
r(i,e,i)\
r(g,h,g)\
s(t,d,h)\
c(D,i,e)\
c(D,g,m)\
u(h,d,h)\
s(j,p,j)\
l(708(%[cur]),p)\
l(J,d)\
y(w,h,k)\
s(t,j,f)\
B(h,544(%[buf]))\
u(f,j,f)\
l(J,j)\
c(t,e,e)\
c(t,m,m)\
s(f,t,f)\
B(f,448(%[buf]))\
l(712(%[cur]),f)\
r(e,i,e)\
r(m,g,m)\
l(M,g)\
c(_44,n,i)\
c(548(%[cur]),n,n)\
y(w,e,e)\
C(A,m,e,m)\
l(716(%[cur]),e)\
c(d,h,d)\
c(j,k,j)\
c(_43,p,k)\
c(_44,p,p)\
y(w,d,d)\
r(k,i,k)\
C(A,j,d,j)\
l(720(%[cur]),d)\
c(_42,f,i)\
c(_43,f,f)\
r(p,n,p)\
x(g,h,g)\
s(v,m,h)\
u(h,m,h)\
s(v,o,m)\
x(t,j,j)\
l(724(%[cur]),n)\
r(i,k,i)\
u(m,o,m)\
c(_41,e,o)\
c(_42,e,e)\
r(f,p,f)\
s(t,m,p)\
l(J,k)\
u(p,m,p)\
s(j,g,j)\
l(728(%[cur]),g)\
l(J,m)\
B(p,608(%[buf]))\
r(o,i,o)\
r(e,f,e)\
y(w,p,f)\
s(t,j,i)\
u(i,j,i)\
l(732(%[cur]),j)\
B(i,512(%[buf]))\
c(_40,d,i)\
c(_41,d,d)\
r(i,o,i)\
r(d,e,d)\
c(_39,n,e)\
c(_40,n,n)\
l(M,o)\
c(k,p,k)\
c(m,f,m)\
c(_38,g,f)\
c(_39,g,g)\
r(e,i,e)\
r(n,d,n)\
c(516(%[cur]),j,d)\
c(_38,j,j)\
y(w,k,k)\
r(f,e,f)\
B(128(%[b]),e)\
C(A,m,k,m)\
r(g,n,g)\
x(t,m,m)\
r(d,f,d)\
r(j,g,j)\
B(160(%[b]),g)\
c(D,d,f)\
c(D,j,n)\
l(736(%[cur]),k)\
l(G,i)\
x(o,p,o)\
c(t,f,f)\
c(t,n,n)\
l(740(%[cur]),p)\
s(m,o,m)\
l(G,o)\
r(f,d,f)\
r(n,j,n)\
s(v,e,j)\
s(t,m,d)\
y(w,f,f)\
u(j,e,j)\
u(d,m,d)\
s(v,g,m)\
l(744(%[cur]),e)\
C(A,n,f,n)\
l(Q,f)\
u(m,g,m)\
s(d,t,d)\
c(_51,k,g)\
c(612(%[cur]),k,k)\
B(d,576(%[buf]))\
l(748(%[cur]),d)\
c(_5,i,i)\
c(196(%[b]),o,o)\
y(w,i,i)\
C(A,o,i,o)\
x(_5,f,f)\
c(_50,p,i)\
c(_51,p,p)\
x(t,o,o)\
r(i,g,i)\
l(752(%[cur]),g)\
r(p,k,p)\
s(o,f,o)\
c(_49,e,f)\
c(_50,e,e)\
c(_48,d,k)\
c(_49,d,d)\
r(f,i,f)\
r(e,p,e)\
l(G,p)\
l(G,i)\
r(k,f,k)\
r(d,e,d)\
l(756(%[cur]),e)\
l(Q,f)\
c(_14,p,p)\
c(228(%[b]),i,i)\
x(_14,f,f)\
y(w,p,p)\
C(A,i,p,i)\
l(760(%[cur]),p)\
x(t,i,i)\
s(i,f,i)\
c(_47,g,f)\
c(_48,g,g)\
r(f,k,f)\
r(g,d,g)\
c(_46,e,d)\
c(_47,e,e)\
l(764(%[cur]),k)\
r(d,f,d)\
r(e,g,e)\
c(_45,p,g)\
c(_46,p,p)\
s(v,n,f)\
u(f,n,f)\
l(I,n)\
r(g,d,g)\
r(p,e,p)\
l(I,e)\
z(v,m,d)\
z(i,m,m)\
s(i,d,i)\
y(w,m,d)\
c(n,m,n)\
c(e,d,e)\
c(580(%[cur]),k,d)\
c(_45,k,k)\
y(w,n,n)\
r(d,g,d)\
C(A,e,n,e)\
l(S,n)\
z(o,j,g)\
s(o,j,o)\
r(k,p,k)\
c(D,d,p)\
y(w,i,j)\
x(t,e,e)\
c(t,p,p)\
r(p,d,p)\
c(D,k,d)\
y(w,p,p)\
x(n,m,n)\
l(J,m)\
c(t,d,d)\
s(e,n,e)\
z(v,q,n)\
z(h,q,q)\
s(h,n,h)\
l(J,n)\
r(d,k,d)\
y(w,h,k)\
C(A,d,p,d)\
l(_24,p)\
c(m,i,m)\
y(w,m,m)\
c(n,j,n)\
l(_24,j)\
c(p,h,p)\
C(A,n,m,n)\
s(v,d,m)\
u(m,d,m)\
x(t,n,n)\
l(M,d)\
y(w,p,p)\
c(j,k,j)\
l(8(%[iy]),k)\
C(A,j,p,j)\
s(v,q,p)\
x(t,j,j)\
u(p,q,p)\
x(d,i,d)\
z(m,f,i)\
z(v,f,f)\
s(v,i,q)\
s(m,f,m)\
u(q,i,q)\
l(_30,i)\
s(v,g,f)\
u(f,g,f)\
s(n,d,n)\
l(_30,d)\
y(w,m,g)\
x(k,h,k)\
z(v,o,h)\
u(h,o,h)\
z(v,f,o)\
z(e,f,f)\
s(e,o,e)\
l(12(%[iy]),o)\
s(j,k,j)\
z(v,h,k)\
z(n,h,h)\
s(n,k,n)\
s(v,f,k)\
u(k,f,k)\
s(v,e,f)\
c(i,m,i)\
u(f,e,f)\
s(v,h,e)\
c(d,g,d)\
u(e,h,e)\
z(q,p,h)\
s(t,k,g)\
u(g,k,g)\
s(v,n,k)\
y(w,i,i)\
u(k,n,k)\
B(g,640(%[buf]))\
s(t,f,g)\
s(t,e,n)\
C(A,d,i,d)\
x(o,m,o)\
z(v,p,p)\
u(g,f,g)\
l(O,f)\
l(O,m)\
x(t,d,d)\
s(q,p,q)\
s(v,h,p)\
s(t,k,i)\
B(g,672(%[buf]))\
l(_23,g)\
u(n,e,n)\
u(p,h,p)\
u(i,k,i)\
z(v,j,k)\
y(w,q,h)\
B(p,128(%[out]))\
l(O,p)\
l(O,e)\
s(d,o,d)\
B(n,704(%[buf]))\
l(_23,n)\
s(d,k,k)\
z(d,j,d)\
B(i,736(%[buf]))\
y(w,k,i)\
s(v,d,j)\
u(j,d,j)\
B(j,160(%[out]))\
c(f,q,f)\
c(m,h,m)\
x(g,q,g)\
c(p,k,p)\
c(e,i,e)\
y(w,f,f)\
C(A,m,f,m)\
x(n,k,n)\
x(t,m,m)\
y(w,p,p)\
C(A,e,p,e)\
x(t,e,e)\
s(m,g,m)\
B(m,192(%[out]))\
s(e,n,e)\
B(e,224(%[out]))
	asm volatile(
		CP_FPS_ASM_BLOCK(CP_FPS_ASM_VPMULUDQ,%%ymm4,%%ymm8,%%ymm11,%%ymm3,%%ymm1,%%ymm9,%%ymm6,%%ymm7,CP_FPS_ASM_VBROADCASTSS,%%ymm2,%%ymm5,%%ymm12,%%ymm0,%%ymm10,CP_FPS_ASM_VPADDQ,CP_FPS_ASM_VPSUBD,%%ymm15,CP_FPS_ASM_VPMINUD,%%ymm14,$32,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPSRLQ,CP_FPS_ASM_VPADDD,$170,CP_FPS_ASM_VMOVDQA,CP_FPS_ASM_VPBLENDD,%%ymm13,32(%[x]),32(%[y]),36(%[x]),36(%[y]),40(%[y]),44(%[y]),(%[x]),(%[y]),12(%[y]),32(%[ix]),36(%[ix]),4(%[x]),4(%[y]),8(%[y]),CP_FPS_ASM_VPBROADCASTD,(%[ix]),12(%[cur]),136(%[cur]),140(%[cur]),144(%[cur]),148(%[cur]),152(%[cur]),156(%[cur]),16(%[cur]),160(%[cur]),192(%[a]),192(%[b]),20(%[cur]),200(%[cur]),204(%[cur]),208(%[cur]),212(%[cur]),216(%[cur]),220(%[cur]),224(%[a]),224(%[b]),224(%[cur]),24(%[cur]),28(%[cur]),32(%[cur]),32(%[iy]),36(%[iy]),392(%[cur]),396(%[cur]),4(%[ix]),40(%[iy]),400(%[cur]),404(%[cur]),408(%[cur]),412(%[cur]),416(%[cur]),44(%[iy]),456(%[cur]),460(%[cur]),464(%[cur]),468(%[cur]),472(%[cur]),476(%[cur]),480(%[cur]),520(%[cur]),524(%[cur]),528(%[cur]),532(%[cur]),536(%[cur]),540(%[cur]),544(%[cur]),584(%[cur]),588(%[cur]),592(%[cur]),596(%[cur]),600(%[cur]),604(%[cur]),608(%[cur]),64(%[a]),64(%[b]),72(%[cur]),76(%[cur]),8(%[cur]),80(%[cur]),84(%[cur]),88(%[cur]),92(%[cur]),96(%[a]),96(%[b]),96(%[cur]))
#undef CP_FPS_ASM_BLOCK
		:
		: [a] "r"(a), [b] "r"(b), [buf] "r"(buf), [x] "r"(x), [y] "r"(y), [out] "r"(out), [cur] "r"(cur), [ix] "r"(ix), [iy] "r"(iy),
		  [P] "m"(kP), [P2] "m"(k2P), [NI] "m"(kNI)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory");
}
[[gnu::always_inline]] inline void first(const void* a, const void* b, void* buf, const void* x, const void* y) {
	alignas(64) static const std::uint32_t zero[192]{};
	alignas(64) std::uint32_t discarded[64];
	both(a, b, buf, x, y, discarded, zero, x, y);
}
[[gnu::always_inline]] inline void last(void* out, const void* cur, const void* ix, const void* iy) {
	alignas(64) static const std::uint32_t zero[64]{};
	alignas(64) std::uint32_t discarded[192];
	both(zero, zero, discarded, ix, iy, out, cur, ix, iy);
}


}
namespace top_kernels {

using ntt::kernels::k2P;
using ntt::kernels::kP;
using ntt::kernels::Vec;

inline void inverse_top(Vec* a, std::size_t q, const Vec* w) {
	Vec* b = a + 4 * q;
	Vec* const end = a + q;
	#define CP_FPS_ASM_BLOCK(c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U) \
S(%[P],v) S(%[P2],j) ".p2align 5\n\t" "1:\n\t" \
A((%[b]),n)\
A(K,f)\
A((%[a]),g)\
A(J,t)\
o(j,n,e)\
o(I,n,n)\
c(I,e,e)\
o(j,f,d)\
c(j,n,r)\
o(H,f,f)\
z(u,e,h)\
y(L,e,m)\
c(H,d,d)\
o(j,g,k)\
y(L,h,h)\
z(u,d,s)\
y(M,d,i)\
o(j,t,p)\
y(M,s,s)\
x(128(%[w]),e,e)\
q(r,n,r)\
c(j,f,n)\
z(u,m,m)\
o(G,g,g)\
c(G,k,k)\
q(n,f,n)\
C(B,h,m,h)\
z(u,i,i)\
o(F,t,t)\
c(F,p,p)\
x(v,h,h)\
C(B,s,i,s)\
x(192(%[w]),d,d)\
z(u,g,i)\
x(v,s,s)\
y(D,g,m)\
z(u,k,f)\
z(u,t,l)\
y(D,i,i)\
y(D,f,f)\
y(D,l,l)\
c(h,e,h)\
x(E,g,g)\
z(u,p,e)\
y(Q,e,e)\
c(s,d,s)\
z(u,m,m)\
y(D,k,d)\
C(B,i,m,i)\
x(E,k,k)\
y(D,t,m)\
x(v,i,i)\
x(E,t,t)\
z(u,d,d)\
z(u,m,m)\
C(B,f,d,f)\
y(Q,p,d)\
x(64(%[w]),p,p)\
C(B,l,m,l)\
x(v,f,f)\
c(i,g,i)\
o(j,r,g)\
o(j,h,m)\
o(n,r,r)\
c(n,g,n)\
x(v,l,l)\
z(u,d,d)\
c(s,m,m)\
z(u,r,g)\
o(s,h,s)\
C(B,e,d,e)\
y(D,r,d)\
z(u,n,h)\
y(D,g,g)\
x(v,e,e)\
y(N,h,h)\
c(f,k,f)\
c(l,t,l)\
y(N,n,t)\
z(u,m,k)\
x(E,r,r)\
y(O,k,k)\
z(u,d,d)\
x(256(%[w]),n,n)\
c(e,p,e)\
C(B,g,d,g)\
y(O,m,d)\
o(l,i,p)\
z(u,t,t)\
c(l,i,l)\
x(v,g,g)\
x(320(%[w]),m,m)\
C(B,h,t,h)\
o(e,f,t)\
c(e,f,e)\
c(j,p,f)\
z(u,d,d)\
x(v,h,h)\
c(j,t,i)\
q(f,p,f)\
C(B,k,d,k)\
o(j,l,d)\
o(j,e,p)\
q(i,t,i)\
x(v,k,k)\
q(d,l,d)\
q(p,e,p)\
c(j,s,e)\
c(g,r,g)\
q(e,s,e)\
c(h,n,h)\
o(j,f,n)\
o(j,i,s)\
o(j,d,r)\
o(j,p,l)\
o(g,f,f)\
c(k,m,k)\
c(g,n,g)\
o(e,i,i)\
c(e,s,e)\
o(h,d,d)\
c(h,r,h)\
o(k,p,p)\
c(k,l,k)\
c(j,f,l)\
c(j,g,r)\
c(j,i,s)\
c(j,e,n)\
c(j,d,m)\
c(j,h,t)\
q(l,f,l)\
q(r,g,r)\
c(j,p,g)\
c(j,k,f)\
q(s,i,s)\
q(n,e,n)\
q(m,d,m)\
q(t,h,t)\
q(g,p,g)\
q(f,k,f)\
c(v,l,k)\
c(v,r,p)\
c(v,s,h)\
c(v,n,d)\
c(v,m,e)\
c(v,t,i)\
q(k,l,k)\
q(p,r,p)\
c(v,g,r)\
c(v,f,l)\
q(h,s,h)\
q(d,n,d)\
A(k,(%[a]))\
q(e,m,e)\
q(i,t,i)\
q(r,g,r)\
q(l,f,l)\
A(p,(%[b]))\
A(h,G)\
A(d,I)\
A(e,J)\
A(i,K)\
A(r,F)\
A(l,H)\
R(u,%[a])\
R(u,%[b])\
T(%[end],%[a])\
U(1b)
	asm volatile(
		CP_FPS_ASM_BLOCK(CP_FPS_ASM_VPSUBD,%%ymm5,%%ymm4,%%ymm1,%%ymm2,%%ymm7,%%ymm11,%%ymm14,%%ymm9,%%ymm13,%%ymm8,%%ymm0,CP_FPS_ASM_VPADDD,%%ymm12,CP_FPS_ASM_VPMINUD,%%ymm6,%%ymm10,%%ymm3,$32,%%ymm15,CP_FPS_ASM_VPMULLD,CP_FPS_ASM_VPMULUDQ,CP_FPS_ASM_VPSRLQ,CP_FPS_ASM_VMOVDQA,$170,CP_FPS_ASM_VPBLENDD,32(%[w]),(%[w]),(%[a],%[h3]),(%[a],%[h]),(%[b],%[h3]),(%[b],%[h]),(%[a],%[h],2),(%[b],%[h],2),160(%[w]),224(%[w]),288(%[w]),352(%[w]),96(%[w]),CP_FPS_ASM_ADD,CP_FPS_ASM_VPBROADCASTD,CP_FPS_ASM_CMP,CP_FPS_ASM_JNE)
#undef CP_FPS_ASM_BLOCK
		: [a] "+r"(a), [b] "+r"(b)
		: [end] "r"(end), [h] "r"(32 * q), [h3] "r"(96 * q), [w] "r"(w), [P] "m"(kP), [P2] "m"(k2P)
		: "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "xmm8", "xmm9", "xmm10", "xmm11", "xmm12", "xmm13", "xmm14", "xmm15", "memory", "cc");
}

}

using ntt::detail::add;
using ntt::detail::diff;
using ntt::detail::Factor;
using ntt::detail::kP;
using ntt::detail::reduce;
using ntt::detail::slot;
using ntt::detail::Vec;

inline Vec times(Vec x, const Factor& f) { return ntt::detail::multiply(x, f); }

inline Vec diff_canonical(Vec x, Vec y) {
	return _mm256_sub_epi32(_mm256_add_epi32(x, ntt::detail::broadcast(kP)), y);
}



inline void forward_radix8(Vec* f, std::size_t q, const std::uint32_t* roots) {
	const Factor i(roots[1], roots[9]), y(roots[2], roots[10]), z(roots[3], roots[11]);
	for (std::size_t j = 0; j < q; ++j) {
		const Vec f0 = f[j], f1 = f[j + q], f2 = f[j + 2 * q], f3 = f[j + 3 * q];
		
		const Vec g0 = add(f0, f2), g1 = add(f1, f3);
		const Vec h0 = diff_canonical(f0, f2), ih1 = times(diff_canonical(f1, f3), i);
		f[j] = add(g0, g1), f[j + q] = diff(g0, g1);
		f[j + 2 * q] = add(h0, ih1), f[j + 3 * q] = diff(h0, ih1);
		
		const Vec if2 = times(f2, i), if3 = times(f3, i);
		const Vec u0 = reduce(add(f0, if2), 2 * kP), v0 = reduce(diff(f0, if2), 2 * kP);
		const Vec yu1 = times(add(f1, if3), y), zv1 = times(diff(f1, if3), z);
		f[j + 4 * q] = add(u0, yu1), f[j + 5 * q] = diff(u0, yu1);
		f[j + 6 * q] = add(v0, zv1), f[j + 7 * q] = diff(v0, zv1);
	}
}



class Subtrees {
public:
	Subtrees(const std::uint32_t* roots, const std::uint32_t* inverse_roots) : r_(roots), ir_(inverse_roots) {}

	void visit(Vec* a, Vec* b, std::size_t nv, std::size_t k) const {
		switch (nv) {
		case 16: return tile<16>(a, b, k);
		case 64: return tile<64>(a, b, k);
		case 256: return tile<256>(a, b, k);
		}
		const std::size_t h = nv / 4;
		forward(a, b, h, k);
		for (std::size_t t = 0; t < 4; ++t) visit(a + t * h, b + t * h, h, 4 * k + t);
		inverse(a, h, k);
	}

private:
	template <std::size_t NV>
	[[gnu::noinline]] void tile(Vec* a, Vec* b, std::size_t k) const {
		for (std::size_t h = NV / 4; h >= 4; h /= 4)
			for (std::size_t j = 0, g = k * (NV / (4 * h)); j < NV; j += 4 * h, ++g) forward(a + j, b + j, h, g);
		bottom(a, b, NV, k * (NV / 4));
		for (std::size_t h = 4; h < NV; h *= 4)
			for (std::size_t j = 0, g = k * (NV / (4 * h)); j < NV; j += 4 * h, ++g) inverse(a + j, h, g);
	}

	void forward(Vec* a, Vec* b, std::size_t h, std::size_t k) const {
		if (k == 0) {
			ntt::kernels::forward_identity(a, h, r_);
			ntt::kernels::forward_identity(b, h, r_);
			return;
		}
		const std::uint32_t *x = r_ + slot(k), *y = r_ + slot(2 * k);
		if (h == 4) return ntt::kernels::forward_pair(a, b, h, x, y);
		ntt::kernels::forward(a, h, x, y);
		ntt::kernels::forward(b, h, x, y);
	}

	void inverse(Vec* a, std::size_t h, std::size_t k) const {
		if (k == 0) return ntt::kernels::inverse_identity(a, h, ir_);
		ntt::kernels::inverse(a, h, ir_ + slot(k), ir_ + slot(2 * k));
	}

	struct alignas(64) Leaves {
		std::uint32_t window[4][16];
		std::uint32_t coefficients[4][8];
	};

	
	void bottom(Vec* a, Vec* b, std::size_t nv, std::size_t first) const {
		Leaves leaves[2][2]{};
		bottom_kernels::first(a, b, leaves[0], r_ + slot(first), r_ + slot(2 * first));
		for (std::size_t j = 0, k = first;; j += 8, k += 2) {
			const std::size_t cur = j / 8 % 2, next = cur ^ 1;
			const std::uint32_t *ix = ir_ + slot(k), *iy = ir_ + slot(2 * k);
			if (j + 8 == nv) return bottom_kernels::last(a + j, leaves[cur], ix, iy);
			bottom_kernels::both(a + j + 8, b + j + 8, leaves[next], r_ + slot(k + 2), r_ + slot(2 * k + 4), a + j,
								 leaves[cur], ix, iy);
		}
	}

	const std::uint32_t *r_, *ir_;
};


class Product {
public:
	static bool fits(std::size_t n, std::size_t m) {
		const int lg = log_length(n, m);
		return lg % 2 == 0 && lg >= 10 && 2 * std::max(n, m) <= std::size_t(1) << lg;
	}

	Product(std::size_t n, std::size_t m) : Product(n, m, nullptr) {}
	Product(std::size_t n, std::size_t m, std::uint32_t* borrowed_a) : lg_(log_length(n, m)) {
		const std::size_t len = length(), tables = ntt::detail::table_words(lg_);
		const std::size_t words = (borrowed_a ? 1 : 2) * (len + kPadding) + 2 * tables + (borrowed_a ? 1024 : 0);
		storage_ = allocate_fps_words(words);
		a_ = borrowed_a ? borrowed_a : storage_.get();
		const std::size_t color = ((reinterpret_cast<std::uintptr_t>(a_) >> 6) - (reinterpret_cast<std::uintptr_t>(storage_.get()) >> 6) + 1) & 63;
		b_ = storage_.get() + (borrowed_a ? 16 * color : len + kPadding);
		roots_ = b_ + len + kPadding;
		inverse_roots_ = roots_ + tables;
		std::fill(roots_, inverse_roots_ + tables, 0);
	}

	Product(const Product&) = delete;
	Product& operator=(const Product&) = delete;

	std::uint32_t* a() { return a_; }
	std::uint32_t* b() { return b_; }


	
	const std::uint32_t* multiply() {
		using namespace ntt::detail;
		const std::size_t len = length(), nv = len / 8, q = nv / 8;
		build_table(roots_, len / 16, kRoots[0]);
		build_table(inverse_roots_, len / 16, kRoots[1]);
		auto* a = reinterpret_cast<Vec*>(a_);
		auto* b = reinterpret_cast<Vec*>(b_);
		forward_radix8(a, q, roots_);
		forward_radix8(b, q, roots_);

		const Subtrees subtrees(roots_, inverse_roots_);
		for (std::size_t c = 0; c < 8; ++c) subtrees.visit(a + c * q, b + c * q, q, c);
		const std::uint32_t s = power(std::uint32_t(nv), kP - 2);
		const std::uint32_t *z0 = inverse_roots_ + 1, *x1 = inverse_roots_ + slot(1), *y1 = inverse_roots_ + slot(2);
		const std::uint32_t twiddles[6] = {s, multiply_mod(s, *z0), multiply_mod(s, y1[0]), multiply_mod(s, y1[1]),
										   multiply_mod(s, *x1), *x1};
		alignas(32) Vec w[12];
		for (int i = 0; i < 6; ++i) w[2 * i] = broadcast(twiddles[i]), w[2 * i + 1] = broadcast(quotient(twiddles[i]));
		top_kernels::inverse_top(a, q, w);
		return a_;
	}

private:
	static constexpr std::size_t kPadding = 16;

	static int log_length(std::size_t n, std::size_t m) { return std::max(6, int(std::bit_width(n + m - 2))); }
	std::size_t length() const { return std::size_t(1) << lg_; }

	int lg_;
	FpsWords storage_;
	std::uint32_t *a_, *b_, *roots_, *inverse_roots_;
};




inline void copy_input(const std::vector<Mint> &in, std::uint32_t *out, std::size_t len) {
	std::size_t i = 0;
	const auto p = _mm256_set1_epi32(Mint::mod());
	for (; i + 8 <= in.size(); i += 8) {
		const auto x = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(in.data() + i));
		_mm256_store_si256(reinterpret_cast<__m256i *>(out + i), _mm256_min_epu32(x, _mm256_sub_epi32(x, p)));
	}
	for (; i < in.size(); ++i) out[i] = std::min(in[i].v, in[i].v - Mint::mod());
	std::fill(out + i, out + (i <= len / 2 ? len / 2 : len), 0);
	std::fill(out + len, out + len + 16, 0);
}


inline void copy_input_mint(const std::vector<Mint>& in, Mint* out) {
	static_assert(sizeof(Mint) == sizeof(std::uint32_t) && std::is_trivially_copyable_v<Mint>);
	std::size_t i = 0;
	const auto p = _mm256_set1_epi32(Mint::mod());
	for (; i + 8 <= in.size(); i += 8) {
		__m256i x;
		std::memcpy(&x, in.data() + i, sizeof(x));
		x = _mm256_min_epu32(x, _mm256_sub_epi32(x, p));
		std::memcpy(static_cast<void*>(out + i), &x, sizeof(x));
	}
	for (; i < in.size(); ++i) out[i] = Mint::word(std::min(in[i].v, in[i].v - Mint::mod()));
}

template <class Plan>
inline std::vector<Mint> run_borrowed_as(const std::vector<Mint>& a, const std::vector<Mint>& b) {
	const std::size_t len = std::size_t(1) << std::max(6, int(std::bit_width(a.size() + b.size() - 2)));
	constexpr std::size_t alignment = 32;
	const std::size_t words = len + 16 + alignment / sizeof(Mint) - 1, size = a.size() + b.size() - 1;
	std::vector<Mint> result;
	prepare_fps_output(result, words);
	result.assign(words, Mint::word(0));
	const auto address = reinterpret_cast<std::uintptr_t>(result.data());
	const std::size_t offset = ((alignment - (address & (alignment - 1))) & (alignment - 1)) / sizeof(Mint);
	Mint* const to = result.data() + offset;
	Plan plan(a.size(), b.size(), reinterpret_cast<std::uint32_t*>(to));
	copy_input_mint(a, to);
	copy_input(b, plan.b(), len);
	plan.multiply();
	if (offset) std::memmove(static_cast<void*>(result.data()), to, size * sizeof(Mint));
	result.resize(size);
	return result;
}

inline std::vector<Mint> run_borrowed(const std::vector<Mint>& a, const std::vector<Mint>& b) {
	return run_borrowed_as<Product>(a, b);
}

template <class Plan>
inline std::vector<Mint> run(const std::vector<Mint> &a, const std::vector<Mint> &b) {
	Plan plan(a.size(), b.size());
	const auto len = std::size_t(1) << std::max(6, int(std::bit_width(a.size() + b.size() - 2)));
	copy_input(a, plan.a(), len);
	copy_input(b, plan.b(), len);
	const auto *p = plan.multiply();
	std::vector<Mint> result;
	const std::size_t size = a.size() + b.size() - 1;
	prepare_fps_output(result, size);
	append_fps_words<true>(result, p, size);
	return result;
}

inline std::vector<Mint> multiply(const std::vector<Mint> &a, const std::vector<Mint> &b) {
	assert(!a.empty() && !b.empty() && a.size() + b.size() - 1 <= (1 << 23));
	if (constant::fits(a, b)) return constant::multiply(a, b);
	if (unbalanced::fits(a.size(), b.size())) return unbalanced::multiply(a, b);
	if (Product::fits(a.size(), b.size())) return run_borrowed(a, b);
	return run_borrowed_as<ntt::Convolution>(a, b);
}

}
#pragma GCC pop_options
#endif

#endif
