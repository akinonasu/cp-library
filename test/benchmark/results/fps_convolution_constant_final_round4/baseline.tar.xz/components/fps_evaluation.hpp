#ifndef CP_COMPONENTS_FPS_EVALUATION_HPP
#define CP_COMPONENTS_FPS_EVALUATION_HPP

#include "fps_blocked.hpp"
#include <optional>

#if defined(__linux__) && defined(__x86_64__) && defined(__GNUC__) && !defined(__clang__)
#pragma GCC push_options
_Pragma("GCC target(\"avx2\")")
#pragma GCC optimize("O3")

namespace fps_detail {
namespace evaluation_poly {
using blocked_poly::Transform;
using blocked_poly::Half;
using blocked_poly::inverse;
using blocked_poly::inverse_log;
using blocked_poly::inverse_scratch;
using blocked_poly::derivative;
inline constexpr std::uint32_t kModulus = blocked_poly::kModulus;
class Arena : public blocked_poly::Arena {
public:
	explicit Arena(std::size_t words) : blocked_poly::Arena(words) {}
	std::span<std::uint32_t> take(std::size_t n) {
		auto span = blocked_poly::Arena::take(n);
		if (!zero_initialized()) std::fill(span.begin(), span.end(), 0u);
		return span;
	}
};
namespace detail {
using namespace blocked_poly::detail;
}
}
namespace evaluation_poly {
namespace detail {
inline Vec add_mod(Vec x, Vec y) { return reduce(add(x, y), kP); }
inline Vec subtract_mod(Vec x, Vec y) { return reduce(_mm256_sub_epi32(add(x, broadcast(kP)), y), kP); }
inline Vec to_montgomery(Vec x) { return reduce(times(x, Factor(kR)), kP); }
inline void forward_small(Vec* f, std::size_t m, std::size_t k, const std::uint32_t* roots) {
	if (m == 1) return;
	const std::size_t h = m / 2;
	const Factor s = entry(roots, k);
	for (std::size_t j = 0; j < h; ++j) {
		const Vec lo = f[j], hi = reduce(times(f[j + h], s), kP);
		f[j] = add_mod(lo, hi), f[j + h] = subtract_mod(lo, hi);
	}
	forward_small(f, h, 2 * k, roots);
	forward_small(f + h, h, 2 * k + 1, roots);
}
inline void inverse_small(Vec* f, std::size_t m, std::size_t k, const std::uint32_t* inverse_roots) {
	if (m == 1) return;
	const std::size_t h = m / 2;
	inverse_small(f, h, 2 * k, inverse_roots);
	inverse_small(f + h, h, 2 * k + 1, inverse_roots);
	const Factor s = entry(inverse_roots, k);
	for (std::size_t j = 0; j < h; ++j) {
		const Vec a = f[j], b = f[j + h];
		f[j] = add_mod(a, b), f[j + h] = reduce(times(_mm256_sub_epi32(add(a, broadcast(kP)), b), s), kP);
	}
}
inline void transpose8(Vec (&r)[8]) {
	Vec t[8], u[8];
	for (int i = 0; i < 8; i += 2) t[i] = _mm256_unpacklo_epi32(r[i], r[i + 1]), t[i + 1] = _mm256_unpackhi_epi32(r[i], r[i + 1]);
	for (int i = 0; i < 8; i += 4)
		for (int k = 0; k < 2; ++k)
			u[i + 2 * k] = _mm256_unpacklo_epi64(t[i + k], t[i + k + 2]), u[i + 2 * k + 1] = _mm256_unpackhi_epi64(t[i + k], t[i + k + 2]);
	for (int i = 0; i < 4; ++i)
		r[i] = _mm256_permute2x128_si256(u[i], u[i + 4], 0x20), r[i + 4] = _mm256_permute2x128_si256(u[i], u[i + 4], 0x31);
}
inline std::uint32_t montgomery_scalar(std::uint32_t x, std::uint32_t y) {
	constexpr std::uint32_t kInverseR = blocked_ntt::detail::power(kR, kP - 2);
	return blocked_ntt::detail::multiply_mod(blocked_ntt::detail::multiply_mod(x, y), kInverseR);
}
[[gnu::always_inline]] inline void multiply_lanes(const std::uint32_t* a, std::size_t m, const std::uint32_t* b, std::size_t k,
												std::uint32_t* c) {
	const Vec ni = broadcast(blocked_ntt::kernels::kNI), p = broadcast(kP), r = broadcast(kR);
	Vec x[33], xo[33], y[33], yo[33];
#pragma GCC unroll 33
	for (std::size_t i = 0; i <= m; ++i) x[i] = load(a + 8 * i), xo[i] = _mm256_srli_epi64(x[i], 32);
#pragma GCC unroll 33
	for (std::size_t j = 0; j <= k; ++j) y[j] = load(b + 8 * j), yo[j] = _mm256_srli_epi64(y[j], 32);
	const auto fold = [r](Vec s) { return _mm256_add_epi64(_mm256_mul_epu32(_mm256_srli_epi64(s, 32), r), _mm256_blend_epi32(s, _mm256_setzero_si256(), 0xAA)); };
#pragma GCC unroll 65
	for (std::size_t t = 0; t <= m + k; ++t) {
		Vec even = _mm256_setzero_si256(), odd = _mm256_setzero_si256();
		const std::size_t first = t > k ? t - k : 0, last = std::min(t, m);
#pragma GCC unroll 17
		for (std::size_t i = first; i <= last; ++i) {
			even = _mm256_add_epi64(even, _mm256_mul_epu32(x[i], y[t - i]));
			odd = _mm256_add_epi64(odd, _mm256_mul_epu32(xo[i], yo[t - i]));
		}
		if (last - first >= 12) even = fold(even), odd = fold(odd);
		even = _mm256_add_epi64(even, _mm256_mul_epu32(_mm256_mul_epu32(even, ni), p));
		odd = _mm256_add_epi64(odd, _mm256_mul_epu32(_mm256_mul_epu32(odd, ni), p));
		store(c + 8 * t, canonical(_mm256_blend_epi32(_mm256_srli_epi64(even, 32), odd, 0xAA)));
	}
}
inline void multiply_lanes_any(const std::uint32_t* a, std::size_t m, const std::uint32_t* b, std::size_t k, std::uint32_t* c) {
	if (m == k) {
		switch (m) {
			case 1: return multiply_lanes(a, 1, b, 1, c);
			case 2: return multiply_lanes(a, 2, b, 2, c);
			case 4: return multiply_lanes(a, 4, b, 4, c);
			case 8: return multiply_lanes(a, 8, b, 8, c);
			case 16: return multiply_lanes(a, 16, b, 16, c);
		}
	}
	multiply_lanes(a, m, b, k, c);
}
class Stack {
public:
	explicit Stack(std::span<std::uint32_t> memory) : base_(memory.data()), size_(memory.size()) {}
	std::size_t mark() const { return top_; }
	void release(std::size_t mark) { top_ = mark; }
	std::uint32_t* take(std::size_t n) {
		const std::size_t need = Arena::footprint(n);
		if (top_ + need > size_) std::abort();
		std::uint32_t* const p = base_ + top_;
		top_ += need;
		return p;
	}
private:
	std::uint32_t* base_;
	std::size_t size_, top_ = 0;
};
}
class TreeTransform {
public:
	static constexpr std::size_t words(int lg_max) {
		return Arena::footprint(2 * blocked_ntt::detail::table_words(std::max(lg_max, Transform::kMinLog)));
	}
	TreeTransform(Arena& arena, int lg_max) : lg_max_(lg_max) {
		if (lg_max < 3 || lg_max > Transform::kMaxLog) std::abort();
		const int lg = std::max(lg_max, Transform::kMinLog);
		const std::size_t table = blocked_ntt::detail::table_words(lg), entries = (std::size_t(1) << lg) / 16;
		roots_ = arena.take(2 * table).data();
		std::fill_n(roots_, 2 * table, 0u);
		inverse_roots_ = roots_ + table;
		blocked_ntt::detail::build_table(roots_, entries, blocked_ntt::detail::kRoots[0]);
		blocked_ntt::detail::build_table(inverse_roots_, entries, blocked_ntt::detail::kRoots[1]);
		for (int k = 3; k <= lg_max; ++k) leaf_scale_[k] = blocked_ntt::detail::power(std::uint32_t(1) << (k - 3), detail::kP - 2);
	}
	int lg_max() const { return lg_max_; }
	void forward(std::span<const std::uint32_t> in, std::size_t shift, std::span<std::uint32_t> out) const {
		using namespace detail;
		const Source src = source(in, shift, out.size());
		if (out.size() < 64) return small(src, out, 0);
		run(out, src, ForwardBottom{roots_}, 0);
	}
	void forward_upper(std::span<const std::uint32_t> in, std::size_t shift, std::span<std::uint32_t> out) const {
		using namespace detail;
		check_length(2 * out.size());
		const Source src = source(in, shift, out.size());
		if (out.size() < 64) return small(src, out, 1);
		const Recursion recursion(roots_, inverse_roots_, ForwardBottom{roots_});
		const std::size_t nv = out.size() / 8;
		auto* v = reinterpret_cast<Vec*>(out.data());
		if (std::countr_zero(nv) % 2 == 0) {
			for (std::size_t j = 0; j < nv; ++j) v[j] = src(j);
			return recursion.visit(out.data(), nv, 1);
		}
		const std::size_t h = nv / 2;
		const Factor z(roots_[1], roots_[9]);
		for (std::size_t j = 0; j < h; ++j) {
			const Vec a = src(j), zb = times(src(j + h), z);
			v[j] = add(a, zb), v[j + h] = diff(a, zb);
		}
		recursion.visit(out.data(), h, 2);
		recursion.visit(out.data() + 8 * h, h, 3);
	}
	void inverse(std::span<const std::uint32_t> in, std::span<std::uint32_t> out, std::uint32_t c = 1) const {
		using namespace detail;
		check_length(out.size());
		if (out.size() < 64) {
			const std::size_t nv = out.size() / 8;
			Vec f[4];
			for (std::size_t j = 0; j < nv; ++j) f[j] = load(in.data() + 8 * j);
			inverse_small(f, nv, 0, inverse_roots_);
			const Factor s(scale(out.size(), c));
			for (std::size_t j = 0; j < nv; ++j) store(out.data() + 8 * j, reduce(times(f[j], s), kP));
			return;
		}
		run(out, Source(nullptr, 0, 0), InverseBottom{inverse_roots_, in.data()}, scale(out.size(), c));
	}
	void inverse_upper(std::span<const std::uint32_t> in, std::span<std::uint32_t> out, std::uint32_t c = 1) const {
		using namespace detail;
		check_length(2 * out.size());
		const std::size_t nv = out.size() / 8;
		auto* v = reinterpret_cast<Vec*>(out.data());
		const Factor s(scale(out.size(), c));
		if (out.size() < 64) {
			Vec f[4];
			for (std::size_t j = 0; j < nv; ++j) f[j] = load(in.data() + 8 * j);
			inverse_small(f, nv, 1, inverse_roots_);
			for (std::size_t j = 0; j < nv; ++j) v[j] = reduce(times(f[j], s), kP);
			return;
		}
		const Recursion recursion(roots_, inverse_roots_, InverseBottom{inverse_roots_, in.data() - out.size()});
		if (std::countr_zero(nv) % 2 == 0) {
			const std::size_t h = nv / 4;
			for (std::size_t t = 0; t < 4; ++t) recursion.visit(out.data() + 8 * t * h, h, 4 + t);
			const Group w(inverse_roots_, 1);
			for (std::size_t j = 0; j < h; ++j) {
				Vec f[4] = {v[j], v[j + h], v[j + 2 * h], v[j + 3 * h]};
				inverse_h1(f, w);
				for (std::size_t t = 0; t < 4; ++t) v[j + t * h] = reduce(times(f[t], s), kP);
			}
			return;
		}
		const std::size_t h = nv / 2;
		recursion.visit(out.data(), h, 2);
		recursion.visit(out.data() + 8 * h, h, 3);
		const Factor sz(blocked_ntt::detail::multiply_mod(scale(out.size(), c), inverse_roots_[1]));
		for (std::size_t j = 0; j < h; ++j) {
			const Vec u = v[j], w = v[j + h];
			v[j] = reduce(times(add(u, w), s), kP), v[j + h] = reduce(times(diff(u, w), sz), kP);
		}
	}
	void leaf_products(const std::uint32_t* a, const std::uint32_t* b, std::span<std::uint32_t> out) const {
		using namespace detail;
		const std::size_t leaves = out.size() / 8;
		Window window[2];
		fill_window(window[0], load(a), leaf_weight(roots_, 0));
		for (std::size_t p = 0; p < leaves; ++p) {
			if (p + 1 < leaves) fill_window(window[(p + 1) & 1], load(a + 8 * p + 8), leaf_weight(roots_, p + 1));
			store(out.data() + 8 * p, reduce(leaf_product(window[p & 1], b + 8 * p), kP));
		}
	}
	void standard_to_lanes(const std::uint32_t* in, std::size_t stride, std::size_t n, std::uint32_t* out) const {
		using namespace detail;
		for (std::size_t p = 0; p < n / 8; ++p) {
			Vec f[8];
			for (std::size_t l = 0; l < 8; ++l) f[l] = load(in + l * stride + 8 * p);
			transpose8(f);
			const Factor z = entry(roots_, p);
			Vec lo[4], hi[4];
			for (std::size_t t = 0; t < 4; ++t) {
				const Vec zb = times(f[t + 4], z);
				lo[t] = add(f[t], zb), hi[t] = diff(f[t], zb);
			}
			forward_h1(lo, Group(roots_, 2 * p));
			forward_h1(hi, Group(roots_, 2 * p + 1));
			for (std::size_t t = 0; t < 4; ++t) store(out + 64 * p + 8 * t, canonical(lo[t])), store(out + 64 * p + 32 + 8 * t, canonical(hi[t]));
		}
	}
	void leaf_product_sums(const std::uint32_t* a, const std::uint32_t* b, const std::uint32_t* c, const std::uint32_t* d,
						std::span<std::uint32_t> out) const {
		using namespace detail;
		const std::size_t leaves = out.size() / 8;
		Window window[2][2];
		fill_window(window[0][0], load(a), leaf_weight(roots_, 0));
		fill_window(window[0][1], load(c), leaf_weight(roots_, 0));
		for (std::size_t p = 0; p < leaves; ++p) {
			if (p + 1 < leaves) {
				const Factor w = leaf_weight(roots_, p + 1);
				fill_window(window[(p + 1) & 1][0], load(a + 8 * p + 8), w);
				fill_window(window[(p + 1) & 1][1], load(c + 8 * p + 8), w);
			}
			const Vec ab = leaf_product(window[p & 1][0], b + 8 * p), cd = leaf_product(window[p & 1][1], d + 8 * p);
			store(out.data() + 8 * p, canonical(add(ab, cd)));
		}
	}
	static void pointwise_products(const std::uint32_t* a, const std::uint32_t* b, std::span<std::uint32_t> out) {
		using namespace detail;
		for (std::size_t i = 0; i < out.size(); i += 8) store(out.data() + i, reduce(montgomery(load(a + i), load(b + i)), kP));
	}
	static void pointwise_product_sums(const std::uint32_t* a, const std::uint32_t* b, const std::uint32_t* c, const std::uint32_t* d,
									std::span<std::uint32_t> out) {
		using namespace detail;
		const Vec ni = broadcast(blocked_ntt::kernels::kNI), p = broadcast(kP);
		for (std::size_t i = 0; i < out.size(); i += 8) {
			const Vec x = load(a + i), y = load(b + i), z = load(c + i), w = load(d + i);
			Vec even = _mm256_add_epi64(_mm256_mul_epu32(x, y), _mm256_mul_epu32(z, w));
			Vec odd = _mm256_add_epi64(_mm256_mul_epu32(_mm256_srli_epi64(x, 32), _mm256_srli_epi64(y, 32)),
									_mm256_mul_epu32(_mm256_srli_epi64(z, 32), _mm256_srli_epi64(w, 32)));
			even = _mm256_add_epi64(even, _mm256_mul_epu32(_mm256_mul_epu32(even, ni), p));
			odd = _mm256_add_epi64(odd, _mm256_mul_epu32(_mm256_mul_epu32(odd, ni), p));
			store(out.data() + i, reduce(_mm256_blend_epi32(_mm256_srli_epi64(even, 32), odd, 0xAA), kP));
		}
	}
private:
	std::uint32_t scale(std::size_t n, std::uint32_t c) const {
		const auto lg = std::countr_zero(n);
		if (lg > Transform::kMaxLog) std::abort();
		return blocked_ntt::detail::multiply_mod(leaf_scale_[lg], c);
	}
	void check_length(std::size_t n) const {
		if (!std::has_single_bit(n) || n < 8 || std::countr_zero(n) > lg_max_) std::abort();
	}
	detail::Source source(std::span<const std::uint32_t> in, std::size_t shift, std::size_t n) const {
		check_length(n);
		if (shift > n || in.size() > n - shift) std::abort();
		return detail::Source(in.data(), in.size(), shift);
	}
	void small(const detail::Source& src, std::span<std::uint32_t> out, std::size_t block) const {
		using namespace detail;
		const std::size_t nv = out.size() / 8;
		Vec f[4];
		for (std::size_t j = 0; j < nv; ++j) f[j] = src(j);
		forward_small(f, nv, block, roots_);
		for (std::size_t j = 0; j < nv; ++j) store(out.data() + 8 * j, f[j]);
	}
	template <class Bottom>
	void run(std::span<std::uint32_t> a, const detail::Source& in, const Bottom& bottom, std::uint32_t scale) const {
		using namespace detail;
		const Recursion recursion(roots_, inverse_roots_, bottom);
		const std::size_t nv = a.size() / 8;
		auto* v = reinterpret_cast<Vec*>(a.data());
		if (std::countr_zero(nv) % 2 == 0) {
			const std::size_t h = nv / 4;
			if constexpr (Bottom::kForward) forward_top4(in, v, h, roots_);
			for (std::size_t t = 0; t < 4; ++t) recursion.visit(a.data() + 8 * t * h, h, t);
			if constexpr (Bottom::kInverse) inverse_top4(v, h, Half::kBoth, inverse_roots_, Factor(scale));
		} else {
			const std::size_t h = nv / 2;
			if constexpr (Bottom::kForward) forward_top2(in, v, h);
			recursion.visit(a.data(), h, 0);
			recursion.visit(a.data() + 8 * h, h, 1);
			if constexpr (Bottom::kInverse) inverse_top2(v, h, Half::kBoth, scale);
		}
	}
	int lg_max_;
	std::uint32_t *roots_, *inverse_roots_;
	std::uint32_t leaf_scale_[Transform::kMaxLog + 1] = {};
};
struct LaneLayout {
	static constexpr std::size_t kWords = 8;
	static constexpr std::uint32_t kBase = 32;
	using Value = detail::Vec;
	struct Node {
		Value degree, lead;
	};
	static void multiply(const std::uint32_t* a, std::size_t m, const std::uint32_t* b, std::size_t k, std::uint32_t* c) {
		detail::multiply_lanes_any(a, m, b, k, c);
	}
	static std::size_t length(std::uint32_t degree) { return std::bit_ceil(std::max<std::uint32_t>(degree, 1)); }
	static void product(const TreeTransform&, const std::uint32_t* a, const std::uint32_t* b, std::span<std::uint32_t> out) {
		TreeTransform::pointwise_products(a, b, out);
	}
	static Value lead(const std::uint32_t* c, Value degree) {
		const Value index = _mm256_add_epi32(_mm256_slli_epi32(degree, 3), _mm256_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7));
		return _mm256_i32gather_epi32(reinterpret_cast<const int*>(c), index, 4);
	}
	static Value sum(Value x, Value y) { return _mm256_add_epi32(x, y); }
	static Value lead_product(Value x, Value y) { return detail::reduce(detail::montgomery(x, y), detail::kP); }
	static Value top(Value degree, Value lead, std::size_t length) {
		return _mm256_and_si256(_mm256_cmpeq_epi32(degree, detail::broadcast(std::uint32_t(length))), lead);
	}
	static void subtract(std::uint32_t* c, Value x) { detail::store(c, detail::subtract_mod(detail::load(c), x)); }
	static void add(std::uint32_t* c, Value x) { detail::store(c, detail::add_mod(detail::load(c), x)); }
	static void put(std::uint32_t* c, Value x) { detail::store(c, x); }
};
struct StandardLayout {
	static constexpr std::size_t kWords = 1;
	static constexpr std::uint32_t kBase = 0;
	using Value = std::uint32_t;
	struct Node {
		Value degree, lead;
	};
	static void multiply(const std::uint32_t*, std::size_t, const std::uint32_t*, std::size_t, std::uint32_t*) {}
	static std::size_t length(std::uint32_t degree) { return std::max<std::size_t>(8, std::bit_ceil(degree)); }
	static void product(const TreeTransform& t, const std::uint32_t* a, const std::uint32_t* b, std::span<std::uint32_t> out) {
		t.leaf_products(a, b, out);
	}
	static Value lead(const std::uint32_t* c, Value degree) { return c[degree]; }
	static Value sum(Value x, Value y) { return x + y; }
	static Value lead_product(Value x, Value y) { return detail::montgomery_scalar(x, y); }
	static Value top(Value degree, Value lead, std::size_t length) { return degree == length ? lead : 0; }
	static void subtract(std::uint32_t* c, Value x) { *c = *c >= x ? *c - x : *c + detail::kP - x; }
	static void add(std::uint32_t* c, Value x) { *c = *c + x >= detail::kP ? *c + x - detail::kP : *c + x; }
	static void put(std::uint32_t* c, Value x) { *c = x; }
};
struct DropTransforms {
	void operator()(std::size_t, std::size_t, std::span<const std::uint32_t>) const {}
};
template <class Layout, class Leaves, class Keep = DropTransforms>
class ProductTree {
public:
	using Value = typename Layout::Value;
	using Node = typename Layout::Node;
	static constexpr bool kPlaces = requires(Keep k, std::size_t i) { k.place(i, i, i, i); };
	struct Root {
		std::span<std::uint32_t> coefficients;
		Node node;
		std::size_t length;
	};
	static std::size_t scratch_words(std::size_t count, std::size_t total) {
		return Arena::footprint(count + 1) + 8 * Arena::footprint(Layout::kWords * (Layout::length(std::uint32_t(total)) + 1)) + 4096;
	}
	ProductTree(const TreeTransform& t, const Leaves& leaves, std::span<std::uint32_t> scratch, Keep keep = {})
		: t_(t), leaves_(leaves), keep_(keep), stack_(scratch), count_(leaves.count()), prefix_(stack_.take(count_ + 1)) {
		prefix_[0] = 0;
		for (std::size_t k = 0; k < count_; ++k) prefix_[k + 1] = prefix_[k] + leaves.degree(k);
	}
	Root root() {
		const std::size_t count = count_, length = Layout::length(degree(0, count));
		constexpr std::size_t w = Layout::kWords;
		std::uint32_t* const c = stack_.take(w * (length + 1));
		if (count == 1 || degree(0, count) <= Layout::kBase) {
			std::fill_n(c, w * (length + 1), 0);
			return {{c, w * (length + 1)}, coefficients(0, count, c), length};
		}
		std::uint32_t* const a = stack_.take(w * length);
		const std::size_t mid = split(0, count);
		std::uint32_t *left_out = a, *right_out = c;
		if constexpr (kPlaces) left_out = keep_.place(0, mid, count, w * length), right_out = left_out + Arena::footprint(w * length);
		const Node left = build(0, mid, left_out, length), right = build(mid, count, right_out, length);
		Layout::product(t_, left_out, right_out, {a, w * length});
		if constexpr (requires { keep_.root(std::span<const std::uint32_t>{}); }) keep_.root(std::span<const std::uint32_t>(a, w * length));
		t_.inverse({a, w * length}, {c, w * length});
		const Node node{Layout::sum(left.degree, right.degree), Layout::lead_product(left.lead, right.lead)};
		const Value top = Layout::top(node.degree, node.lead, length);
		Layout::subtract(c, top);
		Layout::put(c + w * length, top);
		return {{c, w * (length + 1)}, node, length};
	}
	std::size_t split(std::size_t lo, std::size_t hi) const {
		const std::uint32_t target = prefix_[lo] + (prefix_[hi] - prefix_[lo]) / 2;
		std::size_t mid = std::size_t(std::lower_bound(prefix_ + lo + 1, prefix_ + hi - 1, target) - prefix_);
		if (mid > lo + 1 && prefix_[mid] >= target && target - prefix_[mid - 1] < prefix_[mid] - target) --mid;
		return mid;
	}
	std::uint32_t degree(std::size_t lo, std::size_t hi) const { return prefix_[hi] - prefix_[lo]; }
private:
	Node coefficients(std::size_t lo, std::size_t hi, std::uint32_t* c) const {
		if (hi - lo == 1) return leaves_.load(lo, c);
		constexpr std::size_t w = Layout::kWords, kMax = std::max<std::size_t>(Layout::kBase, 1);
		struct Part {
			std::uint32_t* c;
			std::size_t degree;
		};
		Part part[kMax];
		alignas(32) std::uint32_t memory[2][w * 2 * kMax];
		std::size_t count = hi - lo;
		std::uint32_t* to = memory[0];
		Value degree{};
		for (std::size_t k = 0; k < count; ++k) {
			const Value d = leaves_.load(lo + k, to).degree;
			degree = k ? Layout::sum(degree, d) : d;
			part[k] = {to, leaves_.degree(lo + k)};
			to += w * (part[k].degree + 1);
		}
		for (std::size_t level = 1; count > 1; ++level) {
			to = count == 2 ? c : memory[level & 1];
			std::size_t next = 0;
			for (std::size_t k = 0; k + 1 < count; k += 2) {
				const Part &a = part[k], &b = part[k + 1];
				Layout::multiply(a.c, a.degree, b.c, b.degree, to);
				part[next++] = {to, a.degree + b.degree};
				to += w * (a.degree + b.degree + 1);
			}
			if (count % 2) {
				const Part& a = part[count - 1];
				std::copy_n(a.c, w * (a.degree + 1), to);
				part[next++] = {to, a.degree};
			}
			count = next;
		}
		return {degree, Layout::lead(c, degree)};
	}
	Node build(std::size_t lo, std::size_t hi, std::uint32_t* out, std::size_t out_length) {
		constexpr std::size_t w = Layout::kWords;
		if (hi - lo == 1 || degree(lo, hi) <= Layout::kBase) {
			const Node node = coefficients(lo, hi, out);
			t_.forward({out, w * (degree(lo, hi) + 1)}, 0, {out, w * out_length});
			if constexpr (!kPlaces) keep_(lo, hi, std::span<const std::uint32_t>(out, w * out_length));
			return node;
		}
		const std::size_t length = Layout::length(degree(lo, hi)), words = w * length, mark = stack_.mark();
		std::uint32_t *a, *b, *c;
		std::size_t mid;
		if constexpr (kPlaces) {
			mid = split(lo, hi);
			a = keep_.place(lo, mid, hi, words), b = a + Arena::footprint(words), c = stack_.take(words + w);
		} else {
			a = out_length >= 2 * length ? out + words : stack_.take(words);
			b = c = stack_.take(words + w);
			mid = split(lo, hi);
		}
		const Node left = build(lo, mid, a, length), right = build(mid, hi, b, length);
		const Node node{Layout::sum(left.degree, right.degree), Layout::lead_product(left.lead, right.lead)};
		Layout::product(t_, a, b, {out, words});
		if (out_length > length) {
			t_.inverse({out, words}, {c, words});
			const Value top = Layout::top(node.degree, node.lead, length);
			Layout::subtract(c, top);
			Layout::subtract(c, top);
			t_.forward_upper({c, words}, 0, {out + words, words});
			Layout::add(c, top);
			Layout::put(c + words, top);
			for (std::size_t m = 2 * length; m < out_length; m *= 2) t_.forward_upper({c, words + w}, 0, {out + w * m, w * m});
		}
		stack_.release(mark);
		if constexpr (!kPlaces) keep_(lo, hi, std::span<const std::uint32_t>(out, w * out_length));
		return node;
	}
	const TreeTransform& t_;
	const Leaves& leaves_;
	Keep keep_;
	detail::Stack stack_;
	std::size_t count_;
	std::uint32_t* prefix_;
};
inline void lane_columns(const std::uint32_t* c, std::size_t count, const std::uint32_t (&size)[8],
						std::uint32_t* const (&out)[8]) {
	using namespace detail;
	const std::size_t longest = *std::max_element(size, size + 8);
	for (std::size_t j = 0; j < longest; j += 8) {
		Vec r[8];
		for (std::size_t i = 0; i < 8; ++i) r[i] = j + i < count ? load(c + 8 * (j + i)) : _mm256_setzero_si256();
		transpose8(r);
		for (int l = 0; l < 8; ++l)
			if (j < size[l]) store_unaligned(out[l] + j, r[l]);
	}
}
}
namespace evaluation_poly {
namespace detail {
[[gnu::always_inline]] inline Vec montgomery_sums(Vec even, Vec odd, std::size_t terms) {
	const Vec ni = broadcast(blocked_ntt::kernels::kNI), p = broadcast(kP), r = broadcast(kR);
	const auto fold = [r](Vec s) { return _mm256_add_epi64(_mm256_mul_epu32(_mm256_srli_epi64(s, 32), r), _mm256_blend_epi32(s, _mm256_setzero_si256(), 0xAA)); };
	if (terms > 12) even = fold(even), odd = fold(odd);
	even = _mm256_add_epi64(even, _mm256_mul_epu32(_mm256_mul_epu32(even, ni), p));
	odd = _mm256_add_epi64(odd, _mm256_mul_epu32(_mm256_mul_epu32(odd, ni), p));
	return canonical(_mm256_blend_epi32(_mm256_srli_epi64(even, 32), odd, 0xAA));
}
template <std::size_t K, std::size_t C, std::size_t B>
[[gnu::always_inline]] inline void middle_lanes(const std::uint32_t* w, const std::uint32_t* q, std::uint32_t* out) {
	static_assert(K <= 16);
	Vec wo[K + C], qo[K + 1];
#pragma GCC unroll 32
	for (std::size_t i = 0; i < K + C; ++i) wo[i] = _mm256_srli_epi64(load(w + 8 * i), 32);
#pragma GCC unroll 17
	for (std::size_t j = 0; j <= K; ++j) qo[j] = _mm256_srli_epi64(load(q + 8 * j), 32);
	for (std::size_t t0 = 0; t0 < C; t0 += B) {
		Vec even[B], odd[B];
#pragma GCC unroll 8
		for (std::size_t s = 0; s < B; ++s) even[s] = odd[s] = _mm256_setzero_si256();
#pragma GCC unroll 17
		for (std::size_t j = 0; j <= K; ++j) {
			const Vec y = load(q + 8 * j);
#pragma GCC unroll 8
			for (std::size_t s = 0; s < B && t0 + s < C; ++s) {
				even[s] = _mm256_add_epi64(even[s], _mm256_mul_epu32(load(w + 8 * (K + t0 + s - j)), y));
				odd[s] = _mm256_add_epi64(odd[s], _mm256_mul_epu32(wo[K + t0 + s - j], qo[j]));
			}
		}
#pragma GCC unroll 8
		for (std::size_t s = 0; s < B && t0 + s < C; ++s) store(out + 8 * (t0 + s), montgomery_sums(even[s], odd[s], K + 1));
	}
}
[[gnu::noinline]] inline void middle_lanes(const std::uint32_t* w, std::size_t k, const std::uint32_t* q, std::size_t count,
										std::uint32_t* out) {
	for (std::size_t t = 0; t < count; ++t) {
		Vec even = _mm256_setzero_si256(), odd = _mm256_setzero_si256();
		for (std::size_t j = 0; j <= k; ++j) {
			const Vec x = load(w + 8 * (k + t - j)), y = load(q + 8 * j);
			even = _mm256_add_epi64(even, _mm256_mul_epu32(x, y));
			odd = _mm256_add_epi64(odd, _mm256_mul_epu32(_mm256_srli_epi64(x, 32), _mm256_srli_epi64(y, 32)));
		}
		store(out + 8 * t, montgomery_sums(even, odd, k + 1));
	}
}
struct PointSlots {
	const std::uint32_t* points;
	std::size_t slots;
	std::size_t count() const { return slots; }
	std::uint32_t degree(std::size_t) const { return 1; }
	LaneLayout::Node load(std::size_t k, std::uint32_t* c) const {
		const Vec lead = to_montgomery(_mm256_sub_epi32(broadcast(kP), detail::load(points + 8 * k)));
		store(c, broadcast(kR));
		store(c + 8, lead);
		return {broadcast(1), lead};
	}
};
struct LaneProducts {
	const std::uint32_t* c;
	std::size_t stride;
	std::uint32_t lane_degree;
	std::size_t count() const { return 8; }
	std::uint32_t degree(std::size_t) const { return lane_degree; }
	StandardLayout::Node load(std::size_t k, std::uint32_t* out) const {
		std::copy_n(c + k * stride, lane_degree + 1, out);
		return {lane_degree, out[lane_degree]};
	}
};
class TransformStore {
public:
	struct Keeper {
		TransformStore* store;
		std::uint32_t* place(std::size_t, std::size_t mid, std::size_t, std::size_t words) const { return store->place(mid, words); }
		void root(std::span<const std::uint32_t> transform) const { store->root_ = transform; }
	};
	void reset(std::span<std::uint32_t> words, std::span<std::uint32_t> index) { words_ = words, used_ = 0, pair_ = index.data(); }
	std::uint32_t* place(std::size_t mid, std::size_t words) {
		const std::size_t need = 2 * Arena::footprint(words);
		if (used_ + need > words_.size()) std::abort();
		pair_[mid] = std::uint32_t(used_);
		used_ += need;
		return words_.data() + pair_[mid];
	}
	const std::uint32_t* pair(std::size_t mid) const { return words_.data() + pair_[mid]; }
	std::span<const std::uint32_t> root() const { return root_; }
private:
	std::span<const std::uint32_t> root_;
	std::span<std::uint32_t> words_;
	std::size_t used_ = 0;
	std::uint32_t* pair_ = nullptr;
};
template <class Layout, class Tree>
std::size_t kept_words(const Tree& tree, std::size_t lo, std::size_t hi) {
	if (hi - lo == 1 || tree.degree(lo, hi) <= Layout::kBase) return 0;
	const std::size_t mid = tree.split(lo, hi), words = Layout::kWords * Layout::length(tree.degree(lo, hi));
	return 2 * Arena::footprint(words) + kept_words<Layout>(tree, lo, mid) + kept_words<Layout>(tree, mid, hi);
}
template <std::size_t D>
void product_level(const std::uint32_t* children, std::uint32_t* out, std::size_t nodes) {
	for (std::size_t i = 0; i < nodes; ++i)
		multiply_lanes(children + 8 * (D + 1) * (2 * i), D, children + 8 * (D + 1) * (2 * i + 1), D, out + 8 * (2 * D + 1) * i);
}
constexpr std::size_t middle_block(std::size_t d) { return d >= 16 ? 0 : d == 8 ? 3 : d == 4 ? 4 : 2; }
template <std::size_t D>
void middle_level(const std::uint32_t* parents, const std::uint32_t* products, std::uint32_t* out, std::size_t nodes) {
	for (std::size_t i = 0; i < nodes; ++i) {
		const std::uint32_t *w = parents + 16 * D * (i / 2), *q = products + 8 * (D + 1) * (i ^ 1);
		if constexpr (middle_block(D) == 0) middle_lanes(w, D, q, D, out + 8 * D * i);
		else middle_lanes<D, D, middle_block(D)>(w, q, out + 8 * D * i);
	}
}
template <class F>
void with_degree(std::size_t d, F&& f) {
	switch (d) {
		case 1: return f.template operator()<1>();
		case 2: return f.template operator()<2>();
		case 4: return f.template operator()<4>();
		case 8: return f.template operator()<8>();
		case 16: return f.template operator()<16>();
		default: std::abort();
	}
}
class BaseDescent {
public:
	BaseDescent(const PointSlots& slots, std::uint32_t* values) : slots_(slots), values_(values) {}
	void run(std::size_t lo, std::size_t hi, const std::uint32_t* w) {
		const std::size_t count = hi - lo;
		if (count == 1) return store(values_ + 8 * lo, load(w));
		if (std::has_single_bit(count)) return run_levels(lo, count, w);
		free_ = memory_;
		build(1, lo, hi);
		descend(1, lo, hi, w);
	}
private:
	void run_levels(std::size_t lo, std::size_t count, const std::uint32_t* w) {
		const std::uint32_t* products[6];
		std::uint32_t* at = memory_;
		for (std::size_t k = 0; k < count; ++k) slots_.load(lo + k, at + 16 * k);
		products[0] = at;
		at += 16 * count;
		for (std::size_t d = 1, j = 1; 2 * d < count; d *= 2, ++j) {
			with_degree(d, [&]<std::size_t D>() {
				if constexpr (D <= LaneLayout::kBase / 4) product_level<D>(products[j - 1], at, count / (2 * D));
			});
			products[j] = at;
			at += 8 * (2 * d + 1) * (count / (2 * d));
		}
		std::uint32_t* const windows[2] = {at, at + 8 * count};
		const std::uint32_t* parents = w;
		for (std::size_t d = count / 2, j = std::countr_zero(count) - 1;; d /= 2, --j) {
			std::uint32_t* const out = d == 1 ? values_ + 8 * lo : windows[j & 1];
			with_degree(d, [&]<std::size_t D>() { middle_level<D>(parents, products[j], out, count / D); });
			if (d == 1) return;
			parents = out;
		}
	}
	const std::uint32_t* build(std::size_t v, std::size_t lo, std::size_t hi) {
		std::uint32_t* const c = free_;
		if (hi - lo == 1) {
			slots_.load(lo, c);
			free_ += 16;
			return c;
		}
		const std::size_t mid = lo + (hi - lo) / 2;
		product_[2 * v] = build(2 * v, lo, mid);
		product_[2 * v + 1] = build(2 * v + 1, mid, hi);
		if (v == 1) return nullptr;
		std::uint32_t* const out = free_;
		multiply_lanes_any(product_[2 * v], mid - lo, product_[2 * v + 1], hi - mid, out);
		free_ += 8 * (hi - lo + 1);
		return out;
	}
	void descend(std::size_t v, std::size_t lo, std::size_t hi, const std::uint32_t* w) {
		if (hi - lo == 1) return store(values_ + 8 * lo, load(w));
		const std::size_t mid = lo + (hi - lo) / 2;
		std::uint32_t* const left = free_;
		std::uint32_t* const right = left + 8 * (mid - lo);
		free_ = right + 8 * (hi - mid);
		middle_lanes(w, hi - mid, product_[2 * v + 1], mid - lo, left);
		middle_lanes(w, mid - lo, product_[2 * v], hi - mid, right);
		descend(2 * v, lo, mid, left);
		descend(2 * v + 1, mid, hi, right);
		free_ = left;
	}
	alignas(32) std::uint32_t memory_[8 * 320];
	const std::uint32_t* product_[64];
	std::uint32_t* free_ = memory_;
	const PointSlots& slots_;
	std::uint32_t* values_;
};
}
class PointTree {
public:
	static std::size_t words(std::size_t m) {
		const std::size_t m8 = (m + 7) / 8 * 8, count = m8 / 8, levels = std::bit_width(count) + 1;
		const std::size_t top_length = StandardLayout::length(std::uint32_t(m8));
		const std::size_t kept_lanes = levels * (32 * count + 64 * (count / 32 + 1));
		const std::size_t kept_top = 14 * Arena::footprint(top_length);
		return TreeTransform::words(log_length(m8)) + Arena::footprint(m8) + Arena::footprint(LaneTree::scratch_words(count, count)) +
			Arena::footprint(kept_lanes) + Arena::footprint(count) +
			Arena::footprint(8 * ((count + 8) / 8 * 8)) + Arena::footprint(TopTree::scratch_words(8, m8)) +
			Arena::footprint(kept_top) + Arena::footprint(8);
	}
	static std::size_t descend_words(std::size_t m) {
		const std::size_t m8 = (m + 7) / 8 * 8;
		const std::size_t lane_length = LaneLayout::length(std::uint32_t(m8 / 8)), top_length = StandardLayout::length(std::uint32_t(m8));
		return 2 * Arena::footprint(8 * std::max<std::size_t>(8, lane_length)) + 5 * Arena::footprint(top_length) +
			4 * Arena::footprint(8 * lane_length) + 4096;
	}
	PointTree(Arena& arena, std::span<const std::uint32_t> points)
		: m8_((points.size() + 7) / 8 * 8), count_(m8_ / 8), t_(arena, log_length(m8_)) {
		using namespace detail;
		std::uint32_t* const padded = arena.take(m8_).data();
		std::copy(points.begin(), points.end(), padded);
		slots_ = {padded, count_};
		lanes_.emplace(t_, slots_, arena.take(LaneTree::scratch_words(count_, count_)), TransformStore::Keeper{&lane_store_});
		lane_store_.reset(arena.take(kept_words<LaneLayout>(*lanes_, 0, count_)), arena.take(count_));
		const LaneTree::Root lane_root = lanes_->root();
		const std::size_t stride = (count_ + 8) / 8 * 8;
		std::uint32_t* const columns = arena.take(8 * stride).data();
		const std::uint32_t size = std::uint32_t(count_ + 1);
		const std::uint32_t sizes[8] = {size, size, size, size, size, size, size, size};
		std::uint32_t* const out[8] = {columns, columns + stride, columns + 2 * stride, columns + 3 * stride,
									columns + 4 * stride, columns + 5 * stride, columns + 6 * stride, columns + 7 * stride};
		lane_columns(lane_root.coefficients.data(), lane_root.length + 1, sizes, out);
		lane_products_ = {columns, stride, std::uint32_t(count_)};
		top_.emplace(t_, lane_products_, arena.take(TopTree::scratch_words(8, m8_)), TransformStore::Keeper{&top_store_});
		top_store_.reset(arena.take(kept_words<StandardLayout>(*top_, 0, 8)), arena.take(8));
		product_ = top_->root().coefficients.first(m8_ + 1);
	}
	PointTree(const PointTree&) = delete;
	PointTree& operator=(const PointTree&) = delete;
	std::size_t size() const { return m8_; }
	std::span<const std::uint32_t> product() const { return product_; }
	std::span<const std::uint32_t> product_transform() const { return top_store_.root(); }
	void descend(std::span<const std::uint32_t> w, std::span<std::uint32_t> values, std::uint32_t c, std::span<std::uint32_t> scratch) {
		using namespace detail;
		Stack stack(scratch);
		const std::size_t lane_length = LaneLayout::length(std::uint32_t(count_));
		const LaneState root = lane_state(w, c, stack);
		BaseDescent base(slots_, values.data());
		if (count_ <= LaneLayout::kBase) return base.run(0, count_, root.state + 8 * (lane_length - count_));
		descend_lanes(0, count_, root.state, root.u, stack, base);
	}
protected:
	using LaneTree = ProductTree<LaneLayout, detail::PointSlots, detail::TransformStore::Keeper>;
	using TopTree = ProductTree<StandardLayout, detail::LaneProducts, detail::TransformStore::Keeper>;
	static int log_length(std::size_t m8) {
		const std::size_t lanes = 8 * LaneLayout::length(std::uint32_t(m8 / 8)), top = StandardLayout::length(std::uint32_t(m8));
		return std::countr_zero(std::max(lanes, top));
	}
	void halve(std::uint32_t* p, std::size_t words) const {
		using namespace detail;
		const std::size_t h = words / 2;
		t_.inverse_upper({p + h, h}, {p + h, h}, kP - 1);
		t_.forward({p + h, h}, 0, {p + h, h});
		for (std::size_t i = 0; i < h; i += 8) store(p + i, add_mod(load(p + i), load(p + h + i)));
	}
	void coefficients(std::uint32_t* p, std::size_t words, std::uint32_t u) const {
		using namespace detail;
		if (words == 8) return t_.inverse({p, 8}, {p, 8}, u);
		const std::size_t h = words / 2;
		const std::uint32_t c = half(u);
		t_.inverse({p, h}, {p, h}, c);
		t_.inverse_upper({p + h, h}, {p + h, h}, kP - c);
		for (std::size_t i = 0; i < h; i += 8) {
			const Vec a = load(p + i), b = load(p + h + i);
			store(p + i, subtract_mod(a, b)), store(p + h + i, add_mod(a, b));
		}
	}
	struct LaneState {
		std::uint32_t* state;
		std::uint32_t u;
	};
	LaneState lane_state(std::span<const std::uint32_t> w, std::uint32_t c, detail::Stack& stack) {
		using namespace detail;
		const std::size_t lane_length = LaneLayout::length(std::uint32_t(count_)), stride = std::max<std::size_t>(8, lane_length);
		const bool transform = count_ > LaneLayout::kBase;
		std::uint32_t* const lanes = stack.take(8 * stride);
		const std::size_t mark = stack.mark();
		std::uint32_t* const columns = stack.take(8 * stride);
		if (!transform) std::fill_n(columns, 8 * stride, 0);
		const std::size_t length = StandardLayout::length(std::uint32_t(m8_));
		std::uint32_t* const root = stack.take(length);
		t_.forward(w, length - m8_, {root, length});
		std::uint32_t u = 1;
		descend_top(0, 8, root, c, stack, columns, lane_length, stride, transform ? &u : nullptr);
		if (transform) {
			t_.standard_to_lanes(columns, stride, lane_length, lanes);
		} else {
			for (std::size_t j = 0; j < stride; j += 8) {
				Vec r[8];
				for (std::size_t l = 0; l < 8; ++l) r[l] = load(columns + l * stride + j);
				transpose8(r);
				for (std::size_t i = 0; i < 8; ++i) store(lanes + 8 * (j + i), r[i]);
			}
		}
		stack.release(mark);
		return {lanes, u};
	}
	void descend_top(std::size_t lo, std::size_t hi, const std::uint32_t* s, std::uint32_t u, detail::Stack& stack,
					std::uint32_t* columns, std::size_t lane_length, std::size_t stride, std::uint32_t* leaf_u) {
		const TopTree& tree = *top_;
		const std::size_t length = StandardLayout::length(tree.degree(lo, hi)), mid = tree.split(lo, hi);
		const std::size_t sides[2][2] = {{lo, mid}, {mid, hi}};
		for (int side = 0; side < 2; ++side) {
			const std::size_t xlo = sides[side][0], xhi = sides[side][1], inner = StandardLayout::length(tree.degree(xlo, xhi));
			const std::size_t mark = stack.mark();
			std::uint32_t* const p = stack.take(length);
			t_.leaf_products(s, top_store_.pair(mid) + (1 - side) * Arena::footprint(length), {p, length});
			if (xhi - xlo == 1 && leaf_u) {
				halve(p, length);
				std::copy_n(p, lane_length, columns + xlo * stride);
				*leaf_u = half(u);
			} else if (xhi - xlo == 1) {
				coefficients(p, length, u);
				std::copy_n(p + length - lane_length, lane_length, columns + xlo * stride);
			} else if (2 * inner == length) {
				halve(p, length);
				descend_top(xlo, xhi, p, half(u), stack, columns, lane_length, stride, leaf_u);
			} else {
				coefficients(p, length, u);
				std::uint32_t* const q = stack.take(inner);
				t_.forward({p + length - inner, inner}, 0, {q, inner});
				descend_top(xlo, xhi, q, 1, stack, columns, lane_length, stride, leaf_u);
			}
			stack.release(mark);
		}
	}
	void descend_lanes(std::size_t lo, std::size_t hi, const std::uint32_t* s, std::uint32_t u, detail::Stack& stack,
					detail::BaseDescent& base) {
		const LaneTree& tree = *lanes_;
		const std::size_t words = 8 * LaneLayout::length(std::uint32_t(tree.degree(lo, hi))), mid = tree.split(lo, hi);
		const std::size_t sides[2][2] = {{lo, mid}, {mid, hi}};
		for (int side = 0; side < 2; ++side) {
			const std::size_t xlo = sides[side][0], xhi = sides[side][1], degree = tree.degree(xlo, xhi);
			const std::size_t inner = 8 * LaneLayout::length(std::uint32_t(degree)), mark = stack.mark();
			std::uint32_t* const p = stack.take(words);
			TreeTransform::pointwise_products(s, lane_store_.pair(mid) + (1 - side) * Arena::footprint(words), {p, words});
			if (xhi - xlo == 1 || degree <= LaneLayout::kBase) {
				coefficients(p, words, u);
				base.run(xlo, xhi, p + words - 8 * degree);
			} else if (2 * inner == words) {
				halve(p, words);
				descend_lanes(xlo, xhi, p, half(u), stack, base);
			} else {
				coefficients(p, words, u);
				std::uint32_t* const q = stack.take(inner);
				t_.forward({p + words - inner, inner}, 0, {q, inner});
				descend_lanes(xlo, xhi, q, 1, stack, base);
			}
			stack.release(mark);
		}
	}
	static std::uint32_t half(std::uint32_t u) { return blocked_ntt::detail::multiply_mod(u, (detail::kP + 1) / 2); }
	std::size_t m8_, count_;
	TreeTransform t_;
	detail::PointSlots slots_{};
	detail::LaneProducts lane_products_{};
	detail::TransformStore lane_store_, top_store_;
	std::optional<LaneTree> lanes_;
	std::optional<TopTree> top_;
	std::span<const std::uint32_t> product_;
};
namespace detail {
inline constexpr std::size_t kDirectEvaluation = std::size_t(1) << 22;
inline void evaluate_direct(std::span<const std::uint32_t> f, std::span<const std::uint32_t> points, std::span<std::uint32_t> values) {
	constexpr std::size_t kChains = 4;
	const Factor to_r(kR);
	for (std::size_t i = 0; i < points.size(); i += 8 * kChains) {
		alignas(32) std::uint32_t x[8 * kChains] = {}, v[8 * kChains];
		const std::size_t here = std::min<std::size_t>(8 * kChains, points.size() - i);
		std::copy_n(points.begin() + std::ptrdiff_t(i), here, x);
		Vec xm[kChains], acc[kChains];
		for (std::size_t c = 0; c < kChains; ++c) xm[c] = reduce(times(load(x + 8 * c), to_r), kP), acc[c] = _mm256_setzero_si256();
		for (std::size_t j = f.size(); j-- > 0;) {
			const Vec fj = broadcast(f[j]);
			for (std::size_t c = 0; c < kChains; ++c) acc[c] = reduce(add(montgomery(acc[c], xm[c]), fj), 2 * kP);
		}
		for (std::size_t c = 0; c < kChains; ++c) store(v + 8 * c, reduce(acc[c], kP));
		std::copy_n(v, here, values.begin() + std::ptrdiff_t(i));
	}
}
struct Division {
	std::size_t big, k, length;
	Division(std::size_t n, std::size_t m8)
		: big(std::max(n, m8)), k((big + 1) / 2), length(std::max<std::size_t>(64, std::bit_ceil(std::max(2 * k - 1, big)))) {}
	int log() const { return std::max(inverse_log(k), std::countr_zero(length)); }
	std::size_t scratch_words() const {
		return Arena::footprint(big) + Arena::footprint(k) + Arena::footprint(inverse_scratch(k)) + 3 * Arena::footprint(length);
	}
};
inline void divide(const Transform& t, const Division& s, std::span<const std::uint32_t> f, std::span<const std::uint32_t> q,
				std::span<const std::uint32_t> qt, std::span<std::uint32_t> d, std::span<std::uint32_t> scratch) {
	const std::size_t big = s.big, k = s.k, rest = big - k, n = s.length;
	Stack stack(scratch);
	const std::span<std::uint32_t> g{stack.take(big), big}, h{stack.take(k), k};
	std::fill_n(g.begin(), big - f.size(), 0);
	std::reverse_copy(f.begin(), f.end(), g.begin() + std::ptrdiff_t(big - f.size()));
	inverse(t, q, h, {stack.take(inverse_scratch(k)), inverse_scratch(k)});
	const std::span<std::uint32_t> a{stack.take(n), n}, b{stack.take(n), n}, th{stack.take(n), n};
	const auto lower = [n](std::size_t size) { return size <= n / 2 ? Half::kLower : Half::kBoth; };
	t.forward(g.first(k), 0, a);
	t.forward(h, 0, th);
	t.inverse_product(a, th, a, lower(k));
	std::copy_n(a.begin(), k, d.begin());
	t.forward(d.first(k), 0, a);
	if (qt.size() != n) {
		const std::size_t terms = std::min(q.size(), n);
		std::copy_n(q.begin(), terms, b.begin());
		if (q.size() > n) b[0] = std::uint32_t((std::uint64_t(b[0]) + q[n]) % kP);
		t.forward(b.first(terms), 0, b);
		qt = b;
	}
	t.inverse_product(qt, a, a, k >= n / 2 ? Half::kUpper : Half::kBoth);
	for (std::size_t i = 0; i < rest; ++i) b[i] = g[k + i] >= a[k + i] ? g[k + i] - a[k + i] : g[k + i] + kP - a[k + i];
	t.cyclic_product(b.first(rest), 0, a, th, lower(rest));
	std::copy_n(a.begin(), rest, d.begin() + std::ptrdiff_t(k));
}
}
namespace detail {
inline std::size_t evaluate_tree_words(std::size_t n, std::size_t m) {
	const std::size_t m8 = (m + 7) / 8 * 8;
	const Division sizes(n, m8);
	return PointTree::words(m) + Transform::words(sizes.log()) + Arena::footprint(sizes.big) +
		Arena::footprint(std::max(sizes.scratch_words(), PointTree::descend_words(m))) + Arena::footprint(m8);
}
inline void evaluate_tree(Arena& arena, std::span<const std::uint32_t> f, std::span<const std::uint32_t> points,
						std::span<std::uint32_t> values) {
	const std::size_t m = points.size();
	PointTree tree(arena, points);
	const std::size_t m8 = tree.size();
	const Division sizes(f.size(), m8);
	const Transform t(arena, sizes.log());
	const std::span<std::uint32_t> d = arena.take(sizes.big);
	const std::span<std::uint32_t> scratch = arena.take(std::max(sizes.scratch_words(), PointTree::descend_words(m)));
	divide(t, sizes, f, tree.product(), tree.product_transform(), d, scratch);
	const bool direct = m8 == m && reinterpret_cast<std::uintptr_t>(values.data()) % 32 == 0;
	const std::span<std::uint32_t> all = direct ? values : arena.take(m8);
	tree.descend(d.subspan(sizes.big - m8, m8), all, kR, scratch);
	if (!direct) std::copy_n(all.begin(), m, values.begin());
}
}
inline std::size_t evaluate_words(std::size_t n, std::size_t m) {
	return n * m <= detail::kDirectEvaluation ? 0 : detail::evaluate_tree_words(n, m);
}
inline void evaluate(Arena& arena, std::span<const std::uint32_t> f, std::span<const std::uint32_t> points,
					std::span<std::uint32_t> values) {
	if (f.size() * points.size() <= detail::kDirectEvaluation) return detail::evaluate_direct(f, points, values);
	detail::evaluate_tree(arena, f, points, values);
}
}
namespace evaluation_poly {
namespace detail {
inline Vec fold(Vec s) {
	return _mm256_add_epi64(_mm256_mul_epu32(_mm256_srli_epi64(s, 32), broadcast(kR)), _mm256_blend_epi32(s, _mm256_setzero_si256(), 0xAA));
}
template <std::size_t K>
[[gnu::always_inline]] inline Vec cross_sum(const Vec (&even)[K], const Vec (&odd)[K], std::size_t terms) {
	if constexpr (K == 1) {
		return montgomery_sums(even[0], odd[0], terms);
	} else {
		if (terms <= 17) return montgomery_sums(_mm256_add_epi64(even[0], even[1]), _mm256_add_epi64(odd[0], odd[1]), terms);
		return montgomery_sums(_mm256_add_epi64(fold(even[0]), fold(even[1])), _mm256_add_epi64(fold(odd[0]), fold(odd[1])), 0);
	}
}
[[gnu::noinline]] inline void cross_lanes(const std::uint32_t* a, std::size_t n, const std::uint32_t* b, std::size_t k,
										const std::uint32_t* c, const std::uint32_t* d, std::uint32_t* out) {
	for (std::size_t t = 0; t < n + k; ++t) {
		Vec even[2] = {}, odd[2] = {};
		const std::size_t first[2] = {t > k ? t - k : 0, t > n ? t - n : 0}, last[2] = {std::min(t, n - 1), std::min(t, k - 1)};
		for (std::size_t i = first[0]; i <= last[0]; ++i) {
			const Vec x = load(a + 8 * i), y = load(d + 8 * (t - i));
			even[0] = _mm256_add_epi64(even[0], _mm256_mul_epu32(x, y));
			odd[0] = _mm256_add_epi64(odd[0], _mm256_mul_epu32(_mm256_srli_epi64(x, 32), _mm256_srli_epi64(y, 32)));
		}
		for (std::size_t i = first[1]; i <= last[1]; ++i) {
			const Vec x = load(b + 8 * i), y = load(c + 8 * (t - i));
			even[1] = _mm256_add_epi64(even[1], _mm256_mul_epu32(x, y));
			odd[1] = _mm256_add_epi64(odd[1], _mm256_mul_epu32(_mm256_srli_epi64(x, 32), _mm256_srli_epi64(y, 32)));
		}
		store(out + 8 * t, cross_sum(even, odd, (last[0] + 1 - first[0]) + (last[1] + 1 - first[1])));
	}
}
template <std::size_t D, std::size_t B>
[[gnu::always_inline]] inline void cross_lanes(const std::uint32_t* a, const std::uint32_t* b, const std::uint32_t* c,
											const std::uint32_t* d, std::uint32_t* out) {
	constexpr std::size_t kPad = B - 1, kSums = 2 * D > 17 ? 2 : 1;
	Vec x[D + 2 * kPad], xo[D + 2 * kPad], y[D + 2 * kPad], yo[D + 2 * kPad], co[D + 1], dq[D + 1];
	for (std::size_t i = 0; i < kPad; ++i)
		x[i] = xo[i] = y[i] = yo[i] = x[D + kPad + i] = xo[D + kPad + i] = y[D + kPad + i] = yo[D + kPad + i] = _mm256_setzero_si256();
#pragma GCC unroll 16
	for (std::size_t i = 0; i < D; ++i) {
		x[kPad + i] = load(a + 8 * i), xo[kPad + i] = _mm256_srli_epi64(x[kPad + i], 32);
		y[kPad + i] = load(b + 8 * i), yo[kPad + i] = _mm256_srli_epi64(y[kPad + i], 32);
	}
#pragma GCC unroll 17
	for (std::size_t j = 0; j <= D; ++j) co[j] = _mm256_srli_epi64(load(c + 8 * j), 32), dq[j] = _mm256_srli_epi64(load(d + 8 * j), 32);
	for (std::size_t t0 = 0; t0 < 2 * D; t0 += B) {
		Vec even[B][kSums] = {}, odd[B][kSums] = {};
		const std::size_t first = t0 + 1 > D ? t0 + 1 - D : 0, last = std::min(D, t0 + B - 1);
		for (std::size_t j = first; j <= last; ++j) {
			const Vec qd = load(d + 8 * j), qc = load(c + 8 * j);
#pragma GCC unroll 8
			for (std::size_t s = 0; s < B; ++s) {
				const std::size_t i = kPad + t0 + s - j;
				even[s][0] = _mm256_add_epi64(even[s][0], _mm256_mul_epu32(x[i], qd));
				odd[s][0] = _mm256_add_epi64(odd[s][0], _mm256_mul_epu32(xo[i], dq[j]));
				even[s][kSums - 1] = _mm256_add_epi64(even[s][kSums - 1], _mm256_mul_epu32(y[i], qc));
				odd[s][kSums - 1] = _mm256_add_epi64(odd[s][kSums - 1], _mm256_mul_epu32(yo[i], co[j]));
			}
		}
#pragma GCC unroll 8
		for (std::size_t s = 0; s < B; ++s) {
			const std::size_t t = t0 + s, terms = 2 * (std::min(t, D - 1) + 1 - (t > D ? t - D : 0));
			if (t < 2 * D) store(out + 8 * t, cross_sum(even[s], odd[s], terms));
		}
	}
}
template <std::size_t D>
[[gnu::always_inline]] inline void cross_lanes(const std::uint32_t* a, const std::uint32_t* b, const std::uint32_t* c,
											const std::uint32_t* d, std::uint32_t* out) {
	static_assert(2 * D <= 17);
	Vec x[D], xo[D], y[D], yo[D], p[D + 1], po[D + 1], q[D + 1], qo[D + 1];
#pragma GCC unroll 8
	for (std::size_t i = 0; i < D; ++i) {
		x[i] = load(a + 8 * i), xo[i] = _mm256_srli_epi64(x[i], 32);
		y[i] = load(b + 8 * i), yo[i] = _mm256_srli_epi64(y[i], 32);
	}
#pragma GCC unroll 9
	for (std::size_t j = 0; j <= D; ++j) {
		p[j] = load(c + 8 * j), po[j] = _mm256_srli_epi64(p[j], 32);
		q[j] = load(d + 8 * j), qo[j] = _mm256_srli_epi64(q[j], 32);
	}
#pragma GCC unroll 16
	for (std::size_t t = 0; t < 2 * D; ++t) {
		const std::size_t first = t > D ? t - D : 0, last = std::min(t, D - 1);
		Vec even = _mm256_setzero_si256(), odd = _mm256_setzero_si256();
#pragma GCC unroll 8
		for (std::size_t i = first; i <= last; ++i) {
			even = _mm256_add_epi64(even, _mm256_add_epi64(_mm256_mul_epu32(x[i], q[t - i]), _mm256_mul_epu32(y[i], p[t - i])));
			odd = _mm256_add_epi64(odd, _mm256_add_epi64(_mm256_mul_epu32(xo[i], qo[t - i]), _mm256_mul_epu32(yo[i], po[t - i])));
		}
		store(out + 8 * t, montgomery_sums(even, odd, 2 * (last + 1 - first)));
	}
}
template <std::size_t D>
void cross_level(const std::uint32_t* sums, const std::uint32_t* products, std::uint32_t* out, std::size_t nodes) {
	for (std::size_t i = 0; i < nodes; ++i) {
		const std::uint32_t *r = sums + 8 * D * (2 * i), *q = products + 8 * (D + 1) * (2 * i);
		if constexpr (D <= 8) cross_lanes<D>(r, r + 8 * D, q, q + 8 * (D + 1), out + 16 * D * i);
		else cross_lanes<D, 2>(r, r + 8 * D, q, q + 8 * (D + 1), out + 16 * D * i);
	}
}
inline Vec inverse_montgomery(Vec x) {
	Vec result = broadcast(kR), power = x;
	for (std::uint32_t e = kP - 2; e; e >>= 1) {
		if (e & 1) result = montgomery(result, power);
		power = montgomery(power, power);
	}
	return result;
}
class BaseInterpolation {
public:
	BaseInterpolation(const PointSlots& slots, const std::uint32_t* y, std::size_t m) : slots_(slots), y_(y), m_(m) {}
	const std::uint32_t* run(std::size_t lo, std::size_t hi, const std::uint32_t* w) {
		const std::size_t count = hi - lo;
		lo_ = lo;
		if (count == 1) {
			store(values_, load(w));
			weights(1);
			return values_;
		}
		if (std::has_single_bit(count)) return run_levels(count, w);
		free_ = memory_;
		build(1, lo, hi);
		descend(1, lo, hi, w);
		weights(count);
		ascend(1, lo, hi, sums_);
		return sums_;
	}
private:
	const std::uint32_t* run_levels(std::size_t count, const std::uint32_t* w) {
		const std::uint32_t* products[6];
		std::uint32_t* at = memory_;
		for (std::size_t k = 0; k < count; ++k) slots_.load(lo_ + k, at + 16 * k);
		products[0] = at;
		at += 16 * count;
		for (std::size_t d = 1, j = 1; 2 * d < count; d *= 2, ++j) {
			with_degree(d, [&]<std::size_t D>() {
				if constexpr (D <= LaneLayout::kBase / 4) product_level<D>(products[j - 1], at, count / (2 * D));
			});
			products[j] = at;
			at += 8 * (2 * d + 1) * (count / (2 * d));
		}
		std::uint32_t* const buffers[2] = {at, at + 8 * count};
		const std::uint32_t* parents = w;
		for (std::size_t d = count / 2, j = std::countr_zero(count) - 1;; d /= 2, --j) {
			std::uint32_t* const out = d == 1 ? values_ : buffers[j & 1];
			with_degree(d, [&]<std::size_t D>() { middle_level<D>(parents, products[j], out, count / D); });
			if (d == 1) break;
			parents = out;
		}
		weights(count);
		const std::uint32_t* sums = values_;
		for (std::size_t d = 1, j = 0; d < count; d *= 2, ++j) {
			std::uint32_t* const out = 2 * d == count ? sums_ : buffers[j & 1];
			with_degree(d, [&]<std::size_t D>() { cross_level<D>(sums, products[j], out, count / (2 * D)); });
			sums = out;
		}
		return sums_;
	}
	const std::uint32_t* build(std::size_t v, std::size_t lo, std::size_t hi) {
		std::uint32_t* const c = free_;
		if (hi - lo == 1) {
			slots_.load(lo, c);
			free_ += 16;
			return c;
		}
		const std::size_t mid = lo + (hi - lo) / 2;
		product_[2 * v] = build(2 * v, lo, mid);
		product_[2 * v + 1] = build(2 * v + 1, mid, hi);
		if (v == 1) return nullptr;
		std::uint32_t* const out = free_;
		multiply_lanes_any(product_[2 * v], mid - lo, product_[2 * v + 1], hi - mid, out);
		free_ += 8 * (hi - lo + 1);
		return out;
	}
	void descend(std::size_t v, std::size_t lo, std::size_t hi, const std::uint32_t* w) {
		if (hi - lo == 1) return store(values_ + 8 * (lo - lo_), load(w));
		const std::size_t mid = lo + (hi - lo) / 2;
		std::uint32_t* const left = free_;
		std::uint32_t* const right = left + 8 * (mid - lo);
		free_ = right + 8 * (hi - mid);
		middle_lanes(w, hi - mid, product_[2 * v + 1], mid - lo, left);
		middle_lanes(w, mid - lo, product_[2 * v], hi - mid, right);
		descend(2 * v, lo, mid, left);
		descend(2 * v + 1, mid, hi, right);
		free_ = left;
	}
	void ascend(std::size_t v, std::size_t lo, std::size_t hi, std::uint32_t* out) {
		if (hi - lo == 1) return store(out, load(values_ + 8 * (lo - lo_)));
		const std::size_t mid = lo + (hi - lo) / 2;
		std::uint32_t* const left = free_;
		std::uint32_t* const right = left + 8 * (mid - lo);
		free_ = right + 8 * (hi - mid);
		ascend(2 * v, lo, mid, left);
		ascend(2 * v + 1, mid, hi, right);
		cross_lanes(left, mid - lo, right, hi - mid, product_[2 * v], product_[2 * v + 1], out);
		free_ = left;
	}
	void weights(std::size_t count) {
		constexpr std::size_t kChains = 4;
		const Vec iota = _mm256_setr_epi32(0, 1, 2, 3, 4, 5, 6, 7), one = broadcast(kR);
		const std::size_t groups = (count + kChains - 1) / kChains;
		Vec prefix[kMaxSlots];
		for (std::size_t g = 0; g < groups; ++g) {
#pragma GCC unroll 4
			for (std::size_t c = 0; c < kChains; ++c) {
				const std::size_t k = kChains * g + c, first = 8 * (lo_ + k);
				Vec x = one;
				if (k < count) {
					x = load(values_ + 8 * k);
					if (first + 8 > m_) {
						x = _mm256_blendv_epi8(one, x, _mm256_cmpgt_epi32(broadcast(std::uint32_t(m_ - first)), iota));
						store(values_ + 8 * k, x);
					}
				}
				prefix[k] = g ? montgomery(prefix[k - kChains], x) : x;
			}
		}
		const Vec* const last = prefix + kChains * (groups - 1);
		const Vec p01 = montgomery(last[0], last[1]), p23 = montgomery(last[2], last[3]);
		const Vec inverse = inverse_montgomery(montgomery(p01, p23));
		const Vec i01 = montgomery(inverse, p23), i23 = montgomery(inverse, p01);
		Vec e[kChains] = {montgomery(i01, last[1]), montgomery(i01, last[0]), montgomery(i23, last[3]), montgomery(i23, last[2])};
		for (std::size_t g = groups; g-- > 0;) {
#pragma GCC unroll 4
			for (std::size_t c = 0; c < kChains; ++c) {
				const std::size_t k = kChains * g + c;
				if (k >= count) continue;
				const Vec x = load(values_ + 8 * k), reciprocal = g ? montgomery(e[c], prefix[k - kChains]) : e[c];
				e[c] = montgomery(e[c], x);
				store(values_ + 8 * k, canonical(montgomery(reciprocal, load(y_ + 8 * (lo_ + k)))));
			}
		}
	}
	static constexpr std::size_t kMaxSlots = LaneLayout::kBase;
	alignas(32) std::uint32_t memory_[8 * 320];
	alignas(32) std::uint32_t values_[8 * kMaxSlots];
	alignas(32) std::uint32_t sums_[8 * kMaxSlots];
	const std::uint32_t* product_[64];
	std::uint32_t* free_ = memory_;
	const PointSlots& slots_;
	const std::uint32_t* y_;
	std::size_t m_, lo_ = 0;
};
}
class InterpolationTree : public PointTree {
public:
	InterpolationTree(Arena& arena, std::span<const std::uint32_t> points) : PointTree(arena, points), m_(points.size()) {}
	static std::size_t scratch_words(std::size_t m) {
		const std::size_t m8 = (m + 7) / 8 * 8, lane_length = LaneLayout::length(std::uint32_t(m8 / 8));
		const std::size_t stride = std::max<std::size_t>(8, lane_length), top_length = StandardLayout::length(std::uint32_t(m8));
		return descend_words(m) + 10 * Arena::footprint(8 * stride) + 6 * Arena::footprint(top_length) + 4096;
	}
	void interpolate(std::span<const std::uint32_t> w, std::span<const std::uint32_t> y, std::span<std::uint32_t> r,
					std::span<std::uint32_t> scratch) {
		using namespace detail;
		Stack stack(scratch);
		const std::size_t lane_length = LaneLayout::length(std::uint32_t(count_)), stride = std::max<std::size_t>(8, lane_length);
		const LaneState root = lane_state(w, kR, stack);
		BaseInterpolation base(slots_, y.data(), m_);
		std::uint32_t* const sums = stack.take(8 * stride);
		if (count_ <= LaneLayout::kBase) {
			std::copy_n(base.run(0, count_, root.state + 8 * (lane_length - count_)), 8 * count_, sums);
		} else {
			lanes(0, count_, root.state, root.u, stack, base, sums, lane_length);
			t_.inverse({sums, 8 * lane_length}, {sums, 8 * lane_length});
		}
		std::uint32_t* const columns = root.state;
		for (std::size_t j = 0; j < count_; j += 8) {
			Vec v[8];
			for (std::size_t i = 0; i < 8; ++i) v[i] = load(sums + 8 * (j + i));
			transpose8(v);
			for (std::size_t l = 0; l < 8; ++l) store(columns + l * stride + j, v[l]);
		}
		const std::size_t length = StandardLayout::length(std::uint32_t(m8_));
		top(0, 8, columns, stride, stack, r.data(), length);
		t_.inverse(r.first(length), r.first(length));
	}
private:
	void lanes(std::size_t lo, std::size_t hi, const std::uint32_t* s, std::uint32_t u, detail::Stack& stack,
			detail::BaseInterpolation& base, std::uint32_t* out, std::size_t out_length) {
		using namespace detail;
		const LaneTree& tree = *lanes_;
		const std::size_t length = LaneLayout::length(std::uint32_t(tree.degree(lo, hi))), words = 8 * length;
		const std::size_t mid = tree.split(lo, hi), mark = stack.mark();
		const std::uint32_t* const stored[2] = {lane_store_.pair(mid), lane_store_.pair(mid) + Arena::footprint(words)};
		std::uint32_t* const sums[2] = {out_length >= 2 * length ? out + words : out, stack.take(words)};
		const std::size_t sides[2][2] = {{lo, mid}, {mid, hi}};
		for (int side = 0; side < 2; ++side) {
			const std::size_t xlo = sides[side][0], xhi = sides[side][1], degree = tree.degree(xlo, xhi);
			const std::size_t inner = 8 * LaneLayout::length(std::uint32_t(degree)), inner_mark = stack.mark();
			std::uint32_t* const p = stack.take(words);
			TreeTransform::pointwise_products(s, stored[1 - side], {p, words});
			if (xhi - xlo == 1 || degree <= LaneLayout::kBase) {
				coefficients(p, words, u);
				const std::uint32_t* const sum = base.run(xlo, xhi, p + words - 8 * degree);
				t_.forward({sum, 8 * degree}, 0, {sums[side], words});
			} else if (2 * inner == words) {
				halve(p, words);
				lanes(xlo, xhi, p, half(u), stack, base, sums[side], length);
			} else {
				coefficients(p, words, u);
				std::uint32_t* const q = stack.take(inner);
				t_.forward({p + words - inner, inner}, 0, {q, inner});
				lanes(xlo, xhi, q, 1, stack, base, sums[side], length);
			}
			stack.release(inner_mark);
		}
		TreeTransform::pointwise_product_sums(sums[0], stored[1], sums[1], stored[0], {out, words});
		double_to(out, words, out_length / length, stack);
		stack.release(mark);
	}
	void top(std::size_t lo, std::size_t hi, const std::uint32_t* columns, std::size_t stride, detail::Stack& stack,
			std::uint32_t* out, std::size_t out_length) {
		const TopTree& tree = *top_;
		if (hi - lo == 1) return t_.forward({columns + lo * stride, count_}, 0, {out, out_length});
		const std::size_t length = StandardLayout::length(tree.degree(lo, hi)), mid = tree.split(lo, hi), mark = stack.mark();
		const std::uint32_t* const stored[2] = {top_store_.pair(mid), top_store_.pair(mid) + Arena::footprint(length)};
		std::uint32_t* const sums[2] = {out_length >= 2 * length ? out + length : out, stack.take(length)};
		top(lo, mid, columns, stride, stack, sums[0], length);
		top(mid, hi, columns, stride, stack, sums[1], length);
		t_.leaf_product_sums(sums[0], stored[1], sums[1], stored[0], {out, length});
		double_to(out, length, out_length / length, stack);
		stack.release(mark);
	}
	void double_to(std::uint32_t* out, std::size_t words, std::size_t factor, detail::Stack& stack) const {
		if (factor == 1) return;
		std::uint32_t* const c = stack.take(words);
		t_.inverse({out, words}, {c, words});
		for (std::size_t n = words; n < factor * words; n *= 2) t_.forward_upper({c, words}, 0, {out + n, n});
	}
	std::size_t m_;
};
inline std::size_t interpolate_words(std::size_t m) {
	const std::size_t m8 = (m + 7) / 8 * 8;
	const detail::Division sizes(m, m8);
	return PointTree::words(m) + Transform::words(sizes.log()) + Arena::footprint(std::max(m + 1, m8)) +
		Arena::footprint(StandardLayout::length(std::uint32_t(m8))) +
		Arena::footprint(std::max(sizes.scratch_words(), InterpolationTree::scratch_words(m)));
}
inline void interpolate(Arena& arena, std::span<const std::uint32_t> points, std::span<const std::uint32_t> values,
						std::span<std::uint32_t> c) {
	const std::size_t m = points.size();
	InterpolationTree tree(arena, points);
	const std::size_t m8 = tree.size(), length = StandardLayout::length(std::uint32_t(m8));
	const std::span<std::uint32_t> y = arena.take(std::max(m + 1, m8));
	std::reverse_copy(tree.product().begin(), tree.product().begin() + std::ptrdiff_t(m + 1), y.begin());
	derivative(y.first(m + 1), y.first(m));
	const detail::Division sizes(m, m8);
	const Transform t(arena, sizes.log());
	const std::span<std::uint32_t> window = arena.take(length);
	const std::span<std::uint32_t> scratch = arena.take(std::max(sizes.scratch_words(), InterpolationTree::scratch_words(m)));
	detail::divide(t, sizes, y.first(m), tree.product(), tree.product_transform(), window.first(m8), scratch);
	std::copy(values.begin(), values.end(), y.begin());
	y[m] = 0;
	tree.interpolate(window.first(m8), y.first(m8), window, scratch);
	std::reverse_copy(window.begin(), window.begin() + std::ptrdiff_t(m), c.begin());
}
}
namespace evaluation_poly {
inline void import_words(std::span<const Mint> in, std::span<std::uint32_t> out) {
	using namespace detail;
	std::size_t i = 0;
	for (; i + 8 <= in.size(); i += 8) {
		const Vec x = load_unaligned(reinterpret_cast<const std::uint32_t *>(in.data() + i));
		store(out.data() + i, canonical(montgomery(x, broadcast(1))));
	}
	for (; i < in.size(); ++i) out[i] = in[i].val();
}
inline void import_montgomery(std::span<const Mint> in, std::span<std::uint32_t> out) {
	for (std::size_t i = 0; i < in.size(); ++i) {
		const unsigned x = in[i].v;
		out[i] = std::min(x, x - Mint::mod());
	}
}
inline std::vector<Mint> export_words(std::span<const std::uint32_t> in) {
	std::vector<Mint> out;
	append_fps_words<true>(out, in.data(), in.size());
	return out;
}
inline std::vector<Mint> native_evaluate(std::span<const Mint> f, std::span<const Mint> points) {
	Arena arena(evaluate_words(f.size(), points.size()) + Arena::footprint(f.size()) + 2 * Arena::footprint(points.size()));
	auto a = arena.take(f.size()), x = arena.take(points.size()), y = arena.take(points.size());
	import_montgomery(f, a);
	import_words(points, x);
	evaluate(arena, a, x, y);
	return export_words(y);
}
inline std::vector<Mint> native_interpolate(std::span<const Mint> points, std::span<const Mint> values) {
	const std::size_t n = points.size();
	Arena arena(interpolate_words(n) + 3 * Arena::footprint(n));
	auto x = arena.take(n), y = arena.take(n), c = arena.take(n);
	import_words(points, x);
	import_montgomery(values, y);
	interpolate(arena, x, y, c);
	return export_words(c);
}
}
}

#pragma GCC pop_options
#endif
#endif
