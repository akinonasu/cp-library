#ifndef SUFFIX_TREE_HPP
#define SUFFIX_TREE_HPP

#include "../components/suffix_array.hpp"
#include "../components/sequence_compare.hpp"
#include "../components/static_range_min.hpp"
#include <array>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>

class SuffixTree {
	struct Node { int parent, depth, left, right; };
	std::string text_;
	std::vector<Node> nodes_;
	std::vector<int> sa_, lcp_, rank_, terminals_, branches_, offset_, children_;
	std::array<int, 256> root_children_;
	std::uint64_t distinct_ = 0;
	mutable std::optional<StaticRangeMin<std::pair<int, int>>> index_;
	void check([[maybe_unused]] int v) const { assert(0 <= v && v < node_count()); }
	void prepare_index() const {
		if (index_) return;
		std::vector<std::pair<int, int>> values(size());
		for (int i = 0; i < size(); ++i) values[i] = {lcp_[i], branches_[i]};
		index_.emplace(std::move(values));
	}
	int child(int v, unsigned char c) const {
		if (!v) return root_children_[c];
		int l = offset_[v], r = offset_[v + 1];
		auto symbol = [&](int i) { return static_cast<unsigned char>(text_[sa_[nodes_[children_[i]].left] + nodes_[v].depth]); };
		if (r - l <= 4) {
			for (int i = l; i < r; ++i) if (symbol(i) == c) return children_[i];
			return -1;
		}
		int end = r;
		while (l < r) { int m = l + (r - l) / 2; if (symbol(m) < c) l = m + 1; else r = m; }
		return l < end && symbol(l) == c ? children_[l] : -1;
	}

  public:
	struct Locus { int node, length; };
	static constexpr int root = 0;
	SuffixTree() { build({}); }
	explicit SuffixTree(std::string_view s) { build(s); }
	SuffixTree(const SuffixTree &) = default;
	SuffixTree &operator=(const SuffixTree &) = default;
	SuffixTree(SuffixTree &&other) : SuffixTree() { swap(other); }
	SuffixTree &operator=(SuffixTree &&other) {
		if (this != &other) { SuffixTree moved(std::move(other)); swap(moved); }
		return *this;
	}
	void swap(SuffixTree &other) noexcept {
		text_.swap(other.text_);
		nodes_.swap(other.nodes_);
		sa_.swap(other.sa_); lcp_.swap(other.lcp_); rank_.swap(other.rank_);
		terminals_.swap(other.terminals_); branches_.swap(other.branches_);
		offset_.swap(other.offset_); children_.swap(other.children_);
		root_children_.swap(other.root_children_);
		std::swap(distinct_, other.distinct_);
		index_.swap(other.index_);
	}
	void build(std::string_view s) {
		assert(s.size() < std::size_t(std::numeric_limits<int>::max() / 2));
		std::string copy(s);
		text_.swap(copy);
		int n = size();
		sa_ = suffix_array_detail::bytes(text_);
		sa_.insert(sa_.begin(), n);
		rank_.resize(n + 1);
		for (int i = 0; i <= n; ++i) rank_[sa_[i]] = i;
		lcp_.assign(n, 0);
		for (int p = 0, h = 0; p < n; ++p) {
			if (h) --h;
			int i = rank_[p], q = sa_[i - 1];
			h += sequence_compare_detail::prefix(text_.data() + p + h, text_.data() + q + h, std::min(n - p, n - q) - h);
			lcp_[i - 1] = h;
		}
		nodes_.clear();
		nodes_.reserve(std::size_t(n) + 1);
		nodes_.push_back({-1, 0, 0, n + 1});
		terminals_.assign(n + 1, 0);
		branches_.resize(n);
		std::vector<int> stack{0};
		for (int i = 1; i <= n; ++i) {
			int common = lcp_[i - 1], last = -1;
			while (nodes_[stack.back()].depth > common) { last = stack.back(); nodes_[last].right = i; stack.pop_back(); }
			if (nodes_[stack.back()].depth < common) {
				int v = node_count();
				nodes_.push_back({stack.back(), common, nodes_[last].left, n + 1});
				nodes_[last].parent = v;
				stack.push_back(v);
			}
			branches_[i - 1] = stack.back();
			int v = node_count(), p = sa_[i];
			nodes_.push_back({stack.back(), n - p, i, n + 1});
			terminals_[p] = v;
			stack.push_back(v);
		}
		offset_.assign(std::size_t(node_count()) + 1, 0);
		for (int v = 1; v < node_count(); ++v) ++offset_[nodes_[v].parent + 1];
		for (int v = 0; v < node_count(); ++v) offset_[v + 1] += offset_[v];
		children_.resize(node_count() - 1);
		auto cursor = offset_;
		for (int v = 1; v < node_count(); ++v) children_[cursor[nodes_[v].parent]++] = v;
		root_children_.fill(-1);
		for (int v : children(0)) root_children_[static_cast<unsigned char>(text_[sa_[nodes_[v].left]])] = v;
		distinct_ = 0;
		for (int v = 1; v < node_count(); ++v) distinct_ += nodes_[v].depth - nodes_[nodes_[v].parent].depth;
		index_.reset();
	}
	void clear() { build({}); }
	int size() const { return static_cast<int>(text_.size()); }
	bool empty() const { return text_.empty(); }
	int node_count() const { return static_cast<int>(nodes_.size()); }
	std::string_view text() const { return text_; }
	int parent(int v) const { check(v); return nodes_[v].parent; }
	int depth(int v) const { check(v); return nodes_[v].depth; }
	std::pair<int, int> edge_range(int v) const {
		check(v);
		if (!v) return {0, 0};
		int p = sa_[nodes_[v].left];
		return {p + nodes_[nodes_[v].parent].depth, p + nodes_[v].depth};
	}
	std::pair<int, int> label_range(int v) const { check(v); int p = sa_[nodes_[v].left]; return {p, p + nodes_[v].depth}; }
	std::span<const int> children(int v) const {
		check(v);
		int count = offset_[v + 1] - offset_[v];
		return count ? std::span<const int>(children_.data() + offset_[v], count) : std::span<const int>{};
	}
	int transition(int v, char c) const { check(v); return child(v, static_cast<unsigned char>(c)); }
	int suffix_start(int v) const { check(v); int p = sa_[nodes_[v].left]; return size() - p == nodes_[v].depth ? p : -1; }
	int suffix_node(int p) const { assert(0 <= p && p <= size()); return terminals_[p]; }
	std::pair<int, int> occurrence_range(int v) const { check(v); return {nodes_[v].left, nodes_[v].right}; }
	int occurrence_count(int v) const { check(v); return nodes_[v].right - nodes_[v].left; }
	const std::vector<int> &suffix_array() const { return sa_; }
	const std::vector<int> &lcp_array() const { return lcp_; }
	std::uint64_t distinct_substrings() const { return distinct_; }
	std::optional<Locus> find(std::string_view pattern) const {
		if (pattern.size() > text_.size()) return std::nullopt;
		int v = 0, matched = 0, length = static_cast<int>(pattern.size());
		while (matched < length) {
			int u = child(v, static_cast<unsigned char>(pattern[matched]));
			if (u == -1) return std::nullopt;
			int start = sa_[nodes_[u].left] + nodes_[v].depth;
			int take = std::min(length - matched, nodes_[u].depth - nodes_[v].depth);
			if (sequence_compare_detail::prefix(text_.data() + start, pattern.data() + matched, take) != take) return std::nullopt;
			matched += take;
			v = u;
		}
		return Locus{v, length};
	}
	std::optional<Locus> advance(Locus locus, char c) const {
		check(locus.node);
		int v = locus.node;
		assert((!v && locus.length == 0) || (v && nodes_[nodes_[v].parent].depth < locus.length && locus.length <= nodes_[v].depth));
		if (locus.length < nodes_[v].depth) {
			if (text_[sa_[nodes_[v].left] + locus.length] != c) return std::nullopt;
			return Locus{v, locus.length + 1};
		}
		int u = child(v, static_cast<unsigned char>(c));
		return u == -1 ? std::nullopt : std::optional<Locus>(Locus{u, locus.length + 1});
	}
	bool contains(std::string_view pattern) const { return find(pattern).has_value(); }
	int count(std::string_view pattern) const { auto locus = find(pattern); return locus ? occurrence_count(locus->node) : 0; }
	std::vector<int> occurrences(std::string_view pattern) const {
		auto locus = find(pattern);
		if (!locus) return {};
		auto [l, r] = occurrence_range(locus->node);
		return {sa_.begin() + l, sa_.begin() + r};
	}
	int lcp(int p, int q) const {
		assert(0 <= p && p <= size() && 0 <= q && q <= size());
		if (p == q) return size() - p;
		int a = rank_[p], b = rank_[q];
		if (a > b) std::swap(a, b);
		prepare_index();
		return index_->prod(a, b).first;
	}
	int lca(int u, int v) const {
		check(u); check(v);
		if (nodes_[u].left <= nodes_[v].left && nodes_[v].right <= nodes_[u].right) return u;
		if (nodes_[v].left <= nodes_[u].left && nodes_[u].right <= nodes_[v].right) return v;
		int a = nodes_[u].left, b = nodes_[v].left;
		if (a > b) std::swap(a, b);
		prepare_index();
		return index_->prod(a, b).second;
	}
	int suffix_link(int v) const {
		check(v);
		if (!v) return 0;
		int p = suffix_start(v);
		if (p >= 0) return terminals_[p + 1];
		return lca(terminals_[sa_[nodes_[v].left] + 1], terminals_[sa_[nodes_[v].right - 1] + 1]);
	}
};

#endif
